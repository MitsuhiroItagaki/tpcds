# Databricks notebook source
# MAGIC %sql
# MAGIC use catalog tpcds;
# MAGIC use schema tpcds_sf1000_delta_lc;
# MAGIC set use_cached_result = false;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q61.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  promotions,total,cast(promotions as decimal(15,4))/cast(total as decimal(15,4))*100
# MAGIC from
# MAGIC   (select sum(ss_ext_sales_price) promotions
# MAGIC    from  store_sales
# MAGIC         ,store
# MAGIC         ,promotion
# MAGIC         ,date_dim
# MAGIC         ,customer
# MAGIC         ,customer_address 
# MAGIC         ,item
# MAGIC    where ss_sold_date_sk = d_date_sk
# MAGIC    and   ss_store_sk = s_store_sk
# MAGIC    and   ss_promo_sk = p_promo_sk
# MAGIC    and   ss_customer_sk= c_customer_sk
# MAGIC    and   ca_address_sk = c_current_addr_sk
# MAGIC    and   ss_item_sk = i_item_sk 
# MAGIC    and   ca_gmt_offset = -6
# MAGIC    and   i_category = 'Books'
# MAGIC    and   (p_channel_dmail = 'Y' or p_channel_email = 'Y' or p_channel_tv = 'Y')
# MAGIC    and   s_gmt_offset = -6
# MAGIC    and   d_year = 2001
# MAGIC    and   d_moy  = 11) promotional_sales,
# MAGIC   (select sum(ss_ext_sales_price) total
# MAGIC    from  store_sales
# MAGIC         ,store
# MAGIC         ,date_dim
# MAGIC         ,customer
# MAGIC         ,customer_address
# MAGIC         ,item
# MAGIC    where ss_sold_date_sk = d_date_sk
# MAGIC    and   ss_store_sk = s_store_sk
# MAGIC    and   ss_customer_sk= c_customer_sk
# MAGIC    and   ca_address_sk = c_current_addr_sk
# MAGIC    and   ss_item_sk = i_item_sk
# MAGIC    and   ca_gmt_offset = -6
# MAGIC    and   i_category = 'Books'
# MAGIC    and   s_gmt_offset = -6
# MAGIC    and   d_year = 2001
# MAGIC    and   d_moy  = 11) all_sales
# MAGIC order by promotions, total
# MAGIC limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q62.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  
# MAGIC    substr(w_warehouse_name,1,20)
# MAGIC   ,sm_type
# MAGIC   ,web_name
# MAGIC   ,sum(case when (ws_ship_date_sk - ws_sold_date_sk <= 30 ) then 1 else 0 end)  as `30 days` 
# MAGIC   ,sum(case when (ws_ship_date_sk - ws_sold_date_sk > 30) and 
# MAGIC                  (ws_ship_date_sk - ws_sold_date_sk <= 60) then 1 else 0 end )  as `31-60 days` 
# MAGIC   ,sum(case when (ws_ship_date_sk - ws_sold_date_sk > 60) and 
# MAGIC                  (ws_ship_date_sk - ws_sold_date_sk <= 90) then 1 else 0 end)  as `61-90 days` 
# MAGIC   ,sum(case when (ws_ship_date_sk - ws_sold_date_sk > 90) and
# MAGIC                  (ws_ship_date_sk - ws_sold_date_sk <= 120) then 1 else 0 end)  as `91-120 days` 
# MAGIC   ,sum(case when (ws_ship_date_sk - ws_sold_date_sk  > 120) then 1 else 0 end)  as `>120 days` 
# MAGIC from
# MAGIC    web_sales
# MAGIC   ,warehouse
# MAGIC   ,ship_mode
# MAGIC   ,web_site
# MAGIC   ,date_dim
# MAGIC where
# MAGIC     d_month_seq between 1221 and 1221 + 11
# MAGIC and ws_ship_date_sk   = d_date_sk
# MAGIC and ws_warehouse_sk   = w_warehouse_sk
# MAGIC and ws_ship_mode_sk   = sm_ship_mode_sk
# MAGIC and ws_web_site_sk    = web_site_sk
# MAGIC group by
# MAGIC    substr(w_warehouse_name,1,20)
# MAGIC   ,sm_type
# MAGIC   ,web_name
# MAGIC order by substr(w_warehouse_name,1,20)
# MAGIC         ,sm_type
# MAGIC        ,web_name
# MAGIC limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q63.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  * 
# MAGIC from (select i_manager_id
# MAGIC              ,sum(ss_sales_price) sum_sales
# MAGIC              ,avg(sum(ss_sales_price)) over (partition by i_manager_id) avg_monthly_sales
# MAGIC       from item
# MAGIC           ,store_sales
# MAGIC           ,date_dim
# MAGIC           ,store
# MAGIC       where ss_item_sk = i_item_sk
# MAGIC         and ss_sold_date_sk = d_date_sk
# MAGIC         and ss_store_sk = s_store_sk
# MAGIC         and d_month_seq in (1205,1205+1,1205+2,1205+3,1205+4,1205+5,1205+6,1205+7,1205+8,1205+9,1205+10,1205+11)
# MAGIC         and ((    i_category in ('Books','Children','Electronics')
# MAGIC               and i_class in ('personal','portable','reference','self-help')
# MAGIC               and i_brand in ('scholaramalgamalg #14','scholaramalgamalg #7',
# MAGIC 		                  'exportiunivamalg #9','scholaramalgamalg #9'))
# MAGIC            or(    i_category in ('Women','Music','Men')
# MAGIC               and i_class in ('accessories','classical','fragrances','pants')
# MAGIC               and i_brand in ('amalgimporto #1','edu packscholar #1','exportiimporto #1',
# MAGIC 		                 'importoamalg #1')))
# MAGIC group by i_manager_id, d_moy) tmp1
# MAGIC where case when avg_monthly_sales > 0 then abs (sum_sales - avg_monthly_sales) / avg_monthly_sales else null end > 0.1
# MAGIC order by i_manager_id
# MAGIC         ,avg_monthly_sales
# MAGIC         ,sum_sales
# MAGIC limit 100
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q64.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC with cs_ui as
# MAGIC  (select cs_item_sk
# MAGIC         ,sum(cs_ext_list_price) as sale,sum(cr_refunded_cash+cr_reversed_charge+cr_store_credit) as refund
# MAGIC   from catalog_sales
# MAGIC       ,catalog_returns
# MAGIC   where cs_item_sk = cr_item_sk
# MAGIC     and cs_order_number = cr_order_number
# MAGIC   group by cs_item_sk
# MAGIC   having sum(cs_ext_list_price)>2*sum(cr_refunded_cash+cr_reversed_charge+cr_store_credit)),
# MAGIC cross_sales as
# MAGIC  (select i_product_name product_name
# MAGIC      ,i_item_sk item_sk
# MAGIC      ,s_store_name store_name
# MAGIC      ,s_zip store_zip
# MAGIC      ,ad1.ca_street_number b_street_number
# MAGIC      ,ad1.ca_street_name b_street_name
# MAGIC      ,ad1.ca_city b_city
# MAGIC      ,ad1.ca_zip b_zip
# MAGIC      ,ad2.ca_street_number c_street_number
# MAGIC      ,ad2.ca_street_name c_street_name
# MAGIC      ,ad2.ca_city c_city
# MAGIC      ,ad2.ca_zip c_zip
# MAGIC      ,d1.d_year as syear
# MAGIC      ,d2.d_year as fsyear
# MAGIC      ,d3.d_year s2year
# MAGIC      ,count(*) cnt
# MAGIC      ,sum(ss_wholesale_cost) s1
# MAGIC      ,sum(ss_list_price) s2
# MAGIC      ,sum(ss_coupon_amt) s3
# MAGIC   FROM   store_sales
# MAGIC         ,store_returns
# MAGIC         ,cs_ui
# MAGIC         ,date_dim d1
# MAGIC         ,date_dim d2
# MAGIC         ,date_dim d3
# MAGIC         ,store
# MAGIC         ,customer
# MAGIC         ,customer_demographics cd1
# MAGIC         ,customer_demographics cd2
# MAGIC         ,promotion
# MAGIC         ,household_demographics hd1
# MAGIC         ,household_demographics hd2
# MAGIC         ,customer_address ad1
# MAGIC         ,customer_address ad2
# MAGIC         ,income_band ib1
# MAGIC         ,income_band ib2
# MAGIC         ,item
# MAGIC   WHERE  ss_store_sk = s_store_sk AND
# MAGIC          ss_sold_date_sk = d1.d_date_sk AND
# MAGIC          ss_customer_sk = c_customer_sk AND
# MAGIC          ss_cdemo_sk= cd1.cd_demo_sk AND
# MAGIC          ss_hdemo_sk = hd1.hd_demo_sk AND
# MAGIC          ss_addr_sk = ad1.ca_address_sk and
# MAGIC          ss_item_sk = i_item_sk and
# MAGIC          ss_item_sk = sr_item_sk and
# MAGIC          ss_ticket_number = sr_ticket_number and
# MAGIC          ss_item_sk = cs_ui.cs_item_sk and
# MAGIC          c_current_cdemo_sk = cd2.cd_demo_sk AND
# MAGIC          c_current_hdemo_sk = hd2.hd_demo_sk AND
# MAGIC          c_current_addr_sk = ad2.ca_address_sk and
# MAGIC          c_first_sales_date_sk = d2.d_date_sk and
# MAGIC          c_first_shipto_date_sk = d3.d_date_sk and
# MAGIC          ss_promo_sk = p_promo_sk and
# MAGIC          hd1.hd_income_band_sk = ib1.ib_income_band_sk and
# MAGIC          hd2.hd_income_band_sk = ib2.ib_income_band_sk and
# MAGIC          cd1.cd_marital_status <> cd2.cd_marital_status and
# MAGIC          i_color in ('sky','burlywood','lavender','khaki','seashell','puff') and
# MAGIC          i_current_price between 61 and 61 + 10 and
# MAGIC          i_current_price between 61 + 1 and 61 + 15
# MAGIC group by i_product_name
# MAGIC        ,i_item_sk
# MAGIC        ,s_store_name
# MAGIC        ,s_zip
# MAGIC        ,ad1.ca_street_number
# MAGIC        ,ad1.ca_street_name
# MAGIC        ,ad1.ca_city
# MAGIC        ,ad1.ca_zip
# MAGIC        ,ad2.ca_street_number
# MAGIC        ,ad2.ca_street_name
# MAGIC        ,ad2.ca_city
# MAGIC        ,ad2.ca_zip
# MAGIC        ,d1.d_year
# MAGIC        ,d2.d_year
# MAGIC        ,d3.d_year
# MAGIC )
# MAGIC select cs1.product_name
# MAGIC      ,cs1.store_name
# MAGIC      ,cs1.store_zip
# MAGIC      ,cs1.b_street_number
# MAGIC      ,cs1.b_street_name
# MAGIC      ,cs1.b_city
# MAGIC      ,cs1.b_zip
# MAGIC      ,cs1.c_street_number
# MAGIC      ,cs1.c_street_name
# MAGIC      ,cs1.c_city
# MAGIC      ,cs1.c_zip
# MAGIC      ,cs1.syear  as syear1
# MAGIC      ,cs1.cnt as cnt1
# MAGIC      ,cs1.s1 as s11
# MAGIC      ,cs1.s2 as s21
# MAGIC      ,cs1.s3 as s31
# MAGIC      ,cs2.s1 as s12
# MAGIC      ,cs2.s2 as s22
# MAGIC      ,cs2.s3 as s32
# MAGIC      ,cs2.syear as syear2
# MAGIC      ,cs2.cnt as cnt2
# MAGIC from cross_sales cs1,cross_sales cs2
# MAGIC where cs1.item_sk=cs2.item_sk and
# MAGIC      cs1.syear = 2000 and
# MAGIC      cs2.syear = 2000 + 1 and
# MAGIC      cs2.cnt <= cs1.cnt and
# MAGIC      cs1.store_name = cs2.store_name and
# MAGIC      cs1.store_zip = cs2.store_zip
# MAGIC order by cs1.product_name
# MAGIC        ,cs1.store_name
# MAGIC        ,cs2.cnt
# MAGIC        ,cs1.s1
# MAGIC        ,cs2.s1

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q65.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select 
# MAGIC 	s_store_name,
# MAGIC 	i_item_desc,
# MAGIC 	sc.revenue,
# MAGIC 	i_current_price,
# MAGIC 	i_wholesale_cost,
# MAGIC 	i_brand
# MAGIC  from store, item,
# MAGIC      (select ss_store_sk, avg(revenue) as ave
# MAGIC  	from
# MAGIC  	    (select  ss_store_sk, ss_item_sk, 
# MAGIC  		     sum(ss_sales_price) as revenue
# MAGIC  		from store_sales, date_dim
# MAGIC  		where ss_sold_date_sk = d_date_sk and d_month_seq between 1216 and 1216+11
# MAGIC  		group by ss_store_sk, ss_item_sk) sa
# MAGIC  	group by ss_store_sk) sb,
# MAGIC      (select  ss_store_sk, ss_item_sk, sum(ss_sales_price) as revenue
# MAGIC  	from store_sales, date_dim
# MAGIC  	where ss_sold_date_sk = d_date_sk and d_month_seq between 1216 and 1216+11
# MAGIC  	group by ss_store_sk, ss_item_sk) sc
# MAGIC  where sb.ss_store_sk = sc.ss_store_sk and 
# MAGIC        sc.revenue <= 0.1 * sb.ave and
# MAGIC        s_store_sk = sc.ss_store_sk and
# MAGIC        i_item_sk = sc.ss_item_sk
# MAGIC  order by s_store_name, i_item_desc
# MAGIC limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q66.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select   
# MAGIC          w_warehouse_name
# MAGIC  	,w_warehouse_sq_ft
# MAGIC  	,w_city
# MAGIC  	,w_county
# MAGIC  	,w_state
# MAGIC  	,w_country
# MAGIC         ,ship_carriers
# MAGIC         ,year
# MAGIC  	,sum(jan_sales) as jan_sales
# MAGIC  	,sum(feb_sales) as feb_sales
# MAGIC  	,sum(mar_sales) as mar_sales
# MAGIC  	,sum(apr_sales) as apr_sales
# MAGIC  	,sum(may_sales) as may_sales
# MAGIC  	,sum(jun_sales) as jun_sales
# MAGIC  	,sum(jul_sales) as jul_sales
# MAGIC  	,sum(aug_sales) as aug_sales
# MAGIC  	,sum(sep_sales) as sep_sales
# MAGIC  	,sum(oct_sales) as oct_sales
# MAGIC  	,sum(nov_sales) as nov_sales
# MAGIC  	,sum(dec_sales) as dec_sales
# MAGIC  	,sum(jan_sales/w_warehouse_sq_ft) as jan_sales_per_sq_foot
# MAGIC  	,sum(feb_sales/w_warehouse_sq_ft) as feb_sales_per_sq_foot
# MAGIC  	,sum(mar_sales/w_warehouse_sq_ft) as mar_sales_per_sq_foot
# MAGIC  	,sum(apr_sales/w_warehouse_sq_ft) as apr_sales_per_sq_foot
# MAGIC  	,sum(may_sales/w_warehouse_sq_ft) as may_sales_per_sq_foot
# MAGIC  	,sum(jun_sales/w_warehouse_sq_ft) as jun_sales_per_sq_foot
# MAGIC  	,sum(jul_sales/w_warehouse_sq_ft) as jul_sales_per_sq_foot
# MAGIC  	,sum(aug_sales/w_warehouse_sq_ft) as aug_sales_per_sq_foot
# MAGIC  	,sum(sep_sales/w_warehouse_sq_ft) as sep_sales_per_sq_foot
# MAGIC  	,sum(oct_sales/w_warehouse_sq_ft) as oct_sales_per_sq_foot
# MAGIC  	,sum(nov_sales/w_warehouse_sq_ft) as nov_sales_per_sq_foot
# MAGIC  	,sum(dec_sales/w_warehouse_sq_ft) as dec_sales_per_sq_foot
# MAGIC  	,sum(jan_net) as jan_net
# MAGIC  	,sum(feb_net) as feb_net
# MAGIC  	,sum(mar_net) as mar_net
# MAGIC  	,sum(apr_net) as apr_net
# MAGIC  	,sum(may_net) as may_net
# MAGIC  	,sum(jun_net) as jun_net
# MAGIC  	,sum(jul_net) as jul_net
# MAGIC  	,sum(aug_net) as aug_net
# MAGIC  	,sum(sep_net) as sep_net
# MAGIC  	,sum(oct_net) as oct_net
# MAGIC  	,sum(nov_net) as nov_net
# MAGIC  	,sum(dec_net) as dec_net
# MAGIC  from (
# MAGIC      select 
# MAGIC  	w_warehouse_name
# MAGIC  	,w_warehouse_sq_ft
# MAGIC  	,w_city
# MAGIC  	,w_county
# MAGIC  	,w_state
# MAGIC  	,w_country
# MAGIC  	,'RUPEKSA' || ',' || 'ALLIANCE' as ship_carriers
# MAGIC        ,d_year as year
# MAGIC  	,sum(case when d_moy = 1 
# MAGIC  		then ws_ext_list_price* ws_quantity else 0 end) as jan_sales
# MAGIC  	,sum(case when d_moy = 2 
# MAGIC  		then ws_ext_list_price* ws_quantity else 0 end) as feb_sales
# MAGIC  	,sum(case when d_moy = 3 
# MAGIC  		then ws_ext_list_price* ws_quantity else 0 end) as mar_sales
# MAGIC  	,sum(case when d_moy = 4 
# MAGIC  		then ws_ext_list_price* ws_quantity else 0 end) as apr_sales
# MAGIC  	,sum(case when d_moy = 5 
# MAGIC  		then ws_ext_list_price* ws_quantity else 0 end) as may_sales
# MAGIC  	,sum(case when d_moy = 6 
# MAGIC  		then ws_ext_list_price* ws_quantity else 0 end) as jun_sales
# MAGIC  	,sum(case when d_moy = 7 
# MAGIC  		then ws_ext_list_price* ws_quantity else 0 end) as jul_sales
# MAGIC  	,sum(case when d_moy = 8 
# MAGIC  		then ws_ext_list_price* ws_quantity else 0 end) as aug_sales
# MAGIC  	,sum(case when d_moy = 9 
# MAGIC  		then ws_ext_list_price* ws_quantity else 0 end) as sep_sales
# MAGIC  	,sum(case when d_moy = 10 
# MAGIC  		then ws_ext_list_price* ws_quantity else 0 end) as oct_sales
# MAGIC  	,sum(case when d_moy = 11
# MAGIC  		then ws_ext_list_price* ws_quantity else 0 end) as nov_sales
# MAGIC  	,sum(case when d_moy = 12
# MAGIC  		then ws_ext_list_price* ws_quantity else 0 end) as dec_sales
# MAGIC  	,sum(case when d_moy = 1 
# MAGIC  		then ws_net_paid_inc_ship * ws_quantity else 0 end) as jan_net
# MAGIC  	,sum(case when d_moy = 2
# MAGIC  		then ws_net_paid_inc_ship * ws_quantity else 0 end) as feb_net
# MAGIC  	,sum(case when d_moy = 3 
# MAGIC  		then ws_net_paid_inc_ship * ws_quantity else 0 end) as mar_net
# MAGIC  	,sum(case when d_moy = 4 
# MAGIC  		then ws_net_paid_inc_ship * ws_quantity else 0 end) as apr_net
# MAGIC  	,sum(case when d_moy = 5 
# MAGIC  		then ws_net_paid_inc_ship * ws_quantity else 0 end) as may_net
# MAGIC  	,sum(case when d_moy = 6 
# MAGIC  		then ws_net_paid_inc_ship * ws_quantity else 0 end) as jun_net
# MAGIC  	,sum(case when d_moy = 7 
# MAGIC  		then ws_net_paid_inc_ship * ws_quantity else 0 end) as jul_net
# MAGIC  	,sum(case when d_moy = 8 
# MAGIC  		then ws_net_paid_inc_ship * ws_quantity else 0 end) as aug_net
# MAGIC  	,sum(case when d_moy = 9 
# MAGIC  		then ws_net_paid_inc_ship * ws_quantity else 0 end) as sep_net
# MAGIC  	,sum(case when d_moy = 10 
# MAGIC  		then ws_net_paid_inc_ship * ws_quantity else 0 end) as oct_net
# MAGIC  	,sum(case when d_moy = 11
# MAGIC  		then ws_net_paid_inc_ship * ws_quantity else 0 end) as nov_net
# MAGIC  	,sum(case when d_moy = 12
# MAGIC  		then ws_net_paid_inc_ship * ws_quantity else 0 end) as dec_net
# MAGIC      from
# MAGIC           web_sales
# MAGIC          ,warehouse
# MAGIC          ,date_dim
# MAGIC          ,time_dim
# MAGIC  	  ,ship_mode
# MAGIC      where
# MAGIC             ws_warehouse_sk =  w_warehouse_sk
# MAGIC         and ws_sold_date_sk = d_date_sk
# MAGIC         and ws_sold_time_sk = t_time_sk
# MAGIC  	and ws_ship_mode_sk = sm_ship_mode_sk
# MAGIC         and d_year = 2002
# MAGIC  	and t_time between 2208 and 2208+28800 
# MAGIC  	and sm_carrier in ('RUPEKSA','ALLIANCE')
# MAGIC      group by 
# MAGIC         w_warehouse_name
# MAGIC  	,w_warehouse_sq_ft
# MAGIC  	,w_city
# MAGIC  	,w_county
# MAGIC  	,w_state
# MAGIC  	,w_country
# MAGIC        ,d_year
# MAGIC  union all
# MAGIC      select 
# MAGIC  	w_warehouse_name
# MAGIC  	,w_warehouse_sq_ft
# MAGIC  	,w_city
# MAGIC  	,w_county
# MAGIC  	,w_state
# MAGIC  	,w_country
# MAGIC  	,'RUPEKSA' || ',' || 'ALLIANCE' as ship_carriers
# MAGIC        ,d_year as year
# MAGIC  	,sum(case when d_moy = 1 
# MAGIC  		then cs_ext_sales_price* cs_quantity else 0 end) as jan_sales
# MAGIC  	,sum(case when d_moy = 2 
# MAGIC  		then cs_ext_sales_price* cs_quantity else 0 end) as feb_sales
# MAGIC  	,sum(case when d_moy = 3 
# MAGIC  		then cs_ext_sales_price* cs_quantity else 0 end) as mar_sales
# MAGIC  	,sum(case when d_moy = 4 
# MAGIC  		then cs_ext_sales_price* cs_quantity else 0 end) as apr_sales
# MAGIC  	,sum(case when d_moy = 5 
# MAGIC  		then cs_ext_sales_price* cs_quantity else 0 end) as may_sales
# MAGIC  	,sum(case when d_moy = 6 
# MAGIC  		then cs_ext_sales_price* cs_quantity else 0 end) as jun_sales
# MAGIC  	,sum(case when d_moy = 7 
# MAGIC  		then cs_ext_sales_price* cs_quantity else 0 end) as jul_sales
# MAGIC  	,sum(case when d_moy = 8 
# MAGIC  		then cs_ext_sales_price* cs_quantity else 0 end) as aug_sales
# MAGIC  	,sum(case when d_moy = 9 
# MAGIC  		then cs_ext_sales_price* cs_quantity else 0 end) as sep_sales
# MAGIC  	,sum(case when d_moy = 10 
# MAGIC  		then cs_ext_sales_price* cs_quantity else 0 end) as oct_sales
# MAGIC  	,sum(case when d_moy = 11
# MAGIC  		then cs_ext_sales_price* cs_quantity else 0 end) as nov_sales
# MAGIC  	,sum(case when d_moy = 12
# MAGIC  		then cs_ext_sales_price* cs_quantity else 0 end) as dec_sales
# MAGIC  	,sum(case when d_moy = 1 
# MAGIC  		then cs_net_paid * cs_quantity else 0 end) as jan_net
# MAGIC  	,sum(case when d_moy = 2 
# MAGIC  		then cs_net_paid * cs_quantity else 0 end) as feb_net
# MAGIC  	,sum(case when d_moy = 3 
# MAGIC  		then cs_net_paid * cs_quantity else 0 end) as mar_net
# MAGIC  	,sum(case when d_moy = 4 
# MAGIC  		then cs_net_paid * cs_quantity else 0 end) as apr_net
# MAGIC  	,sum(case when d_moy = 5 
# MAGIC  		then cs_net_paid * cs_quantity else 0 end) as may_net
# MAGIC  	,sum(case when d_moy = 6 
# MAGIC  		then cs_net_paid * cs_quantity else 0 end) as jun_net
# MAGIC  	,sum(case when d_moy = 7 
# MAGIC  		then cs_net_paid * cs_quantity else 0 end) as jul_net
# MAGIC  	,sum(case when d_moy = 8 
# MAGIC  		then cs_net_paid * cs_quantity else 0 end) as aug_net
# MAGIC  	,sum(case when d_moy = 9 
# MAGIC  		then cs_net_paid * cs_quantity else 0 end) as sep_net
# MAGIC  	,sum(case when d_moy = 10 
# MAGIC  		then cs_net_paid * cs_quantity else 0 end) as oct_net
# MAGIC  	,sum(case when d_moy = 11
# MAGIC  		then cs_net_paid * cs_quantity else 0 end) as nov_net
# MAGIC  	,sum(case when d_moy = 12
# MAGIC  		then cs_net_paid * cs_quantity else 0 end) as dec_net
# MAGIC      from
# MAGIC           catalog_sales
# MAGIC          ,warehouse
# MAGIC          ,date_dim
# MAGIC          ,time_dim
# MAGIC  	 ,ship_mode
# MAGIC      where
# MAGIC             cs_warehouse_sk =  w_warehouse_sk
# MAGIC         and cs_sold_date_sk = d_date_sk
# MAGIC         and cs_sold_time_sk = t_time_sk
# MAGIC  	and cs_ship_mode_sk = sm_ship_mode_sk
# MAGIC         and d_year = 2002
# MAGIC  	and t_time between 2208 AND 2208+28800 
# MAGIC  	and sm_carrier in ('RUPEKSA','ALLIANCE')
# MAGIC      group by 
# MAGIC         w_warehouse_name
# MAGIC  	,w_warehouse_sq_ft
# MAGIC  	,w_city
# MAGIC  	,w_county
# MAGIC  	,w_state
# MAGIC  	,w_country
# MAGIC        ,d_year
# MAGIC  ) x
# MAGIC  group by 
# MAGIC         w_warehouse_name
# MAGIC  	,w_warehouse_sq_ft
# MAGIC  	,w_city
# MAGIC  	,w_county
# MAGIC  	,w_state
# MAGIC  	,w_country
# MAGIC  	,ship_carriers
# MAGIC        ,year
# MAGIC  order by w_warehouse_name
# MAGIC  limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q67.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  *
# MAGIC from (select i_category
# MAGIC             ,i_class
# MAGIC             ,i_brand
# MAGIC             ,i_product_name
# MAGIC             ,d_year
# MAGIC             ,d_qoy
# MAGIC             ,d_moy
# MAGIC             ,s_store_id
# MAGIC             ,sumsales
# MAGIC             ,rank() over (partition by i_category order by sumsales desc) rk
# MAGIC       from (select i_category
# MAGIC                   ,i_class
# MAGIC                   ,i_brand
# MAGIC                   ,i_product_name
# MAGIC                   ,d_year
# MAGIC                   ,d_qoy
# MAGIC                   ,d_moy
# MAGIC                   ,s_store_id
# MAGIC                   ,sum(coalesce(ss_sales_price*ss_quantity,0)) sumsales
# MAGIC             from store_sales
# MAGIC                 ,date_dim
# MAGIC                 ,store
# MAGIC                 ,item
# MAGIC        where  ss_sold_date_sk=d_date_sk
# MAGIC           and ss_item_sk=i_item_sk
# MAGIC           and ss_store_sk = s_store_sk
# MAGIC           and d_month_seq between 1189 and 1189+11
# MAGIC        group by  rollup(i_category, i_class, i_brand, i_product_name, d_year, d_qoy, d_moy,s_store_id))dw1) dw2
# MAGIC where rk <= 100
# MAGIC order by i_category
# MAGIC         ,i_class
# MAGIC         ,i_brand
# MAGIC         ,i_product_name
# MAGIC         ,d_year
# MAGIC         ,d_qoy
# MAGIC         ,d_moy
# MAGIC         ,s_store_id
# MAGIC         ,sumsales
# MAGIC         ,rk
# MAGIC limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q68.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  c_last_name
# MAGIC        ,c_first_name
# MAGIC        ,ca_city
# MAGIC        ,bought_city
# MAGIC        ,ss_ticket_number
# MAGIC        ,extended_price
# MAGIC        ,extended_tax
# MAGIC        ,list_price
# MAGIC  from (select ss_ticket_number
# MAGIC              ,ss_customer_sk
# MAGIC              ,ca_city bought_city
# MAGIC              ,sum(ss_ext_sales_price) extended_price 
# MAGIC              ,sum(ss_ext_list_price) list_price
# MAGIC              ,sum(ss_ext_tax) extended_tax 
# MAGIC        from store_sales
# MAGIC            ,date_dim
# MAGIC            ,store
# MAGIC            ,household_demographics
# MAGIC            ,customer_address 
# MAGIC        where store_sales.ss_sold_date_sk = date_dim.d_date_sk
# MAGIC          and store_sales.ss_store_sk = store.s_store_sk  
# MAGIC         and store_sales.ss_hdemo_sk = household_demographics.hd_demo_sk
# MAGIC         and store_sales.ss_addr_sk = customer_address.ca_address_sk
# MAGIC         and date_dim.d_dom between 1 and 2 
# MAGIC         and (household_demographics.hd_dep_count = 7 or
# MAGIC              household_demographics.hd_vehicle_count= 0)
# MAGIC         and date_dim.d_year in (1998,1998+1,1998+2)
# MAGIC         and store.s_city in ('Spring Hill','Russellville')
# MAGIC        group by ss_ticket_number
# MAGIC                ,ss_customer_sk
# MAGIC                ,ss_addr_sk,ca_city) dn
# MAGIC       ,customer
# MAGIC       ,customer_address current_addr
# MAGIC  where ss_customer_sk = c_customer_sk
# MAGIC    and customer.c_current_addr_sk = current_addr.ca_address_sk
# MAGIC    and current_addr.ca_city <> bought_city
# MAGIC  order by c_last_name
# MAGIC          ,ss_ticket_number
# MAGIC  limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q69.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  
# MAGIC   cd_gender,
# MAGIC   cd_marital_status,
# MAGIC   cd_education_status,
# MAGIC   count(*) cnt1,
# MAGIC   cd_purchase_estimate,
# MAGIC   count(*) cnt2,
# MAGIC   cd_credit_rating,
# MAGIC   count(*) cnt3
# MAGIC  from
# MAGIC   customer c,customer_address ca,customer_demographics
# MAGIC  where
# MAGIC   c.c_current_addr_sk = ca.ca_address_sk and
# MAGIC   ca_state in ('GA','CO','OH') and
# MAGIC   cd_demo_sk = c.c_current_cdemo_sk and 
# MAGIC   exists (select *
# MAGIC           from store_sales,date_dim
# MAGIC           where c.c_customer_sk = ss_customer_sk and
# MAGIC                 ss_sold_date_sk = d_date_sk and
# MAGIC                 d_year = 2004 and
# MAGIC                 d_moy between 4 and 4+2) and
# MAGIC    (not exists (select *
# MAGIC             from web_sales,date_dim
# MAGIC             where c.c_customer_sk = ws_bill_customer_sk and
# MAGIC                   ws_sold_date_sk = d_date_sk and
# MAGIC                   d_year = 2004 and
# MAGIC                   d_moy between 4 and 4+2) and
# MAGIC     not exists (select * 
# MAGIC             from catalog_sales,date_dim
# MAGIC             where c.c_customer_sk = cs_ship_customer_sk and
# MAGIC                   cs_sold_date_sk = d_date_sk and
# MAGIC                   d_year = 2004 and
# MAGIC                   d_moy between 4 and 4+2))
# MAGIC  group by cd_gender,
# MAGIC           cd_marital_status,
# MAGIC           cd_education_status,
# MAGIC           cd_purchase_estimate,
# MAGIC           cd_credit_rating
# MAGIC  order by cd_gender,
# MAGIC           cd_marital_status,
# MAGIC           cd_education_status,
# MAGIC           cd_purchase_estimate,
# MAGIC           cd_credit_rating
# MAGIC  limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q70.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  
# MAGIC     sum(ss_net_profit) as total_sum
# MAGIC    ,s_state
# MAGIC    ,s_county
# MAGIC    ,grouping(s_state)+grouping(s_county) as lochierarchy
# MAGIC    ,rank() over (
# MAGIC  	partition by grouping(s_state)+grouping(s_county),
# MAGIC  	case when grouping(s_county) = 0 then s_state end 
# MAGIC  	order by sum(ss_net_profit) desc) as rank_within_parent
# MAGIC  from
# MAGIC     store_sales
# MAGIC    ,date_dim       d1
# MAGIC    ,store
# MAGIC  where
# MAGIC     d1.d_month_seq between 1185 and 1185+11
# MAGIC  and d1.d_date_sk = ss_sold_date_sk
# MAGIC  and s_store_sk  = ss_store_sk
# MAGIC  and s_state in
# MAGIC              ( select s_state
# MAGIC                from  (select s_state as s_state,
# MAGIC  			    rank() over ( partition by s_state order by sum(ss_net_profit) desc) as ranking
# MAGIC                       from   store_sales, store, date_dim
# MAGIC                       where  d_month_seq between 1185 and 1185+11
# MAGIC  			    and d_date_sk = ss_sold_date_sk
# MAGIC  			    and s_store_sk  = ss_store_sk
# MAGIC                       group by s_state
# MAGIC                      ) tmp1 
# MAGIC                where ranking <= 5
# MAGIC              )
# MAGIC  group by rollup(s_state,s_county)
# MAGIC  order by
# MAGIC    lochierarchy desc
# MAGIC   ,case when lochierarchy = 0 then s_state end
# MAGIC   ,rank_within_parent
# MAGIC  limit 100