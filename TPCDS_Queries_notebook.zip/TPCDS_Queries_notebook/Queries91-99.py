# Databricks notebook source
# MAGIC %sql
# MAGIC use catalog tpcds;
# MAGIC use schema tpcds_sf1000_delta_lc;
# MAGIC set use_cached_result = false;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q91.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  
# MAGIC         cc_call_center_id Call_Center,
# MAGIC         cc_name Call_Center_Name,
# MAGIC         cc_manager Manager,
# MAGIC         sum(cr_net_loss) Returns_Loss
# MAGIC from
# MAGIC         call_center,
# MAGIC         catalog_returns,
# MAGIC         date_dim,
# MAGIC         customer,
# MAGIC         customer_address,
# MAGIC         customer_demographics,
# MAGIC         household_demographics
# MAGIC where
# MAGIC         cr_call_center_sk       = cc_call_center_sk
# MAGIC and     cr_returned_date_sk     = d_date_sk
# MAGIC and     cr_returning_customer_sk= c_customer_sk
# MAGIC and     cd_demo_sk              = c_current_cdemo_sk
# MAGIC and     hd_demo_sk              = c_current_hdemo_sk
# MAGIC and     ca_address_sk           = c_current_addr_sk
# MAGIC and     d_year                  = 1999 
# MAGIC and     d_moy                   = 12
# MAGIC and     ( (cd_marital_status       = 'M' and cd_education_status     = 'Unknown')
# MAGIC         or(cd_marital_status       = 'W' and cd_education_status     = 'Advanced Degree'))
# MAGIC and     hd_buy_potential like '501-1000%'
# MAGIC and     ca_gmt_offset           = -7
# MAGIC group by cc_call_center_id,cc_name,cc_manager,cd_marital_status,cd_education_status
# MAGIC order by sum(cr_net_loss) desc

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q92.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  
# MAGIC    sum(ws_ext_discount_amt)  as `Excess Discount Amount` 
# MAGIC from 
# MAGIC     web_sales 
# MAGIC    ,item 
# MAGIC    ,date_dim
# MAGIC where
# MAGIC i_manufact_id = 382
# MAGIC and i_item_sk = ws_item_sk 
# MAGIC and d_date between '2002-02-07' and 
# MAGIC         date_add(cast('2002-02-07' as date),90)
# MAGIC and d_date_sk = ws_sold_date_sk 
# MAGIC and ws_ext_discount_amt  
# MAGIC      > ( 
# MAGIC          SELECT 
# MAGIC             1.3 * avg(ws_ext_discount_amt) 
# MAGIC          FROM 
# MAGIC             web_sales 
# MAGIC            ,date_dim
# MAGIC          WHERE 
# MAGIC               ws_item_sk = i_item_sk 
# MAGIC           and d_date between '2002-02-07' and
# MAGIC                              date_add(cast('2002-02-07' as date),90)
# MAGIC           and d_date_sk = ws_sold_date_sk 
# MAGIC       ) 
# MAGIC order by sum(ws_ext_discount_amt)
# MAGIC limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q93.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  ss_customer_sk
# MAGIC             ,sum(act_sales) sumsales
# MAGIC       from (select ss_item_sk
# MAGIC                   ,ss_ticket_number
# MAGIC                   ,ss_customer_sk
# MAGIC                   ,case when sr_return_quantity is not null then (ss_quantity-sr_return_quantity)*ss_sales_price
# MAGIC                                                             else (ss_quantity*ss_sales_price) end act_sales
# MAGIC             from store_sales left outer join store_returns on (sr_item_sk = ss_item_sk
# MAGIC                                                                and sr_ticket_number = ss_ticket_number)
# MAGIC                 ,reason
# MAGIC             where sr_reason_sk = r_reason_sk
# MAGIC               and r_reason_desc = 'reason 43') t
# MAGIC       group by ss_customer_sk
# MAGIC       order by sumsales, ss_customer_sk
# MAGIC limit 100
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q94.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  
# MAGIC    count(distinct ws_order_number) as `order count`
# MAGIC   ,sum(ws_ext_ship_cost) as `total shipping cost`
# MAGIC   ,sum(ws_net_profit) as `total net profit`
# MAGIC from
# MAGIC    web_sales ws1
# MAGIC   ,date_dim
# MAGIC   ,customer_address
# MAGIC   ,web_site
# MAGIC where
# MAGIC     d_date between '2001-4-01' and 
# MAGIC            date_add(cast('2001-4-01' as date),60)
# MAGIC and ws1.ws_ship_date_sk = d_date_sk
# MAGIC and ws1.ws_ship_addr_sk = ca_address_sk
# MAGIC and ca_state = 'AL'
# MAGIC and ws1.ws_web_site_sk = web_site_sk
# MAGIC and web_company_name = 'pri'
# MAGIC and exists (select *
# MAGIC             from web_sales ws2
# MAGIC             where ws1.ws_order_number = ws2.ws_order_number
# MAGIC               and ws1.ws_warehouse_sk <> ws2.ws_warehouse_sk)
# MAGIC and not exists(select *
# MAGIC                from web_returns wr1
# MAGIC                where ws1.ws_order_number = wr1.wr_order_number)
# MAGIC order by count(distinct ws_order_number)
# MAGIC limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q95.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC with ws_wh as
# MAGIC (select ws1.ws_order_number,ws1.ws_warehouse_sk wh1,ws2.ws_warehouse_sk wh2
# MAGIC  from web_sales ws1,web_sales ws2
# MAGIC  where ws1.ws_order_number = ws2.ws_order_number
# MAGIC    and ws1.ws_warehouse_sk <> ws2.ws_warehouse_sk)
# MAGIC  select  
# MAGIC    count(distinct ws_order_number) as `order count`
# MAGIC   ,sum(ws_ext_ship_cost) as `total shipping cost`
# MAGIC   ,sum(ws_net_profit) as `total net profit`
# MAGIC from
# MAGIC    web_sales ws1
# MAGIC   ,date_dim
# MAGIC   ,customer_address
# MAGIC   ,web_site
# MAGIC where
# MAGIC     d_date between '2001-2-01' and 
# MAGIC            date_add(cast('2001-2-01' as date),60)
# MAGIC and ws1.ws_ship_date_sk = d_date_sk
# MAGIC and ws1.ws_ship_addr_sk = ca_address_sk
# MAGIC and ca_state = 'OH'
# MAGIC and ws1.ws_web_site_sk = web_site_sk
# MAGIC and web_company_name = 'pri'
# MAGIC and ws1.ws_order_number in (select ws_order_number
# MAGIC                             from ws_wh)
# MAGIC and ws1.ws_order_number in (select wr_order_number
# MAGIC                             from web_returns,ws_wh
# MAGIC                             where wr_order_number = ws_wh.ws_order_number)
# MAGIC order by count(distinct ws_order_number)
# MAGIC limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q96.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  count(*) 
# MAGIC from store_sales
# MAGIC     ,household_demographics 
# MAGIC     ,time_dim, store
# MAGIC where ss_sold_time_sk = time_dim.t_time_sk   
# MAGIC     and ss_hdemo_sk = household_demographics.hd_demo_sk 
# MAGIC     and ss_store_sk = s_store_sk
# MAGIC     and time_dim.t_hour = 8
# MAGIC     and time_dim.t_minute >= 30
# MAGIC     and household_demographics.hd_dep_count = 7
# MAGIC     and store.s_store_name = 'ese'
# MAGIC order by count(*)
# MAGIC limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q97.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC with ssci as (
# MAGIC   select
# MAGIC     ss_customer_sk customer_sk,
# MAGIC     ss_item_sk item_sk
# MAGIC   from
# MAGIC     store_sales,
# MAGIC     date_dim
# MAGIC   where
# MAGIC     ss_sold_date_sk = d_date_sk
# MAGIC     and d_month_seq between 1208
# MAGIC     and 1208 + 11
# MAGIC   group by
# MAGIC     ss_customer_sk,
# MAGIC     ss_item_sk
# MAGIC ),
# MAGIC csci as(
# MAGIC   select
# MAGIC     cs_bill_customer_sk customer_sk,
# MAGIC     cs_item_sk item_sk
# MAGIC   from
# MAGIC     catalog_sales,
# MAGIC     date_dim
# MAGIC   where
# MAGIC     cs_sold_date_sk = d_date_sk
# MAGIC     and d_month_seq between 1208
# MAGIC     and 1208 + 11
# MAGIC   group by
# MAGIC     cs_bill_customer_sk,
# MAGIC     cs_item_sk
# MAGIC )
# MAGIC select
# MAGIC   sum(
# MAGIC     case
# MAGIC       when ssci.customer_sk is not null
# MAGIC       and csci.customer_sk is null then 1
# MAGIC       else 0
# MAGIC     end
# MAGIC   ) store_only,
# MAGIC   sum(
# MAGIC     case
# MAGIC       when ssci.customer_sk is null
# MAGIC       and csci.customer_sk is not null then 1
# MAGIC       else 0
# MAGIC     end
# MAGIC   ) catalog_only,
# MAGIC   sum(
# MAGIC     case
# MAGIC       when ssci.customer_sk is not null
# MAGIC       and csci.customer_sk is not null then 1
# MAGIC       else 0
# MAGIC     end
# MAGIC   ) store_and_catalog
# MAGIC from
# MAGIC   ssci full
# MAGIC   outer join csci on (
# MAGIC     ssci.customer_sk = csci.customer_sk
# MAGIC     and ssci.item_sk = csci.item_sk
# MAGIC   )
# MAGIC limit
# MAGIC   100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q98.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select i_item_id
# MAGIC       ,i_item_desc 
# MAGIC       ,i_category 
# MAGIC       ,i_class 
# MAGIC       ,i_current_price
# MAGIC       ,sum(ss_ext_sales_price) as itemrevenue 
# MAGIC       ,sum(ss_ext_sales_price)*100/sum(sum(ss_ext_sales_price)) over
# MAGIC           (partition by i_class) as revenueratio
# MAGIC from	
# MAGIC 	store_sales
# MAGIC     	,item 
# MAGIC     	,date_dim
# MAGIC where 
# MAGIC 	ss_item_sk = i_item_sk 
# MAGIC   	and i_category in ('Books', 'Children', 'Sports')
# MAGIC   	and ss_sold_date_sk = d_date_sk
# MAGIC 	and d_date between cast('1998-06-19' as date) 
# MAGIC 				and date_add(cast('1998-06-19' as date),30)
# MAGIC group by 
# MAGIC 	i_item_id
# MAGIC         ,i_item_desc 
# MAGIC         ,i_category
# MAGIC         ,i_class
# MAGIC         ,i_current_price
# MAGIC order by 
# MAGIC 	i_category
# MAGIC         ,i_class
# MAGIC         ,i_item_id
# MAGIC         ,i_item_desc
# MAGIC         ,revenueratio
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q99.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  
# MAGIC    substr(w_warehouse_name,1,20)
# MAGIC   ,sm_type
# MAGIC   ,cc_name
# MAGIC   ,sum(case when (cs_ship_date_sk - cs_sold_date_sk <= 30 ) then 1 else 0 end)  as `30 days` 
# MAGIC   ,sum(case when (cs_ship_date_sk - cs_sold_date_sk > 30) and 
# MAGIC                  (cs_ship_date_sk - cs_sold_date_sk <= 60) then 1 else 0 end )  as `31-60 days` 
# MAGIC   ,sum(case when (cs_ship_date_sk - cs_sold_date_sk > 60) and 
# MAGIC                  (cs_ship_date_sk - cs_sold_date_sk <= 90) then 1 else 0 end)  as `61-90 days` 
# MAGIC   ,sum(case when (cs_ship_date_sk - cs_sold_date_sk > 90) and
# MAGIC                  (cs_ship_date_sk - cs_sold_date_sk <= 120) then 1 else 0 end)  as `91-120 days` 
# MAGIC   ,sum(case when (cs_ship_date_sk - cs_sold_date_sk  > 120) then 1 else 0 end)  as `>120 days` 
# MAGIC from
# MAGIC    catalog_sales
# MAGIC   ,warehouse
# MAGIC   ,ship_mode
# MAGIC   ,call_center
# MAGIC   ,date_dim
# MAGIC where
# MAGIC     d_month_seq between 1190 and 1190 + 11
# MAGIC and cs_ship_date_sk   = d_date_sk
# MAGIC and cs_warehouse_sk   = w_warehouse_sk
# MAGIC and cs_ship_mode_sk   = sm_ship_mode_sk
# MAGIC and cs_call_center_sk = cc_call_center_sk
# MAGIC group by
# MAGIC    substr(w_warehouse_name,1,20)
# MAGIC   ,sm_type
# MAGIC   ,cc_name
# MAGIC order by substr(w_warehouse_name,1,20)
# MAGIC         ,sm_type
# MAGIC         ,cc_name
# MAGIC limit 100
# MAGIC