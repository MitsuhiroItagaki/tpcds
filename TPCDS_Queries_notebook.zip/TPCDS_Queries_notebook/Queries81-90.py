# Databricks notebook source
# MAGIC %sql
# MAGIC use catalog tpcds;
# MAGIC use schema tpcds_sf1000_delta_lc;
# MAGIC set use_cached_result = false;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q81.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC with customer_total_return as
# MAGIC  (select cr_returning_customer_sk as ctr_customer_sk
# MAGIC         ,ca_state as ctr_state, 
# MAGIC  	sum(cr_return_amt_inc_tax) as ctr_total_return
# MAGIC  from catalog_returns
# MAGIC      ,date_dim
# MAGIC      ,customer_address
# MAGIC  where cr_returned_date_sk = d_date_sk 
# MAGIC    and d_year =2002
# MAGIC    and cr_returning_addr_sk = ca_address_sk 
# MAGIC  group by cr_returning_customer_sk
# MAGIC          ,ca_state )
# MAGIC   select  c_customer_id,c_salutation,c_first_name,c_last_name,ca_street_number,ca_street_name
# MAGIC                    ,ca_street_type,ca_suite_number,ca_city,ca_county,ca_state,ca_zip,ca_country,ca_gmt_offset
# MAGIC                   ,ca_location_type,ctr_total_return
# MAGIC  from customer_total_return ctr1
# MAGIC      ,customer_address
# MAGIC      ,customer
# MAGIC  where ctr1.ctr_total_return > (select avg(ctr_total_return)*1.2
# MAGIC  			  from customer_total_return ctr2 
# MAGIC                   	  where ctr1.ctr_state = ctr2.ctr_state)
# MAGIC        and ca_address_sk = c_current_addr_sk
# MAGIC        and ca_state = 'WY'
# MAGIC        and ctr1.ctr_customer_sk = c_customer_sk
# MAGIC  order by c_customer_id,c_salutation,c_first_name,c_last_name,ca_street_number,ca_street_name
# MAGIC                    ,ca_street_type,ca_suite_number,ca_city,ca_county,ca_state,ca_zip,ca_country,ca_gmt_offset
# MAGIC                   ,ca_location_type,ctr_total_return
# MAGIC  limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q82.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  i_item_id
# MAGIC        ,i_item_desc
# MAGIC        ,i_current_price
# MAGIC  from item, inventory, date_dim, store_sales
# MAGIC  where i_current_price between 34 and 34+30
# MAGIC  and inv_item_sk = i_item_sk
# MAGIC  and d_date_sk=inv_date_sk
# MAGIC  and d_date between cast('2002-03-15' as date) and date_add(cast('2002-03-15' as date),60)
# MAGIC  and i_manufact_id in (448,377,708,504)
# MAGIC  and inv_quantity_on_hand between 100 and 500
# MAGIC  and ss_item_sk = i_item_sk
# MAGIC  group by i_item_id,i_item_desc,i_current_price
# MAGIC  order by i_item_id
# MAGIC  limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q83.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC with sr_items as
# MAGIC  (select i_item_id item_id,
# MAGIC         sum(sr_return_quantity) sr_item_qty
# MAGIC  from store_returns,
# MAGIC       item,
# MAGIC       date_dim
# MAGIC  where sr_item_sk = i_item_sk
# MAGIC  and   d_date    in 
# MAGIC 	(select d_date
# MAGIC 	from date_dim
# MAGIC 	where d_week_seq in 
# MAGIC 		(select d_week_seq
# MAGIC 		from date_dim
# MAGIC 	  where d_date in ('2002-02-11','2002-08-16','2002-11-20')))
# MAGIC  and   sr_returned_date_sk   = d_date_sk
# MAGIC  group by i_item_id),
# MAGIC  cr_items as
# MAGIC  (select i_item_id item_id,
# MAGIC         sum(cr_return_quantity) cr_item_qty
# MAGIC  from catalog_returns,
# MAGIC       item,
# MAGIC       date_dim
# MAGIC  where cr_item_sk = i_item_sk
# MAGIC  and   d_date    in 
# MAGIC 	(select d_date
# MAGIC 	from date_dim
# MAGIC 	where d_week_seq in 
# MAGIC 		(select d_week_seq
# MAGIC 		from date_dim
# MAGIC 	  where d_date in ('2002-02-11','2002-08-16','2002-11-20')))
# MAGIC  and   cr_returned_date_sk   = d_date_sk
# MAGIC  group by i_item_id),
# MAGIC  wr_items as
# MAGIC  (select i_item_id item_id,
# MAGIC         sum(wr_return_quantity) wr_item_qty
# MAGIC  from web_returns,
# MAGIC       item,
# MAGIC       date_dim
# MAGIC  where wr_item_sk = i_item_sk
# MAGIC  and   d_date    in 
# MAGIC 	(select d_date
# MAGIC 	from date_dim
# MAGIC 	where d_week_seq in 
# MAGIC 		(select d_week_seq
# MAGIC 		from date_dim
# MAGIC 		where d_date in ('2002-02-11','2002-08-16','2002-11-20')))
# MAGIC  and   wr_returned_date_sk   = d_date_sk
# MAGIC  group by i_item_id)
# MAGIC   select  sr_items.item_id
# MAGIC        ,sr_item_qty
# MAGIC        ,sr_item_qty/(sr_item_qty+cr_item_qty+wr_item_qty)/3.0 * 100 sr_dev
# MAGIC        ,cr_item_qty
# MAGIC        ,cr_item_qty/(sr_item_qty+cr_item_qty+wr_item_qty)/3.0 * 100 cr_dev
# MAGIC        ,wr_item_qty
# MAGIC        ,wr_item_qty/(sr_item_qty+cr_item_qty+wr_item_qty)/3.0 * 100 wr_dev
# MAGIC        ,(sr_item_qty+cr_item_qty+wr_item_qty)/3.0 average
# MAGIC  from sr_items
# MAGIC      ,cr_items
# MAGIC      ,wr_items
# MAGIC  where sr_items.item_id=cr_items.item_id
# MAGIC    and sr_items.item_id=wr_items.item_id 
# MAGIC  order by sr_items.item_id
# MAGIC          ,sr_item_qty
# MAGIC  limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q84.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  c_customer_id as customer_id
# MAGIC        , coalesce(c_last_name,'') || ', ' || coalesce(c_first_name,'') as customername
# MAGIC  from customer
# MAGIC      ,customer_address
# MAGIC      ,customer_demographics
# MAGIC      ,household_demographics
# MAGIC      ,income_band
# MAGIC      ,store_returns
# MAGIC  where ca_city	        =  'Woodville'
# MAGIC    and c_current_addr_sk = ca_address_sk
# MAGIC    and ib_lower_bound   >=  9512
# MAGIC    and ib_upper_bound   <=  9512 + 50000
# MAGIC    and ib_income_band_sk = hd_income_band_sk
# MAGIC    and cd_demo_sk = c_current_cdemo_sk
# MAGIC    and hd_demo_sk = c_current_hdemo_sk
# MAGIC    and sr_cdemo_sk = cd_demo_sk
# MAGIC  order by c_customer_id
# MAGIC  limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q85.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  substr(r_reason_desc,1,20)
# MAGIC        ,avg(ws_quantity)
# MAGIC        ,avg(wr_refunded_cash)
# MAGIC        ,avg(wr_fee)
# MAGIC  from web_sales, web_returns, web_page, customer_demographics cd1,
# MAGIC       customer_demographics cd2, customer_address, date_dim, reason 
# MAGIC  where ws_web_page_sk = wp_web_page_sk
# MAGIC    and ws_item_sk = wr_item_sk
# MAGIC    and ws_order_number = wr_order_number
# MAGIC    and ws_sold_date_sk = d_date_sk and d_year = 2002
# MAGIC    and cd1.cd_demo_sk = wr_refunded_cdemo_sk 
# MAGIC    and cd2.cd_demo_sk = wr_returning_cdemo_sk
# MAGIC    and ca_address_sk = wr_refunded_addr_sk
# MAGIC    and r_reason_sk = wr_reason_sk
# MAGIC    and
# MAGIC    (
# MAGIC     (
# MAGIC      cd1.cd_marital_status = 'U'
# MAGIC      and
# MAGIC      cd1.cd_marital_status = cd2.cd_marital_status
# MAGIC      and
# MAGIC      cd1.cd_education_status = 'Unknown'
# MAGIC      and 
# MAGIC      cd1.cd_education_status = cd2.cd_education_status
# MAGIC      and
# MAGIC      ws_sales_price between 100.00 and 150.00
# MAGIC     )
# MAGIC    or
# MAGIC     (
# MAGIC      cd1.cd_marital_status = 'W'
# MAGIC      and
# MAGIC      cd1.cd_marital_status = cd2.cd_marital_status
# MAGIC      and
# MAGIC      cd1.cd_education_status = 'Primary' 
# MAGIC      and
# MAGIC      cd1.cd_education_status = cd2.cd_education_status
# MAGIC      and
# MAGIC      ws_sales_price between 50.00 and 100.00
# MAGIC     )
# MAGIC    or
# MAGIC     (
# MAGIC      cd1.cd_marital_status = 'D'
# MAGIC      and
# MAGIC      cd1.cd_marital_status = cd2.cd_marital_status
# MAGIC      and
# MAGIC      cd1.cd_education_status = 'Advanced Degree'
# MAGIC      and
# MAGIC      cd1.cd_education_status = cd2.cd_education_status
# MAGIC      and
# MAGIC      ws_sales_price between 150.00 and 200.00
# MAGIC     )
# MAGIC    )
# MAGIC    and
# MAGIC    (
# MAGIC     (
# MAGIC      ca_country = 'United States'
# MAGIC      and
# MAGIC      ca_state in ('KY', 'MS', 'NE')
# MAGIC      and ws_net_profit between 100 and 200  
# MAGIC     )
# MAGIC     or
# MAGIC     (
# MAGIC      ca_country = 'United States'
# MAGIC      and
# MAGIC      ca_state in ('ND', 'NJ', 'KS')
# MAGIC      and ws_net_profit between 150 and 300  
# MAGIC     )
# MAGIC     or
# MAGIC     (
# MAGIC      ca_country = 'United States'
# MAGIC      and
# MAGIC      ca_state in ('WA', 'MO', 'GA')
# MAGIC      and ws_net_profit between 50 and 250  
# MAGIC     )
# MAGIC    )
# MAGIC group by r_reason_desc
# MAGIC order by substr(r_reason_desc,1,20)
# MAGIC         ,avg(ws_quantity)
# MAGIC         ,avg(wr_refunded_cash)
# MAGIC         ,avg(wr_fee)
# MAGIC limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q86.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select   
# MAGIC     sum(ws_net_paid) as total_sum
# MAGIC    ,i_category
# MAGIC    ,i_class
# MAGIC    ,grouping(i_category)+grouping(i_class) as lochierarchy
# MAGIC    ,rank() over (
# MAGIC  	partition by grouping(i_category)+grouping(i_class),
# MAGIC  	case when grouping(i_class) = 0 then i_category end 
# MAGIC  	order by sum(ws_net_paid) desc) as rank_within_parent
# MAGIC  from
# MAGIC     web_sales
# MAGIC    ,date_dim       d1
# MAGIC    ,item
# MAGIC  where
# MAGIC     d1.d_month_seq between 1207 and 1207+11
# MAGIC  and d1.d_date_sk = ws_sold_date_sk
# MAGIC  and i_item_sk  = ws_item_sk
# MAGIC  group by rollup(i_category,i_class)
# MAGIC  order by
# MAGIC    lochierarchy desc,
# MAGIC    case when lochierarchy = 0 then i_category end,
# MAGIC    rank_within_parent
# MAGIC  limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q87.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select count(*) 
# MAGIC from ((select distinct c_last_name, c_first_name, d_date
# MAGIC        from store_sales, date_dim, customer
# MAGIC        where store_sales.ss_sold_date_sk = date_dim.d_date_sk
# MAGIC          and store_sales.ss_customer_sk = customer.c_customer_sk
# MAGIC          and d_month_seq between 1194 and 1194+11)
# MAGIC        except
# MAGIC       (select distinct c_last_name, c_first_name, d_date
# MAGIC        from catalog_sales, date_dim, customer
# MAGIC        where catalog_sales.cs_sold_date_sk = date_dim.d_date_sk
# MAGIC          and catalog_sales.cs_bill_customer_sk = customer.c_customer_sk
# MAGIC          and d_month_seq between 1194 and 1194+11)
# MAGIC        except
# MAGIC       (select distinct c_last_name, c_first_name, d_date
# MAGIC        from web_sales, date_dim, customer
# MAGIC        where web_sales.ws_sold_date_sk = date_dim.d_date_sk
# MAGIC          and web_sales.ws_bill_customer_sk = customer.c_customer_sk
# MAGIC          and d_month_seq between 1194 and 1194+11)
# MAGIC ) cool_cust
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q88.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  *
# MAGIC from
# MAGIC  (select count(*) h8_30_to_9
# MAGIC  from store_sales, household_demographics , time_dim, store
# MAGIC  where ss_sold_time_sk = time_dim.t_time_sk   
# MAGIC      and ss_hdemo_sk = household_demographics.hd_demo_sk 
# MAGIC      and ss_store_sk = s_store_sk
# MAGIC      and time_dim.t_hour = 8
# MAGIC      and time_dim.t_minute >= 30
# MAGIC      and ((household_demographics.hd_dep_count = 1 and household_demographics.hd_vehicle_count<=1+2) or
# MAGIC           (household_demographics.hd_dep_count = 0 and household_demographics.hd_vehicle_count<=0+2) or
# MAGIC           (household_demographics.hd_dep_count = 2 and household_demographics.hd_vehicle_count<=2+2)) 
# MAGIC      and store.s_store_name = 'ese') s1,
# MAGIC  (select count(*) h9_to_9_30 
# MAGIC  from store_sales, household_demographics , time_dim, store
# MAGIC  where ss_sold_time_sk = time_dim.t_time_sk
# MAGIC      and ss_hdemo_sk = household_demographics.hd_demo_sk
# MAGIC      and ss_store_sk = s_store_sk 
# MAGIC      and time_dim.t_hour = 9 
# MAGIC      and time_dim.t_minute < 30
# MAGIC      and ((household_demographics.hd_dep_count = 1 and household_demographics.hd_vehicle_count<=1+2) or
# MAGIC           (household_demographics.hd_dep_count = 0 and household_demographics.hd_vehicle_count<=0+2) or
# MAGIC           (household_demographics.hd_dep_count = 2 and household_demographics.hd_vehicle_count<=2+2))
# MAGIC      and store.s_store_name = 'ese') s2,
# MAGIC  (select count(*) h9_30_to_10 
# MAGIC  from store_sales, household_demographics , time_dim, store
# MAGIC  where ss_sold_time_sk = time_dim.t_time_sk
# MAGIC      and ss_hdemo_sk = household_demographics.hd_demo_sk
# MAGIC      and ss_store_sk = s_store_sk
# MAGIC      and time_dim.t_hour = 9
# MAGIC      and time_dim.t_minute >= 30
# MAGIC      and ((household_demographics.hd_dep_count = 1 and household_demographics.hd_vehicle_count<=1+2) or
# MAGIC           (household_demographics.hd_dep_count = 0 and household_demographics.hd_vehicle_count<=0+2) or
# MAGIC           (household_demographics.hd_dep_count = 2 and household_demographics.hd_vehicle_count<=2+2))
# MAGIC      and store.s_store_name = 'ese') s3,
# MAGIC  (select count(*) h10_to_10_30
# MAGIC  from store_sales, household_demographics , time_dim, store
# MAGIC  where ss_sold_time_sk = time_dim.t_time_sk
# MAGIC      and ss_hdemo_sk = household_demographics.hd_demo_sk
# MAGIC      and ss_store_sk = s_store_sk
# MAGIC      and time_dim.t_hour = 10 
# MAGIC      and time_dim.t_minute < 30
# MAGIC      and ((household_demographics.hd_dep_count = 1 and household_demographics.hd_vehicle_count<=1+2) or
# MAGIC           (household_demographics.hd_dep_count = 0 and household_demographics.hd_vehicle_count<=0+2) or
# MAGIC           (household_demographics.hd_dep_count = 2 and household_demographics.hd_vehicle_count<=2+2))
# MAGIC      and store.s_store_name = 'ese') s4,
# MAGIC  (select count(*) h10_30_to_11
# MAGIC  from store_sales, household_demographics , time_dim, store
# MAGIC  where ss_sold_time_sk = time_dim.t_time_sk
# MAGIC      and ss_hdemo_sk = household_demographics.hd_demo_sk
# MAGIC      and ss_store_sk = s_store_sk
# MAGIC      and time_dim.t_hour = 10 
# MAGIC      and time_dim.t_minute >= 30
# MAGIC      and ((household_demographics.hd_dep_count = 1 and household_demographics.hd_vehicle_count<=1+2) or
# MAGIC           (household_demographics.hd_dep_count = 0 and household_demographics.hd_vehicle_count<=0+2) or
# MAGIC           (household_demographics.hd_dep_count = 2 and household_demographics.hd_vehicle_count<=2+2))
# MAGIC      and store.s_store_name = 'ese') s5,
# MAGIC  (select count(*) h11_to_11_30
# MAGIC  from store_sales, household_demographics , time_dim, store
# MAGIC  where ss_sold_time_sk = time_dim.t_time_sk
# MAGIC      and ss_hdemo_sk = household_demographics.hd_demo_sk
# MAGIC      and ss_store_sk = s_store_sk 
# MAGIC      and time_dim.t_hour = 11
# MAGIC      and time_dim.t_minute < 30
# MAGIC      and ((household_demographics.hd_dep_count = 1 and household_demographics.hd_vehicle_count<=1+2) or
# MAGIC           (household_demographics.hd_dep_count = 0 and household_demographics.hd_vehicle_count<=0+2) or
# MAGIC           (household_demographics.hd_dep_count = 2 and household_demographics.hd_vehicle_count<=2+2))
# MAGIC      and store.s_store_name = 'ese') s6,
# MAGIC  (select count(*) h11_30_to_12
# MAGIC  from store_sales, household_demographics , time_dim, store
# MAGIC  where ss_sold_time_sk = time_dim.t_time_sk
# MAGIC      and ss_hdemo_sk = household_demographics.hd_demo_sk
# MAGIC      and ss_store_sk = s_store_sk
# MAGIC      and time_dim.t_hour = 11
# MAGIC      and time_dim.t_minute >= 30
# MAGIC      and ((household_demographics.hd_dep_count = 1 and household_demographics.hd_vehicle_count<=1+2) or
# MAGIC           (household_demographics.hd_dep_count = 0 and household_demographics.hd_vehicle_count<=0+2) or
# MAGIC           (household_demographics.hd_dep_count = 2 and household_demographics.hd_vehicle_count<=2+2))
# MAGIC      and store.s_store_name = 'ese') s7,
# MAGIC  (select count(*) h12_to_12_30
# MAGIC  from store_sales, household_demographics , time_dim, store
# MAGIC  where ss_sold_time_sk = time_dim.t_time_sk
# MAGIC      and ss_hdemo_sk = household_demographics.hd_demo_sk
# MAGIC      and ss_store_sk = s_store_sk
# MAGIC      and time_dim.t_hour = 12
# MAGIC      and time_dim.t_minute < 30
# MAGIC      and ((household_demographics.hd_dep_count = 1 and household_demographics.hd_vehicle_count<=1+2) or
# MAGIC           (household_demographics.hd_dep_count = 0 and household_demographics.hd_vehicle_count<=0+2) or
# MAGIC           (household_demographics.hd_dep_count = 2 and household_demographics.hd_vehicle_count<=2+2))
# MAGIC      and store.s_store_name = 'ese') s8
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q89.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  *
# MAGIC from(
# MAGIC select i_category, i_class, i_brand,
# MAGIC        s_store_name, s_company_name,
# MAGIC        d_moy,
# MAGIC        sum(ss_sales_price) sum_sales,
# MAGIC        avg(sum(ss_sales_price)) over
# MAGIC          (partition by i_category, i_brand, s_store_name, s_company_name)
# MAGIC          avg_monthly_sales
# MAGIC from item, store_sales, date_dim, store
# MAGIC where ss_item_sk = i_item_sk and
# MAGIC       ss_sold_date_sk = d_date_sk and
# MAGIC       ss_store_sk = s_store_sk and
# MAGIC       d_year in (2000) and
# MAGIC         ((i_category in ('Books','Children','Electronics') and
# MAGIC           i_class in ('science','toddlers','automotive')
# MAGIC          )
# MAGIC       or (i_category in ('Music','Jewelry','Men') and
# MAGIC           i_class in ('classical','estate','accessories') 
# MAGIC         ))
# MAGIC group by i_category, i_class, i_brand,
# MAGIC          s_store_name, s_company_name, d_moy) tmp1
# MAGIC where case when (avg_monthly_sales <> 0) then (abs(sum_sales - avg_monthly_sales) / avg_monthly_sales) else null end > 0.1
# MAGIC order by sum_sales - avg_monthly_sales, s_store_name
# MAGIC limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q90.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  cast(amc as decimal(15,4))/cast(pmc as decimal(15,4)) am_pm_ratio
# MAGIC  from ( select count(*) amc
# MAGIC        from web_sales, household_demographics , time_dim, web_page
# MAGIC        where ws_sold_time_sk = time_dim.t_time_sk
# MAGIC          and ws_ship_hdemo_sk = household_demographics.hd_demo_sk
# MAGIC          and ws_web_page_sk = web_page.wp_web_page_sk
# MAGIC          and time_dim.t_hour between 6 and 6+1
# MAGIC          and household_demographics.hd_dep_count = 2
# MAGIC          and web_page.wp_char_count between 5000 and 5200) at,
# MAGIC       ( select count(*) pmc
# MAGIC        from web_sales, household_demographics , time_dim, web_page
# MAGIC        where ws_sold_time_sk = time_dim.t_time_sk
# MAGIC          and ws_ship_hdemo_sk = household_demographics.hd_demo_sk
# MAGIC          and ws_web_page_sk = web_page.wp_web_page_sk
# MAGIC          and time_dim.t_hour between 15 and 15+1
# MAGIC          and household_demographics.hd_dep_count = 2
# MAGIC          and web_page.wp_char_count between 5000 and 5200) pt
# MAGIC  order by am_pm_ratio
# MAGIC  limit 100