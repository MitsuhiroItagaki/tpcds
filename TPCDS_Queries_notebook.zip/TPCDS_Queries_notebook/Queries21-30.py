# Databricks notebook source
# MAGIC %sql
# MAGIC use catalog tpcds;
# MAGIC use schema tpcds_sf1000_delta_lc;
# MAGIC set use_cached_result = false;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q21.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  *
# MAGIC  from(select w_warehouse_name
# MAGIC             ,i_item_id
# MAGIC             ,sum(case when (cast(d_date as date) < cast ('2000-05-29' as date))
# MAGIC 	                then inv_quantity_on_hand 
# MAGIC                       else 0 end) as inv_before
# MAGIC             ,sum(case when (cast(d_date as date) >= cast ('2000-05-29' as date))
# MAGIC                       then inv_quantity_on_hand 
# MAGIC                       else 0 end) as inv_after
# MAGIC    from inventory
# MAGIC        ,warehouse
# MAGIC        ,item
# MAGIC        ,date_dim
# MAGIC    where i_current_price between 0.99 and 1.49
# MAGIC      and i_item_sk          = inv_item_sk
# MAGIC      and inv_warehouse_sk   = w_warehouse_sk
# MAGIC      and inv_date_sk    = d_date_sk
# MAGIC      and d_date between date_add(cast ('2000-05-29' as date),-30)
# MAGIC                     and date_add(cast ('2000-05-29' as date),30)
# MAGIC    group by w_warehouse_name, i_item_id) x
# MAGIC  where (case when inv_before > 0 
# MAGIC              then inv_after / inv_before 
# MAGIC              else null
# MAGIC              end) between 2.0/3.0 and 3.0/2.0
# MAGIC  order by w_warehouse_name
# MAGIC          ,i_item_id
# MAGIC  limit 100
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q22.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  i_product_name
# MAGIC              ,i_brand
# MAGIC              ,i_class
# MAGIC              ,i_category
# MAGIC              ,avg(inv_quantity_on_hand) qoh
# MAGIC        from inventory
# MAGIC            ,date_dim
# MAGIC            ,item
# MAGIC        where inv_date_sk=d_date_sk
# MAGIC               and inv_item_sk=i_item_sk
# MAGIC               and d_month_seq between 1183 and 1183 + 11
# MAGIC        group by rollup(i_product_name
# MAGIC                        ,i_brand
# MAGIC                        ,i_class
# MAGIC                        ,i_category)
# MAGIC order by qoh, i_product_name, i_brand, i_class, i_category
# MAGIC limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q23a.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC with frequent_ss_items as 
# MAGIC  (select substr(i_item_desc,1,30) itemdesc,i_item_sk item_sk,d_date solddate,count(*) cnt
# MAGIC   from store_sales
# MAGIC       ,date_dim 
# MAGIC       ,item
# MAGIC   where ss_sold_date_sk = d_date_sk
# MAGIC     and ss_item_sk = i_item_sk 
# MAGIC     and d_year in (1998,1998+1,1998+2,1998+3)
# MAGIC   group by substr(i_item_desc,1,30),i_item_sk,d_date
# MAGIC   having count(*) >4),
# MAGIC  max_store_sales as
# MAGIC  (select max(csales) tpcds_cmax 
# MAGIC   from (select c_customer_sk,sum(ss_quantity*ss_sales_price) csales
# MAGIC         from store_sales
# MAGIC             ,customer
# MAGIC             ,date_dim 
# MAGIC         where ss_customer_sk = c_customer_sk
# MAGIC          and ss_sold_date_sk = d_date_sk
# MAGIC          and d_year in (1998,1998+1,1998+2,1998+3) 
# MAGIC         group by c_customer_sk)),
# MAGIC  best_ss_customer as
# MAGIC  (select c_customer_sk,sum(ss_quantity*ss_sales_price) ssales
# MAGIC   from store_sales
# MAGIC       ,customer
# MAGIC   where ss_customer_sk = c_customer_sk
# MAGIC   group by c_customer_sk
# MAGIC   having sum(ss_quantity*ss_sales_price) > (95/100.0) * (select
# MAGIC   *
# MAGIC from
# MAGIC  max_store_sales))
# MAGIC   select  sum(sales)
# MAGIC  from (select cs_quantity*cs_list_price sales
# MAGIC        from catalog_sales
# MAGIC            ,date_dim 
# MAGIC        where d_year = 1998 
# MAGIC          and d_moy = 4 
# MAGIC          and cs_sold_date_sk = d_date_sk 
# MAGIC          and cs_item_sk in (select item_sk from frequent_ss_items)
# MAGIC          and cs_bill_customer_sk in (select c_customer_sk from best_ss_customer)
# MAGIC       union all
# MAGIC       select ws_quantity*ws_list_price sales
# MAGIC        from web_sales 
# MAGIC            ,date_dim 
# MAGIC        where d_year = 1998 
# MAGIC          and d_moy = 4 
# MAGIC          and ws_sold_date_sk = d_date_sk 
# MAGIC          and ws_item_sk in (select item_sk from frequent_ss_items)
# MAGIC          and ws_bill_customer_sk in (select c_customer_sk from best_ss_customer)) 
# MAGIC  limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q23b.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC with frequent_ss_items as
# MAGIC  (select substr(i_item_desc,1,30) itemdesc,i_item_sk item_sk,d_date solddate,count(*) cnt
# MAGIC   from store_sales
# MAGIC       ,date_dim
# MAGIC       ,item
# MAGIC   where ss_sold_date_sk = d_date_sk
# MAGIC     and ss_item_sk = i_item_sk
# MAGIC     and d_year in (1998,1998 + 1,1998 + 2,1998 + 3)
# MAGIC   group by substr(i_item_desc,1,30),i_item_sk,d_date
# MAGIC   having count(*) >4),
# MAGIC  max_store_sales as
# MAGIC  (select max(csales) tpcds_cmax
# MAGIC   from (select c_customer_sk,sum(ss_quantity*ss_sales_price) csales
# MAGIC         from store_sales
# MAGIC             ,customer
# MAGIC             ,date_dim 
# MAGIC         where ss_customer_sk = c_customer_sk
# MAGIC          and ss_sold_date_sk = d_date_sk
# MAGIC          and d_year in (1998,1998+1,1998+2,1998+3)
# MAGIC         group by c_customer_sk)),
# MAGIC  best_ss_customer as
# MAGIC  (select c_customer_sk,sum(ss_quantity*ss_sales_price) ssales
# MAGIC   from store_sales
# MAGIC       ,customer
# MAGIC   where ss_customer_sk = c_customer_sk
# MAGIC   group by c_customer_sk
# MAGIC   having sum(ss_quantity*ss_sales_price) > (95/100.0) * (select
# MAGIC   *
# MAGIC  from max_store_sales))
# MAGIC   select  c_last_name,c_first_name,sales
# MAGIC  from (select c_last_name,c_first_name,sum(cs_quantity*cs_list_price) sales
# MAGIC         from catalog_sales
# MAGIC             ,customer
# MAGIC             ,date_dim 
# MAGIC         where d_year = 1998 
# MAGIC          and d_moy = 4 
# MAGIC          and cs_sold_date_sk = d_date_sk 
# MAGIC          and cs_item_sk in (select item_sk from frequent_ss_items)
# MAGIC          and cs_bill_customer_sk in (select c_customer_sk from best_ss_customer)
# MAGIC          and cs_bill_customer_sk = c_customer_sk 
# MAGIC        group by c_last_name,c_first_name
# MAGIC       union all
# MAGIC       select c_last_name,c_first_name,sum(ws_quantity*ws_list_price) sales
# MAGIC        from web_sales
# MAGIC            ,customer
# MAGIC            ,date_dim 
# MAGIC        where d_year = 1998 
# MAGIC          and d_moy = 4 
# MAGIC          and ws_sold_date_sk = d_date_sk 
# MAGIC          and ws_item_sk in (select item_sk from frequent_ss_items)
# MAGIC          and ws_bill_customer_sk in (select c_customer_sk from best_ss_customer)
# MAGIC          and ws_bill_customer_sk = c_customer_sk
# MAGIC        group by c_last_name,c_first_name) 
# MAGIC      order by c_last_name,c_first_name,sales
# MAGIC   limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q24a.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC with ssales as
# MAGIC (select c_last_name
# MAGIC       ,c_first_name
# MAGIC       ,s_store_name
# MAGIC       ,ca_state
# MAGIC       ,s_state
# MAGIC       ,i_color
# MAGIC       ,i_current_price
# MAGIC       ,i_manager_id
# MAGIC       ,i_units
# MAGIC       ,i_size
# MAGIC       ,sum(ss_net_paid_inc_tax) netpaid
# MAGIC from store_sales
# MAGIC     ,store_returns
# MAGIC     ,store
# MAGIC     ,item
# MAGIC     ,customer
# MAGIC     ,customer_address
# MAGIC where ss_ticket_number = sr_ticket_number
# MAGIC   and ss_item_sk = sr_item_sk
# MAGIC   and ss_customer_sk = c_customer_sk
# MAGIC   and ss_item_sk = i_item_sk
# MAGIC   and ss_store_sk = s_store_sk
# MAGIC   and c_current_addr_sk = ca_address_sk
# MAGIC   and c_birth_country <> upper(ca_country)
# MAGIC   and s_zip = ca_zip
# MAGIC and s_market_id=5
# MAGIC group by c_last_name
# MAGIC         ,c_first_name
# MAGIC         ,s_store_name
# MAGIC         ,ca_state
# MAGIC         ,s_state
# MAGIC         ,i_color
# MAGIC         ,i_current_price
# MAGIC         ,i_manager_id
# MAGIC         ,i_units
# MAGIC         ,i_size)
# MAGIC select c_last_name
# MAGIC       ,c_first_name
# MAGIC       ,s_store_name
# MAGIC       ,sum(netpaid) paid
# MAGIC from ssales
# MAGIC where i_color = 'tomato'
# MAGIC group by c_last_name
# MAGIC         ,c_first_name
# MAGIC         ,s_store_name
# MAGIC having sum(netpaid) > (select 0.05*avg(netpaid)
# MAGIC                                  from ssales)
# MAGIC order by c_last_name
# MAGIC         ,c_first_name
# MAGIC         ,s_store_name
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q24b.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC with ssales as
# MAGIC (select c_last_name
# MAGIC       ,c_first_name
# MAGIC       ,s_store_name
# MAGIC       ,ca_state
# MAGIC       ,s_state
# MAGIC       ,i_color
# MAGIC       ,i_current_price
# MAGIC       ,i_manager_id
# MAGIC       ,i_units
# MAGIC       ,i_size
# MAGIC       ,sum(ss_net_paid_inc_tax) netpaid
# MAGIC from store_sales
# MAGIC     ,store_returns
# MAGIC     ,store
# MAGIC     ,item
# MAGIC     ,customer
# MAGIC     ,customer_address
# MAGIC where ss_ticket_number = sr_ticket_number
# MAGIC   and ss_item_sk = sr_item_sk
# MAGIC   and ss_customer_sk = c_customer_sk
# MAGIC   and ss_item_sk = i_item_sk
# MAGIC   and ss_store_sk = s_store_sk
# MAGIC   and c_current_addr_sk = ca_address_sk
# MAGIC   and c_birth_country <> upper(ca_country)
# MAGIC   and s_zip = ca_zip
# MAGIC   and s_market_id = 5
# MAGIC group by c_last_name
# MAGIC         ,c_first_name
# MAGIC         ,s_store_name
# MAGIC         ,ca_state
# MAGIC         ,s_state
# MAGIC         ,i_color
# MAGIC         ,i_current_price
# MAGIC         ,i_manager_id
# MAGIC         ,i_units
# MAGIC         ,i_size)
# MAGIC select c_last_name
# MAGIC       ,c_first_name
# MAGIC       ,s_store_name
# MAGIC       ,sum(netpaid) paid
# MAGIC from ssales
# MAGIC where i_color = 'pale'
# MAGIC group by c_last_name
# MAGIC         ,c_first_name
# MAGIC         ,s_store_name
# MAGIC having sum(netpaid) > (select 0.05*avg(netpaid)
# MAGIC                            from ssales)
# MAGIC order by c_last_name
# MAGIC         ,c_first_name
# MAGIC         ,s_store_name
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q25.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  
# MAGIC  i_item_id
# MAGIC  ,i_item_desc
# MAGIC  ,s_store_id
# MAGIC  ,s_store_name
# MAGIC  ,min(ss_net_profit) as store_sales_profit
# MAGIC  ,min(sr_net_loss) as store_returns_loss
# MAGIC  ,min(cs_net_profit) as catalog_sales_profit
# MAGIC  from
# MAGIC  store_sales
# MAGIC  ,store_returns
# MAGIC  ,catalog_sales
# MAGIC  ,date_dim d1
# MAGIC  ,date_dim d2
# MAGIC  ,date_dim d3
# MAGIC  ,store
# MAGIC  ,item
# MAGIC  where
# MAGIC  d1.d_moy = 4
# MAGIC  and d1.d_year = 2001
# MAGIC  and d1.d_date_sk = ss_sold_date_sk
# MAGIC  and i_item_sk = ss_item_sk
# MAGIC  and s_store_sk = ss_store_sk
# MAGIC  and ss_customer_sk = sr_customer_sk
# MAGIC  and ss_item_sk = sr_item_sk
# MAGIC  and ss_ticket_number = sr_ticket_number
# MAGIC  and sr_returned_date_sk = d2.d_date_sk
# MAGIC  and d2.d_moy               between 4 and  10
# MAGIC  and d2.d_year              = 2001
# MAGIC  and sr_customer_sk = cs_bill_customer_sk
# MAGIC  and sr_item_sk = cs_item_sk
# MAGIC  and cs_sold_date_sk = d3.d_date_sk
# MAGIC  and d3.d_moy               between 4 and  10 
# MAGIC  and d3.d_year              = 2001
# MAGIC  group by
# MAGIC  i_item_id
# MAGIC  ,i_item_desc
# MAGIC  ,s_store_id
# MAGIC  ,s_store_name
# MAGIC  order by
# MAGIC  i_item_id
# MAGIC  ,i_item_desc
# MAGIC  ,s_store_id
# MAGIC  ,s_store_name
# MAGIC  limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q26.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  i_item_id, 
# MAGIC         avg(cs_quantity) agg1,
# MAGIC         avg(cs_list_price) agg2,
# MAGIC         avg(cs_coupon_amt) agg3,
# MAGIC         avg(cs_sales_price) agg4 
# MAGIC  from catalog_sales, customer_demographics, date_dim, item, promotion
# MAGIC  where cs_sold_date_sk = d_date_sk and
# MAGIC        cs_item_sk = i_item_sk and
# MAGIC        cs_bill_cdemo_sk = cd_demo_sk and
# MAGIC        cs_promo_sk = p_promo_sk and
# MAGIC        cd_gender = 'F' and 
# MAGIC        cd_marital_status = 'D' and
# MAGIC        cd_education_status = '2 yr Degree' and
# MAGIC        (p_channel_email = 'N' or p_channel_event = 'N') and
# MAGIC        d_year = 2002 
# MAGIC  group by i_item_id
# MAGIC  order by i_item_id
# MAGIC  limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q27.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  i_item_id,
# MAGIC         s_state, grouping(s_state) g_state,
# MAGIC         avg(ss_quantity) agg1,
# MAGIC         avg(ss_list_price) agg2,
# MAGIC         avg(ss_coupon_amt) agg3,
# MAGIC         avg(ss_sales_price) agg4
# MAGIC  from store_sales, customer_demographics, date_dim, store, item
# MAGIC  where ss_sold_date_sk = d_date_sk and
# MAGIC        ss_item_sk = i_item_sk and
# MAGIC        ss_store_sk = s_store_sk and
# MAGIC        ss_cdemo_sk = cd_demo_sk and
# MAGIC        cd_gender = 'F' and
# MAGIC        cd_marital_status = 'M' and
# MAGIC        cd_education_status = 'Secondary' and
# MAGIC        d_year = 2001 and
# MAGIC        s_state in ('MN','MN', 'CA', 'OK', 'KY', 'SD')
# MAGIC  group by rollup (i_item_id, s_state)
# MAGIC  order by i_item_id
# MAGIC          ,s_state
# MAGIC  limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q28.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  *
# MAGIC from (select avg(ss_list_price) B1_LP
# MAGIC             ,count(ss_list_price) B1_CNT
# MAGIC             ,count(distinct ss_list_price) B1_CNTD
# MAGIC       from store_sales
# MAGIC       where ss_quantity between 0 and 5
# MAGIC         and (ss_list_price between 159 and 159+10 
# MAGIC              or ss_coupon_amt between 13991 and 13991+1000
# MAGIC              or ss_wholesale_cost between 57 and 57+20)) B1,
# MAGIC      (select avg(ss_list_price) B2_LP
# MAGIC             ,count(ss_list_price) B2_CNT
# MAGIC             ,count(distinct ss_list_price) B2_CNTD
# MAGIC       from store_sales
# MAGIC       where ss_quantity between 6 and 10
# MAGIC         and (ss_list_price between 163 and 163+10
# MAGIC           or ss_coupon_amt between 2260 and 2260+1000
# MAGIC           or ss_wholesale_cost between 1 and 1+20)) B2,
# MAGIC      (select avg(ss_list_price) B3_LP
# MAGIC             ,count(ss_list_price) B3_CNT
# MAGIC             ,count(distinct ss_list_price) B3_CNTD
# MAGIC       from store_sales
# MAGIC       where ss_quantity between 11 and 15
# MAGIC         and (ss_list_price between 36 and 36+10
# MAGIC           or ss_coupon_amt between 11822 and 11822+1000
# MAGIC           or ss_wholesale_cost between 29 and 29+20)) B3,
# MAGIC      (select avg(ss_list_price) B4_LP
# MAGIC             ,count(ss_list_price) B4_CNT
# MAGIC             ,count(distinct ss_list_price) B4_CNTD
# MAGIC       from store_sales
# MAGIC       where ss_quantity between 16 and 20
# MAGIC         and (ss_list_price between 40 and 40+10
# MAGIC           or ss_coupon_amt between 7051 and 7051+1000
# MAGIC           or ss_wholesale_cost between 49 and 49+20)) B4,
# MAGIC      (select avg(ss_list_price) B5_LP
# MAGIC             ,count(ss_list_price) B5_CNT
# MAGIC             ,count(distinct ss_list_price) B5_CNTD
# MAGIC       from store_sales
# MAGIC       where ss_quantity between 21 and 25
# MAGIC         and (ss_list_price between 90 and 90+10
# MAGIC           or ss_coupon_amt between 4594 and 4594+1000
# MAGIC           or ss_wholesale_cost between 12 and 12+20)) B5,
# MAGIC      (select avg(ss_list_price) B6_LP
# MAGIC             ,count(ss_list_price) B6_CNT
# MAGIC             ,count(distinct ss_list_price) B6_CNTD
# MAGIC       from store_sales
# MAGIC       where ss_quantity between 26 and 30
# MAGIC         and (ss_list_price between 150 and 150+10
# MAGIC           or ss_coupon_amt between 6475 and 6475+1000
# MAGIC           or ss_wholesale_cost between 45 and 45+20)) B6
# MAGIC limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q29.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select   
# MAGIC      i_item_id
# MAGIC     ,i_item_desc
# MAGIC     ,s_store_id
# MAGIC     ,s_store_name
# MAGIC     ,avg(ss_quantity)        as store_sales_quantity
# MAGIC     ,avg(sr_return_quantity) as store_returns_quantity
# MAGIC     ,avg(cs_quantity)        as catalog_sales_quantity
# MAGIC  from
# MAGIC     store_sales
# MAGIC    ,store_returns
# MAGIC    ,catalog_sales
# MAGIC    ,date_dim             d1
# MAGIC    ,date_dim             d2
# MAGIC    ,date_dim             d3
# MAGIC    ,store
# MAGIC    ,item
# MAGIC  where
# MAGIC      d1.d_moy               = 4 
# MAGIC  and d1.d_year              = 2000
# MAGIC  and d1.d_date_sk           = ss_sold_date_sk
# MAGIC  and i_item_sk              = ss_item_sk
# MAGIC  and s_store_sk             = ss_store_sk
# MAGIC  and ss_customer_sk         = sr_customer_sk
# MAGIC  and ss_item_sk             = sr_item_sk
# MAGIC  and ss_ticket_number       = sr_ticket_number
# MAGIC  and sr_returned_date_sk    = d2.d_date_sk
# MAGIC  and d2.d_moy               between 4 and  4 + 3 
# MAGIC  and d2.d_year              = 2000
# MAGIC  and sr_customer_sk         = cs_bill_customer_sk
# MAGIC  and sr_item_sk             = cs_item_sk
# MAGIC  and cs_sold_date_sk        = d3.d_date_sk     
# MAGIC  and d3.d_year              in (2000,2000+1,2000+2)
# MAGIC  group by
# MAGIC     i_item_id
# MAGIC    ,i_item_desc
# MAGIC    ,s_store_id
# MAGIC    ,s_store_name
# MAGIC  order by
# MAGIC     i_item_id 
# MAGIC    ,i_item_desc
# MAGIC    ,s_store_id
# MAGIC    ,s_store_name
# MAGIC  limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q30.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC with customer_total_return as
# MAGIC  (select wr_returning_customer_sk as ctr_customer_sk
# MAGIC         ,ca_state as ctr_state, 
# MAGIC  	sum(wr_return_amt) as ctr_total_return
# MAGIC  from web_returns
# MAGIC      ,date_dim
# MAGIC      ,customer_address
# MAGIC  where wr_returned_date_sk = d_date_sk 
# MAGIC    and d_year =2000
# MAGIC    and wr_returning_addr_sk = ca_address_sk 
# MAGIC  group by wr_returning_customer_sk
# MAGIC          ,ca_state)
# MAGIC   select  c_customer_id,c_salutation,c_first_name,c_last_name,c_preferred_cust_flag
# MAGIC        ,c_birth_day,c_birth_month,c_birth_year,c_birth_country,c_login,c_email_address
# MAGIC        ,c_last_review_date_sk,ctr_total_return
# MAGIC  from customer_total_return ctr1
# MAGIC      ,customer_address
# MAGIC      ,customer
# MAGIC  where ctr1.ctr_total_return > (select avg(ctr_total_return)*1.2
# MAGIC  			  from customer_total_return ctr2 
# MAGIC                   	  where ctr1.ctr_state = ctr2.ctr_state)
# MAGIC        and ca_address_sk = c_current_addr_sk
# MAGIC        and ca_state = 'UT'
# MAGIC        and ctr1.ctr_customer_sk = c_customer_sk
# MAGIC  order by c_customer_id,c_salutation,c_first_name,c_last_name,c_preferred_cust_flag
# MAGIC                   ,c_birth_day,c_birth_month,c_birth_year,c_birth_country,c_login,c_email_address
# MAGIC                   ,c_last_review_date_sk,ctr_total_return
# MAGIC limit 100