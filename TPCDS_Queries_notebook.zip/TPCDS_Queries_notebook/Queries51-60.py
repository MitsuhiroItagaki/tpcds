# Databricks notebook source
# MAGIC %sql
# MAGIC use catalog tpcds;
# MAGIC use schema tpcds_sf1000_delta_lc;
# MAGIC set use_cached_result = false;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q51.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC WITH web_v1 as (
# MAGIC select
# MAGIC   ws_item_sk item_sk, d_date,
# MAGIC   sum(sum(ws_sales_price))
# MAGIC       over (partition by ws_item_sk order by d_date rows between unbounded preceding and current row) cume_sales
# MAGIC from web_sales
# MAGIC     ,date_dim
# MAGIC where ws_sold_date_sk=d_date_sk
# MAGIC   and d_month_seq between 1190 and 1190+11
# MAGIC   and ws_item_sk is not NULL
# MAGIC group by ws_item_sk, d_date),
# MAGIC store_v1 as (
# MAGIC select
# MAGIC   ss_item_sk item_sk, d_date,
# MAGIC   sum(sum(ss_sales_price))
# MAGIC       over (partition by ss_item_sk order by d_date rows between unbounded preceding and current row) cume_sales
# MAGIC from store_sales
# MAGIC     ,date_dim
# MAGIC where ss_sold_date_sk=d_date_sk
# MAGIC   and d_month_seq between 1190 and 1190+11
# MAGIC   and ss_item_sk is not NULL
# MAGIC group by ss_item_sk, d_date)
# MAGIC  select  *
# MAGIC from (select item_sk
# MAGIC      ,d_date
# MAGIC      ,web_sales
# MAGIC      ,store_sales
# MAGIC      ,max(web_sales)
# MAGIC          over (partition by item_sk order by d_date rows between unbounded preceding and current row) web_cumulative
# MAGIC      ,max(store_sales)
# MAGIC          over (partition by item_sk order by d_date rows between unbounded preceding and current row) store_cumulative
# MAGIC      from (select case when web.item_sk is not null then web.item_sk else store.item_sk end item_sk
# MAGIC                  ,case when web.d_date is not null then web.d_date else store.d_date end d_date
# MAGIC                  ,web.cume_sales web_sales
# MAGIC                  ,store.cume_sales store_sales
# MAGIC            from web_v1 web full outer join store_v1 store on (web.item_sk = store.item_sk
# MAGIC                                                           and web.d_date = store.d_date)
# MAGIC           )x )y
# MAGIC where web_cumulative > store_cumulative
# MAGIC order by item_sk
# MAGIC         ,d_date
# MAGIC limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q52.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  dt.d_year
# MAGIC  	,item.i_brand_id brand_id
# MAGIC  	,item.i_brand brand
# MAGIC  	,sum(ss_ext_sales_price) ext_price
# MAGIC  from date_dim dt
# MAGIC      ,store_sales
# MAGIC      ,item
# MAGIC  where dt.d_date_sk = store_sales.ss_sold_date_sk
# MAGIC     and store_sales.ss_item_sk = item.i_item_sk
# MAGIC     and item.i_manager_id = 1
# MAGIC     and dt.d_moy=12
# MAGIC     and dt.d_year=1998
# MAGIC  group by dt.d_year
# MAGIC  	,item.i_brand
# MAGIC  	,item.i_brand_id
# MAGIC  order by dt.d_year
# MAGIC  	,ext_price desc
# MAGIC  	,brand_id
# MAGIC limit 100
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q53.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  * from 
# MAGIC (select i_manufact_id,
# MAGIC sum(ss_sales_price) sum_sales,
# MAGIC avg(sum(ss_sales_price)) over (partition by i_manufact_id) avg_quarterly_sales
# MAGIC from item, store_sales, date_dim, store
# MAGIC where ss_item_sk = i_item_sk and
# MAGIC ss_sold_date_sk = d_date_sk and
# MAGIC ss_store_sk = s_store_sk and
# MAGIC d_month_seq in (1192,1192+1,1192+2,1192+3,1192+4,1192+5,1192+6,1192+7,1192+8,1192+9,1192+10,1192+11) and
# MAGIC ((i_category in ('Books','Children','Electronics') and
# MAGIC i_class in ('personal','portable','reference','self-help') and
# MAGIC i_brand in ('scholaramalgamalg #14','scholaramalgamalg #7',
# MAGIC 		'exportiunivamalg #9','scholaramalgamalg #9'))
# MAGIC or(i_category in ('Women','Music','Men') and
# MAGIC i_class in ('accessories','classical','fragrances','pants') and
# MAGIC i_brand in ('amalgimporto #1','edu packscholar #1','exportiimporto #1',
# MAGIC 		'importoamalg #1')))
# MAGIC group by i_manufact_id, d_qoy ) tmp1
# MAGIC where case when avg_quarterly_sales > 0 
# MAGIC 	then abs (sum_sales - avg_quarterly_sales)/ avg_quarterly_sales 
# MAGIC 	else null end > 0.1
# MAGIC order by avg_quarterly_sales,
# MAGIC 	 sum_sales,
# MAGIC 	 i_manufact_id
# MAGIC limit 100
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q54.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC with my_customers as (
# MAGIC  select distinct c_customer_sk
# MAGIC         , c_current_addr_sk
# MAGIC  from   
# MAGIC         ( select cs_sold_date_sk sold_date_sk,
# MAGIC                  cs_bill_customer_sk customer_sk,
# MAGIC                  cs_item_sk item_sk
# MAGIC           from   catalog_sales
# MAGIC           union all
# MAGIC           select ws_sold_date_sk sold_date_sk,
# MAGIC                  ws_bill_customer_sk customer_sk,
# MAGIC                  ws_item_sk item_sk
# MAGIC           from   web_sales
# MAGIC          ) cs_or_ws_sales,
# MAGIC          item,
# MAGIC          date_dim,
# MAGIC          customer
# MAGIC  where   sold_date_sk = d_date_sk
# MAGIC          and item_sk = i_item_sk
# MAGIC          and i_category = 'Sports'
# MAGIC          and i_class = 'pools'
# MAGIC          and c_customer_sk = cs_or_ws_sales.customer_sk
# MAGIC          and d_moy = 2
# MAGIC          and d_year = 1998
# MAGIC  )
# MAGIC  , my_revenue as (
# MAGIC  select c_customer_sk,
# MAGIC         sum(ss_ext_sales_price) as revenue
# MAGIC  from   my_customers,
# MAGIC         store_sales,
# MAGIC         customer_address,
# MAGIC         store,
# MAGIC         date_dim
# MAGIC  where  c_current_addr_sk = ca_address_sk
# MAGIC         and ca_county = s_county
# MAGIC         and ca_state = s_state
# MAGIC         and ss_sold_date_sk = d_date_sk
# MAGIC         and c_customer_sk = ss_customer_sk
# MAGIC         and d_month_seq between (select distinct d_month_seq+1
# MAGIC                                  from   date_dim where d_year = 1998 and d_moy = 2)
# MAGIC                            and  (select distinct d_month_seq+3
# MAGIC                                  from   date_dim where d_year = 1998 and d_moy = 2)
# MAGIC  group by c_customer_sk
# MAGIC  )
# MAGIC  , segments as
# MAGIC  (select cast((revenue/50) as int) as segment
# MAGIC   from   my_revenue
# MAGIC  )
# MAGIC   select  segment, count(*) as num_customers, segment*50 as segment_base
# MAGIC  from segments
# MAGIC  group by segment
# MAGIC  order by segment, num_customers
# MAGIC  limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q55.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  i_brand_id brand_id, i_brand brand,
# MAGIC  	sum(ss_ext_sales_price) ext_price
# MAGIC  from date_dim, store_sales, item
# MAGIC  where d_date_sk = ss_sold_date_sk
# MAGIC  	and ss_item_sk = i_item_sk
# MAGIC  	and i_manager_id=15
# MAGIC  	and d_moy=12
# MAGIC  	and d_year=2000
# MAGIC  group by i_brand, i_brand_id
# MAGIC  order by ext_price desc, i_brand_id
# MAGIC limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q56.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC with ss as (
# MAGIC  select i_item_id,sum(ss_ext_sales_price) total_sales
# MAGIC  from
# MAGIC  	store_sales,
# MAGIC  	date_dim,
# MAGIC          customer_address,
# MAGIC          item
# MAGIC  where i_item_id in (select
# MAGIC      i_item_id
# MAGIC from item
# MAGIC where i_color in ('misty','firebrick','chiffon'))
# MAGIC  and     ss_item_sk              = i_item_sk
# MAGIC  and     ss_sold_date_sk         = d_date_sk
# MAGIC  and     d_year                  = 2000
# MAGIC  and     d_moy                   = 3
# MAGIC  and     ss_addr_sk              = ca_address_sk
# MAGIC  and     ca_gmt_offset           = -6 
# MAGIC  group by i_item_id),
# MAGIC  cs as (
# MAGIC  select i_item_id,sum(cs_ext_sales_price) total_sales
# MAGIC  from
# MAGIC  	catalog_sales,
# MAGIC  	date_dim,
# MAGIC          customer_address,
# MAGIC          item
# MAGIC  where
# MAGIC          i_item_id               in (select
# MAGIC   i_item_id
# MAGIC from item
# MAGIC where i_color in ('misty','firebrick','chiffon'))
# MAGIC  and     cs_item_sk              = i_item_sk
# MAGIC  and     cs_sold_date_sk         = d_date_sk
# MAGIC  and     d_year                  = 2000
# MAGIC  and     d_moy                   = 3
# MAGIC  and     cs_bill_addr_sk         = ca_address_sk
# MAGIC  and     ca_gmt_offset           = -6 
# MAGIC  group by i_item_id),
# MAGIC  ws as (
# MAGIC  select i_item_id,sum(ws_ext_sales_price) total_sales
# MAGIC  from
# MAGIC  	web_sales,
# MAGIC  	date_dim,
# MAGIC          customer_address,
# MAGIC          item
# MAGIC  where
# MAGIC          i_item_id               in (select
# MAGIC   i_item_id
# MAGIC from item
# MAGIC where i_color in ('misty','firebrick','chiffon'))
# MAGIC  and     ws_item_sk              = i_item_sk
# MAGIC  and     ws_sold_date_sk         = d_date_sk
# MAGIC  and     d_year                  = 2000
# MAGIC  and     d_moy                   = 3
# MAGIC  and     ws_bill_addr_sk         = ca_address_sk
# MAGIC  and     ca_gmt_offset           = -6
# MAGIC  group by i_item_id)
# MAGIC   select  i_item_id ,sum(total_sales) total_sales
# MAGIC  from  (select * from ss 
# MAGIC         union all
# MAGIC         select * from cs 
# MAGIC         union all
# MAGIC         select * from ws) tmp1
# MAGIC  group by i_item_id
# MAGIC  order by total_sales,
# MAGIC           i_item_id
# MAGIC  limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q57.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC with v1 as(
# MAGIC  select i_category, i_brand,
# MAGIC         cc_name,
# MAGIC         d_year, d_moy,
# MAGIC         sum(cs_sales_price) sum_sales,
# MAGIC         avg(sum(cs_sales_price)) over
# MAGIC           (partition by i_category, i_brand,
# MAGIC                      cc_name, d_year)
# MAGIC           avg_monthly_sales,
# MAGIC         rank() over
# MAGIC           (partition by i_category, i_brand,
# MAGIC                      cc_name
# MAGIC            order by d_year, d_moy) rn
# MAGIC  from item, catalog_sales, date_dim, call_center
# MAGIC  where cs_item_sk = i_item_sk and
# MAGIC        cs_sold_date_sk = d_date_sk and
# MAGIC        cc_call_center_sk= cs_call_center_sk and
# MAGIC        (
# MAGIC          d_year = 2001 or
# MAGIC          ( d_year = 2001-1 and d_moy =12) or
# MAGIC          ( d_year = 2001+1 and d_moy =1)
# MAGIC        )
# MAGIC  group by i_category, i_brand,
# MAGIC           cc_name , d_year, d_moy),
# MAGIC  v2 as(
# MAGIC  select v1.i_category, v1.i_brand
# MAGIC         ,v1.d_year, v1.d_moy
# MAGIC         ,v1.avg_monthly_sales
# MAGIC         ,v1.sum_sales, v1_lag.sum_sales psum, v1_lead.sum_sales nsum
# MAGIC  from v1, v1 v1_lag, v1 v1_lead
# MAGIC  where v1.i_category = v1_lag.i_category and
# MAGIC        v1.i_category = v1_lead.i_category and
# MAGIC        v1.i_brand = v1_lag.i_brand and
# MAGIC        v1.i_brand = v1_lead.i_brand and
# MAGIC        v1. cc_name = v1_lag. cc_name and
# MAGIC        v1. cc_name = v1_lead. cc_name and
# MAGIC        v1.rn = v1_lag.rn + 1 and
# MAGIC        v1.rn = v1_lead.rn - 1)
# MAGIC   select  *
# MAGIC  from v2
# MAGIC  where  d_year = 2001 and
# MAGIC         avg_monthly_sales > 0 and
# MAGIC         case when avg_monthly_sales > 0 then abs(sum_sales - avg_monthly_sales) / avg_monthly_sales else null end > 0.1
# MAGIC  order by sum_sales - avg_monthly_sales, nsum
# MAGIC  limit 100
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q58.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC with ss_items as
# MAGIC  (select i_item_id item_id
# MAGIC         ,sum(ss_ext_sales_price) ss_item_rev 
# MAGIC  from store_sales
# MAGIC      ,item
# MAGIC      ,date_dim
# MAGIC  where ss_item_sk = i_item_sk
# MAGIC    and d_date in (select d_date
# MAGIC                   from date_dim
# MAGIC                   where d_week_seq = (select d_week_seq 
# MAGIC                                       from date_dim
# MAGIC                                       where d_date = '2000-05-06'))
# MAGIC    and ss_sold_date_sk   = d_date_sk
# MAGIC  group by i_item_id),
# MAGIC  cs_items as
# MAGIC  (select i_item_id item_id
# MAGIC         ,sum(cs_ext_sales_price) cs_item_rev
# MAGIC   from catalog_sales
# MAGIC       ,item
# MAGIC       ,date_dim
# MAGIC  where cs_item_sk = i_item_sk
# MAGIC   and  d_date in (select d_date
# MAGIC                   from date_dim
# MAGIC                   where d_week_seq = (select d_week_seq 
# MAGIC                                       from date_dim
# MAGIC                                       where d_date = '2000-05-06'))
# MAGIC   and  cs_sold_date_sk = d_date_sk
# MAGIC  group by i_item_id),
# MAGIC  ws_items as
# MAGIC  (select i_item_id item_id
# MAGIC         ,sum(ws_ext_sales_price) ws_item_rev
# MAGIC   from web_sales
# MAGIC       ,item
# MAGIC       ,date_dim
# MAGIC  where ws_item_sk = i_item_sk
# MAGIC   and  d_date in (select d_date
# MAGIC                   from date_dim
# MAGIC                   where d_week_seq =(select d_week_seq 
# MAGIC                                      from date_dim
# MAGIC                                      where d_date = '2000-05-06'))
# MAGIC   and ws_sold_date_sk   = d_date_sk
# MAGIC  group by i_item_id)
# MAGIC   select  ss_items.item_id
# MAGIC        ,ss_item_rev
# MAGIC        ,ss_item_rev/((ss_item_rev+cs_item_rev+ws_item_rev)/3) * 100 ss_dev
# MAGIC        ,cs_item_rev
# MAGIC        ,cs_item_rev/((ss_item_rev+cs_item_rev+ws_item_rev)/3) * 100 cs_dev
# MAGIC        ,ws_item_rev
# MAGIC        ,ws_item_rev/((ss_item_rev+cs_item_rev+ws_item_rev)/3) * 100 ws_dev
# MAGIC        ,(ss_item_rev+cs_item_rev+ws_item_rev)/3 average
# MAGIC  from ss_items,cs_items,ws_items
# MAGIC  where ss_items.item_id=cs_items.item_id
# MAGIC    and ss_items.item_id=ws_items.item_id 
# MAGIC    and ss_item_rev between 0.9 * cs_item_rev and 1.1 * cs_item_rev
# MAGIC    and ss_item_rev between 0.9 * ws_item_rev and 1.1 * ws_item_rev
# MAGIC    and cs_item_rev between 0.9 * ss_item_rev and 1.1 * ss_item_rev
# MAGIC    and cs_item_rev between 0.9 * ws_item_rev and 1.1 * ws_item_rev
# MAGIC    and ws_item_rev between 0.9 * ss_item_rev and 1.1 * ss_item_rev
# MAGIC    and ws_item_rev between 0.9 * cs_item_rev and 1.1 * cs_item_rev
# MAGIC  order by item_id
# MAGIC          ,ss_item_rev
# MAGIC  limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q59.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC with wss as 
# MAGIC  (select d_week_seq,
# MAGIC         ss_store_sk,
# MAGIC         sum(case when (d_day_name='Sunday') then ss_sales_price else null end) sun_sales,
# MAGIC         sum(case when (d_day_name='Monday') then ss_sales_price else null end) mon_sales,
# MAGIC         sum(case when (d_day_name='Tuesday') then ss_sales_price else  null end) tue_sales,
# MAGIC         sum(case when (d_day_name='Wednesday') then ss_sales_price else null end) wed_sales,
# MAGIC         sum(case when (d_day_name='Thursday') then ss_sales_price else null end) thu_sales,
# MAGIC         sum(case when (d_day_name='Friday') then ss_sales_price else null end) fri_sales,
# MAGIC         sum(case when (d_day_name='Saturday') then ss_sales_price else null end) sat_sales
# MAGIC  from store_sales,date_dim
# MAGIC  where d_date_sk = ss_sold_date_sk
# MAGIC  group by d_week_seq,ss_store_sk
# MAGIC  )
# MAGIC   select  s_store_name1,s_store_id1,d_week_seq1
# MAGIC        ,sun_sales1/sun_sales2,mon_sales1/mon_sales2
# MAGIC        ,tue_sales1/tue_sales2,wed_sales1/wed_sales2,thu_sales1/thu_sales2
# MAGIC        ,fri_sales1/fri_sales2,sat_sales1/sat_sales2
# MAGIC  from
# MAGIC  (select s_store_name s_store_name1,wss.d_week_seq d_week_seq1
# MAGIC         ,s_store_id s_store_id1,sun_sales sun_sales1
# MAGIC         ,mon_sales mon_sales1,tue_sales tue_sales1
# MAGIC         ,wed_sales wed_sales1,thu_sales thu_sales1
# MAGIC         ,fri_sales fri_sales1,sat_sales sat_sales1
# MAGIC   from wss,store,date_dim d
# MAGIC   where d.d_week_seq = wss.d_week_seq and
# MAGIC         ss_store_sk = s_store_sk and 
# MAGIC         d_month_seq between 1188 and 1188 + 11) y,
# MAGIC  (select s_store_name s_store_name2,wss.d_week_seq d_week_seq2
# MAGIC         ,s_store_id s_store_id2,sun_sales sun_sales2
# MAGIC         ,mon_sales mon_sales2,tue_sales tue_sales2
# MAGIC         ,wed_sales wed_sales2,thu_sales thu_sales2
# MAGIC         ,fri_sales fri_sales2,sat_sales sat_sales2
# MAGIC   from wss,store,date_dim d
# MAGIC   where d.d_week_seq = wss.d_week_seq and
# MAGIC         ss_store_sk = s_store_sk and 
# MAGIC         d_month_seq between 1188+ 12 and 1188 + 23) x
# MAGIC  where s_store_id1=s_store_id2
# MAGIC    and d_week_seq1=d_week_seq2-52
# MAGIC  order by s_store_name1,s_store_id1,d_week_seq1
# MAGIC limit 100
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q60.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC with ss as (
# MAGIC  select
# MAGIC           i_item_id,sum(ss_ext_sales_price) total_sales
# MAGIC  from
# MAGIC  	store_sales,
# MAGIC  	date_dim,
# MAGIC          customer_address,
# MAGIC          item
# MAGIC  where
# MAGIC          i_item_id in (select
# MAGIC   i_item_id
# MAGIC from
# MAGIC  item
# MAGIC where i_category in ('Music'))
# MAGIC  and     ss_item_sk              = i_item_sk
# MAGIC  and     ss_sold_date_sk         = d_date_sk
# MAGIC  and     d_year                  = 2001
# MAGIC  and     d_moy                   = 8
# MAGIC  and     ss_addr_sk              = ca_address_sk
# MAGIC  and     ca_gmt_offset           = -5 
# MAGIC  group by i_item_id),
# MAGIC  cs as (
# MAGIC  select
# MAGIC           i_item_id,sum(cs_ext_sales_price) total_sales
# MAGIC  from
# MAGIC  	catalog_sales,
# MAGIC  	date_dim,
# MAGIC          customer_address,
# MAGIC          item
# MAGIC  where
# MAGIC          i_item_id               in (select
# MAGIC   i_item_id
# MAGIC from
# MAGIC  item
# MAGIC where i_category in ('Music'))
# MAGIC  and     cs_item_sk              = i_item_sk
# MAGIC  and     cs_sold_date_sk         = d_date_sk
# MAGIC  and     d_year                  = 2001
# MAGIC  and     d_moy                   = 8
# MAGIC  and     cs_bill_addr_sk         = ca_address_sk
# MAGIC  and     ca_gmt_offset           = -5 
# MAGIC  group by i_item_id),
# MAGIC  ws as (
# MAGIC  select
# MAGIC           i_item_id,sum(ws_ext_sales_price) total_sales
# MAGIC  from
# MAGIC  	web_sales,
# MAGIC  	date_dim,
# MAGIC          customer_address,
# MAGIC          item
# MAGIC  where
# MAGIC          i_item_id               in (select
# MAGIC   i_item_id
# MAGIC from
# MAGIC  item
# MAGIC where i_category in ('Music'))
# MAGIC  and     ws_item_sk              = i_item_sk
# MAGIC  and     ws_sold_date_sk         = d_date_sk
# MAGIC  and     d_year                  = 2001
# MAGIC  and     d_moy                   = 8
# MAGIC  and     ws_bill_addr_sk         = ca_address_sk
# MAGIC  and     ca_gmt_offset           = -5
# MAGIC  group by i_item_id)
# MAGIC   select   
# MAGIC   i_item_id
# MAGIC ,sum(total_sales) total_sales
# MAGIC  from  (select * from ss 
# MAGIC         union all
# MAGIC         select * from cs 
# MAGIC         union all
# MAGIC         select * from ws) tmp1
# MAGIC  group by i_item_id
# MAGIC  order by i_item_id
# MAGIC       ,total_sales
# MAGIC  limit 100
# MAGIC