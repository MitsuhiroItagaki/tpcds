# Databricks notebook source
# MAGIC %sql
# MAGIC use catalog tpcds;
# MAGIC use schema tpcds_sf1000_delta_lc;
# MAGIC set use_cached_result = false;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q31.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC with ss as
# MAGIC  (select ca_county,d_qoy, d_year,sum(ss_ext_sales_price) as store_sales
# MAGIC  from store_sales,date_dim,customer_address
# MAGIC  where ss_sold_date_sk = d_date_sk
# MAGIC   and ss_addr_sk=ca_address_sk
# MAGIC  group by ca_county,d_qoy, d_year),
# MAGIC  ws as
# MAGIC  (select ca_county,d_qoy, d_year,sum(ws_ext_sales_price) as web_sales
# MAGIC  from web_sales,date_dim,customer_address
# MAGIC  where ws_sold_date_sk = d_date_sk
# MAGIC   and ws_bill_addr_sk=ca_address_sk
# MAGIC  group by ca_county,d_qoy, d_year)
# MAGIC  select 
# MAGIC         ss1.ca_county
# MAGIC        ,ss1.d_year
# MAGIC        ,ws2.web_sales/ws1.web_sales web_q1_q2_increase
# MAGIC        ,ss2.store_sales/ss1.store_sales store_q1_q2_increase
# MAGIC        ,ws3.web_sales/ws2.web_sales web_q2_q3_increase
# MAGIC        ,ss3.store_sales/ss2.store_sales store_q2_q3_increase
# MAGIC  from
# MAGIC         ss ss1
# MAGIC        ,ss ss2
# MAGIC        ,ss ss3
# MAGIC        ,ws ws1
# MAGIC        ,ws ws2
# MAGIC        ,ws ws3
# MAGIC  where
# MAGIC     ss1.d_qoy = 1
# MAGIC     and ss1.d_year = 1998
# MAGIC     and ss1.ca_county = ss2.ca_county
# MAGIC     and ss2.d_qoy = 2
# MAGIC     and ss2.d_year = 1998
# MAGIC  and ss2.ca_county = ss3.ca_county
# MAGIC     and ss3.d_qoy = 3
# MAGIC     and ss3.d_year = 1998
# MAGIC     and ss1.ca_county = ws1.ca_county
# MAGIC     and ws1.d_qoy = 1
# MAGIC     and ws1.d_year = 1998
# MAGIC     and ws1.ca_county = ws2.ca_county
# MAGIC     and ws2.d_qoy = 2
# MAGIC     and ws2.d_year = 1998
# MAGIC     and ws1.ca_county = ws3.ca_county
# MAGIC     and ws3.d_qoy = 3
# MAGIC     and ws3.d_year =1998
# MAGIC     and case when ws1.web_sales > 0 then ws2.web_sales/ws1.web_sales else null end 
# MAGIC        > case when ss1.store_sales > 0 then ss2.store_sales/ss1.store_sales else null end
# MAGIC     and case when ws2.web_sales > 0 then ws3.web_sales/ws2.web_sales else null end
# MAGIC        > case when ss2.store_sales > 0 then ss3.store_sales/ss2.store_sales else null end
# MAGIC  order by store_q2_q3_increase

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q32.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  sum(cs_ext_discount_amt)  as `excess discount amount` 
# MAGIC from 
# MAGIC    catalog_sales 
# MAGIC    ,item 
# MAGIC    ,date_dim
# MAGIC where
# MAGIC i_manufact_id = 211
# MAGIC and i_item_sk = cs_item_sk 
# MAGIC and d_date between '2001-02-09' and 
# MAGIC         date_add(cast('2001-02-09' as date),90)
# MAGIC and d_date_sk = cs_sold_date_sk 
# MAGIC and cs_ext_discount_amt  
# MAGIC      > ( 
# MAGIC          select 
# MAGIC             1.3 * avg(cs_ext_discount_amt) 
# MAGIC          from 
# MAGIC             catalog_sales 
# MAGIC            ,date_dim
# MAGIC          where 
# MAGIC               cs_item_sk = i_item_sk 
# MAGIC           and d_date between '2001-02-09' and
# MAGIC                              date_add(cast('2001-02-09' as date),90)
# MAGIC           and d_date_sk = cs_sold_date_sk 
# MAGIC       ) 
# MAGIC limit 100
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q33.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC with ss as (
# MAGIC  select
# MAGIC           i_manufact_id,sum(ss_ext_sales_price) total_sales
# MAGIC  from
# MAGIC  	store_sales,
# MAGIC  	date_dim,
# MAGIC          customer_address,
# MAGIC          item
# MAGIC  where
# MAGIC          i_manufact_id in (select
# MAGIC   i_manufact_id
# MAGIC from
# MAGIC  item
# MAGIC where i_category in ('Home'))
# MAGIC  and     ss_item_sk              = i_item_sk
# MAGIC  and     ss_sold_date_sk         = d_date_sk
# MAGIC  and     d_year                  = 1998
# MAGIC  and     d_moy                   = 7
# MAGIC  and     ss_addr_sk              = ca_address_sk
# MAGIC  and     ca_gmt_offset           = -6 
# MAGIC  group by i_manufact_id),
# MAGIC  cs as (
# MAGIC  select
# MAGIC           i_manufact_id,sum(cs_ext_sales_price) total_sales
# MAGIC  from
# MAGIC  	catalog_sales,
# MAGIC  	date_dim,
# MAGIC          customer_address,
# MAGIC          item
# MAGIC  where
# MAGIC          i_manufact_id               in (select
# MAGIC   i_manufact_id
# MAGIC from
# MAGIC  item
# MAGIC where i_category in ('Home'))
# MAGIC  and     cs_item_sk              = i_item_sk
# MAGIC  and     cs_sold_date_sk         = d_date_sk
# MAGIC  and     d_year                  = 1998
# MAGIC  and     d_moy                   = 7
# MAGIC  and     cs_bill_addr_sk         = ca_address_sk
# MAGIC  and     ca_gmt_offset           = -6 
# MAGIC  group by i_manufact_id),
# MAGIC  ws as (
# MAGIC  select
# MAGIC           i_manufact_id,sum(ws_ext_sales_price) total_sales
# MAGIC  from
# MAGIC  	web_sales,
# MAGIC  	date_dim,
# MAGIC          customer_address,
# MAGIC          item
# MAGIC  where
# MAGIC          i_manufact_id               in (select
# MAGIC   i_manufact_id
# MAGIC from
# MAGIC  item
# MAGIC where i_category in ('Home'))
# MAGIC  and     ws_item_sk              = i_item_sk
# MAGIC  and     ws_sold_date_sk         = d_date_sk
# MAGIC  and     d_year                  = 1998
# MAGIC  and     d_moy                   = 7
# MAGIC  and     ws_bill_addr_sk         = ca_address_sk
# MAGIC  and     ca_gmt_offset           = -6
# MAGIC  group by i_manufact_id)
# MAGIC   select  i_manufact_id ,sum(total_sales) total_sales
# MAGIC  from  (select * from ss 
# MAGIC         union all
# MAGIC         select * from cs 
# MAGIC         union all
# MAGIC         select * from ws) tmp1
# MAGIC  group by i_manufact_id
# MAGIC  order by total_sales
# MAGIC limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q34.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select c_last_name
# MAGIC        ,c_first_name
# MAGIC        ,c_salutation
# MAGIC        ,c_preferred_cust_flag
# MAGIC        ,ss_ticket_number
# MAGIC        ,cnt from
# MAGIC    (select ss_ticket_number
# MAGIC           ,ss_customer_sk
# MAGIC           ,count(*) cnt
# MAGIC     from store_sales,date_dim,store,household_demographics
# MAGIC     where store_sales.ss_sold_date_sk = date_dim.d_date_sk
# MAGIC     and store_sales.ss_store_sk = store.s_store_sk  
# MAGIC     and store_sales.ss_hdemo_sk = household_demographics.hd_demo_sk
# MAGIC     and (date_dim.d_dom between 1 and 3 or date_dim.d_dom between 25 and 28)
# MAGIC     and (household_demographics.hd_buy_potential = '>10000' or
# MAGIC          household_demographics.hd_buy_potential = '5001-10000')
# MAGIC     and household_demographics.hd_vehicle_count > 0
# MAGIC     and (case when household_demographics.hd_vehicle_count > 0 
# MAGIC 	then household_demographics.hd_dep_count/ household_demographics.hd_vehicle_count 
# MAGIC 	else null 
# MAGIC 	end)  > 1.2
# MAGIC     and date_dim.d_year in (2000,2000+1,2000+2)
# MAGIC     and store.s_county in ('Tolland County','Sibley County','Lunenburg County','Greene County',
# MAGIC                            'Perry County','Wilkinson County','Huron County','Terry County')
# MAGIC     group by ss_ticket_number,ss_customer_sk) dn,customer
# MAGIC     where ss_customer_sk = c_customer_sk
# MAGIC       and cnt between 15 and 20
# MAGIC     order by c_last_name,c_first_name,c_salutation,c_preferred_cust_flag desc, ss_ticket_number
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q35.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select   
# MAGIC   ca_state,
# MAGIC   cd_gender,
# MAGIC   cd_marital_status,
# MAGIC   cd_dep_count,
# MAGIC   count(*) cnt1,
# MAGIC   max(cd_dep_count) AGGONE_1,
# MAGIC   min(cd_dep_count) AGGTWO_1,
# MAGIC   avg(cd_dep_count) AGGTHREE_1,
# MAGIC   cd_dep_employed_count,
# MAGIC   count(*) cnt2,
# MAGIC   max(cd_dep_employed_count) AGGONE_2,
# MAGIC   min(cd_dep_employed_count) AGGTWO_2,
# MAGIC   avg(cd_dep_employed_count) AGGTHREE_2,
# MAGIC   cd_dep_college_count,
# MAGIC   count(*) cnt3,
# MAGIC   max(cd_dep_college_count) AGGONE_3,
# MAGIC   min(cd_dep_college_count) AGGTWO_3,
# MAGIC   avg(cd_dep_college_count) AGGTHREE_3
# MAGIC  from
# MAGIC   customer c,customer_address ca,customer_demographics
# MAGIC  where
# MAGIC   c.c_current_addr_sk = ca.ca_address_sk and
# MAGIC   cd_demo_sk = c.c_current_cdemo_sk and 
# MAGIC   exists (select *
# MAGIC           from store_sales,date_dim
# MAGIC           where c.c_customer_sk = ss_customer_sk and
# MAGIC                 ss_sold_date_sk = d_date_sk and
# MAGIC                 d_year = 2000 and
# MAGIC                 d_qoy < 4) and
# MAGIC    (exists (select *
# MAGIC             from web_sales,date_dim
# MAGIC             where c.c_customer_sk = ws_bill_customer_sk and
# MAGIC                   ws_sold_date_sk = d_date_sk and
# MAGIC                   d_year = 2000 and
# MAGIC                   d_qoy < 4) or 
# MAGIC     exists (select * 
# MAGIC             from catalog_sales,date_dim
# MAGIC             where c.c_customer_sk = cs_ship_customer_sk and
# MAGIC                   cs_sold_date_sk = d_date_sk and
# MAGIC                   d_year = 2000 and
# MAGIC                   d_qoy < 4))
# MAGIC  group by ca_state,
# MAGIC           cd_gender,
# MAGIC           cd_marital_status,
# MAGIC           cd_dep_count,
# MAGIC           cd_dep_employed_count,
# MAGIC           cd_dep_college_count
# MAGIC  order by ca_state,
# MAGIC           cd_gender,
# MAGIC           cd_marital_status,
# MAGIC           cd_dep_count,
# MAGIC           cd_dep_employed_count,
# MAGIC           cd_dep_college_count
# MAGIC  limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q36.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  
# MAGIC     sum(ss_net_profit)/sum(ss_ext_sales_price) as gross_margin
# MAGIC    ,i_category
# MAGIC    ,i_class
# MAGIC    ,grouping(i_category)+grouping(i_class) as lochierarchy
# MAGIC    ,rank() over (
# MAGIC  	partition by grouping(i_category)+grouping(i_class),
# MAGIC  	case when grouping(i_class) = 0 then i_category end 
# MAGIC  	order by sum(ss_net_profit)/sum(ss_ext_sales_price) asc) as rank_within_parent
# MAGIC  from
# MAGIC     store_sales
# MAGIC    ,date_dim       d1
# MAGIC    ,item
# MAGIC    ,store
# MAGIC  where
# MAGIC     d1.d_year = 1998 
# MAGIC  and d1.d_date_sk = ss_sold_date_sk
# MAGIC  and i_item_sk  = ss_item_sk 
# MAGIC  and s_store_sk  = ss_store_sk
# MAGIC  and s_state in ('NY','NC','LA','SC',
# MAGIC                  'AL','CA','NM','MN')
# MAGIC  group by rollup(i_category,i_class)
# MAGIC  order by
# MAGIC    lochierarchy desc
# MAGIC   ,case when lochierarchy = 0 then i_category end
# MAGIC   ,rank_within_parent
# MAGIC   limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q37.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  i_item_id
# MAGIC        ,i_item_desc
# MAGIC        ,i_current_price
# MAGIC  from item, inventory, date_dim, catalog_sales
# MAGIC  where i_current_price between 34 and 34 + 30
# MAGIC  and inv_item_sk = i_item_sk
# MAGIC  and d_date_sk=inv_date_sk
# MAGIC  and d_date between cast('2001-04-22' as date) and date_add(cast('2001-04-22' as date),60)
# MAGIC  and i_manufact_id in (773,886,933,776)
# MAGIC  and inv_quantity_on_hand between 100 and 500
# MAGIC  and cs_item_sk = i_item_sk
# MAGIC  group by i_item_id,i_item_desc,i_current_price
# MAGIC  order by i_item_id
# MAGIC  limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q38.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  count(*) from (
# MAGIC     select distinct c_last_name, c_first_name, d_date
# MAGIC     from store_sales, date_dim, customer
# MAGIC           where store_sales.ss_sold_date_sk = date_dim.d_date_sk
# MAGIC       and store_sales.ss_customer_sk = customer.c_customer_sk
# MAGIC       and d_month_seq between 1209 and 1209 + 11
# MAGIC   intersect
# MAGIC     select distinct c_last_name, c_first_name, d_date
# MAGIC     from catalog_sales, date_dim, customer
# MAGIC           where catalog_sales.cs_sold_date_sk = date_dim.d_date_sk
# MAGIC       and catalog_sales.cs_bill_customer_sk = customer.c_customer_sk
# MAGIC       and d_month_seq between 1209 and 1209 + 11
# MAGIC   intersect
# MAGIC     select distinct c_last_name, c_first_name, d_date
# MAGIC     from web_sales, date_dim, customer
# MAGIC           where web_sales.ws_sold_date_sk = date_dim.d_date_sk
# MAGIC       and web_sales.ws_bill_customer_sk = customer.c_customer_sk
# MAGIC       and d_month_seq between 1209 and 1209 + 11
# MAGIC ) hot_cust
# MAGIC limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q39a.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC with inv as
# MAGIC (select w_warehouse_name,w_warehouse_sk,i_item_sk,d_moy
# MAGIC        ,stdev,mean, case mean when 0 then null else stdev/mean end cov
# MAGIC  from(select w_warehouse_name,w_warehouse_sk,i_item_sk,d_moy
# MAGIC             ,stddev_samp(inv_quantity_on_hand) stdev,avg(inv_quantity_on_hand) mean
# MAGIC       from inventory
# MAGIC           ,item
# MAGIC           ,warehouse
# MAGIC           ,date_dim
# MAGIC       where inv_item_sk = i_item_sk
# MAGIC         and inv_warehouse_sk = w_warehouse_sk
# MAGIC         and inv_date_sk = d_date_sk
# MAGIC         and d_year =2001
# MAGIC       group by w_warehouse_name,w_warehouse_sk,i_item_sk,d_moy) foo
# MAGIC  where case mean when 0 then 0 else stdev/mean end > 1)
# MAGIC select inv1.w_warehouse_sk as `inv1 w_warehouse_sk`,inv1.i_item_sk as `inv1.i_item_sk`,inv1.d_moy as `inv1.d_moy`,inv1.mean as `inv1.mean`, inv1.cov `inv1.cov`
# MAGIC         ,inv2.w_warehouse_sk as `inv2.w_warehouse_sk`,inv2.i_item_sk `inv2.i_item_sk`,inv2.d_moy `inv2.d_moy`,inv2.mean `inv2.mean`, inv2.cov `inv2.cov`
# MAGIC from inv inv1,inv inv2
# MAGIC where inv1.i_item_sk = inv2.i_item_sk
# MAGIC   and inv1.w_warehouse_sk =  inv2.w_warehouse_sk
# MAGIC   and inv1.d_moy=1
# MAGIC   and inv2.d_moy=1+1
# MAGIC order by inv1.w_warehouse_sk,inv1.i_item_sk,inv1.d_moy,inv1.mean,inv1.cov
# MAGIC         ,inv2.d_moy,inv2.mean, inv2.cov

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q39b.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC with inv as
# MAGIC (select w_warehouse_name,w_warehouse_sk,i_item_sk,d_moy
# MAGIC        ,stdev,mean, case mean when 0 then null else stdev/mean end cov
# MAGIC  from(select w_warehouse_name,w_warehouse_sk,i_item_sk,d_moy
# MAGIC             ,stddev_samp(inv_quantity_on_hand) stdev,avg(inv_quantity_on_hand) mean
# MAGIC       from inventory
# MAGIC           ,item
# MAGIC           ,warehouse
# MAGIC           ,date_dim
# MAGIC       where inv_item_sk = i_item_sk
# MAGIC         and inv_warehouse_sk = w_warehouse_sk
# MAGIC         and inv_date_sk = d_date_sk
# MAGIC         and d_year =2001
# MAGIC       group by w_warehouse_name,w_warehouse_sk,i_item_sk,d_moy) foo
# MAGIC  where case mean when 0 then 0 else stdev/mean end > 1)
# MAGIC select inv1.w_warehouse_sk as `inv1.w_warehouse_sk`,inv1.i_item_sk as `inv1.i_item_sk`,inv1.d_moy `inv1.d_moy`,inv1.mean as `inv1.mean`, inv1.cov as `inv1.cov`
# MAGIC         ,inv2.w_warehouse_sk as `inv2.w_warehouse_sk`,inv2.i_item_sk as `inv2.i_item_sk`,inv2.d_moy as `inv2.d_moy`,inv2.mean as `inv2.mean`, inv2.cov as `inv2.cov`
# MAGIC from inv inv1,inv inv2
# MAGIC where inv1.i_item_sk = inv2.i_item_sk
# MAGIC   and inv1.w_warehouse_sk =  inv2.w_warehouse_sk
# MAGIC   and inv1.d_moy=1
# MAGIC   and inv2.d_moy=1+1
# MAGIC   and inv1.cov > 1.5
# MAGIC order by inv1.w_warehouse_sk,inv1.i_item_sk,inv1.d_moy,inv1.mean,inv1.cov
# MAGIC         ,inv2.d_moy,inv2.mean, inv2.cov
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q40.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  
# MAGIC    w_state
# MAGIC   ,i_item_id
# MAGIC   ,sum(case when (cast(d_date as date) < cast ('2000-02-17' as date)) 
# MAGIC  		then cs_sales_price - coalesce(cr_refunded_cash,0) else 0 end) as sales_before
# MAGIC   ,sum(case when (cast(d_date as date) >= cast ('2000-02-17' as date)) 
# MAGIC  		then cs_sales_price - coalesce(cr_refunded_cash,0) else 0 end) as sales_after
# MAGIC  from
# MAGIC    catalog_sales left outer join catalog_returns on
# MAGIC        (cs_order_number = cr_order_number 
# MAGIC         and cs_item_sk = cr_item_sk)
# MAGIC   ,warehouse 
# MAGIC   ,item
# MAGIC   ,date_dim
# MAGIC  where
# MAGIC      i_current_price between 0.99 and 1.49
# MAGIC  and i_item_sk          = cs_item_sk
# MAGIC  and cs_warehouse_sk    = w_warehouse_sk 
# MAGIC  and cs_sold_date_sk    = d_date_sk
# MAGIC  and d_date between date_add(cast ('2000-02-17' as date),-30)
# MAGIC                 and date_add(cast ('2000-02-17' as date),30) 
# MAGIC  group by
# MAGIC     w_state,i_item_id
# MAGIC  order by w_state,i_item_id
# MAGIC limit 100