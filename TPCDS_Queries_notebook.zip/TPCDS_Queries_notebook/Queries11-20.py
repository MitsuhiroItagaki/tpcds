# Databricks notebook source
# MAGIC %sql
# MAGIC use catalog tpcds;
# MAGIC use schema tpcds_sf1000_delta_lc;
# MAGIC set use_cached_result = false;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q11.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC with year_total as (
# MAGIC  select c_customer_id customer_id
# MAGIC        ,c_first_name customer_first_name
# MAGIC        ,c_last_name customer_last_name
# MAGIC        ,c_preferred_cust_flag customer_preferred_cust_flag
# MAGIC        ,c_birth_country customer_birth_country
# MAGIC        ,c_login customer_login
# MAGIC        ,c_email_address customer_email_address
# MAGIC        ,d_year dyear
# MAGIC        ,sum(ss_ext_list_price-ss_ext_discount_amt) year_total
# MAGIC        ,'s' sale_type
# MAGIC  from customer
# MAGIC      ,store_sales
# MAGIC      ,date_dim
# MAGIC  where c_customer_sk = ss_customer_sk
# MAGIC    and ss_sold_date_sk = d_date_sk
# MAGIC  group by c_customer_id
# MAGIC          ,c_first_name
# MAGIC          ,c_last_name
# MAGIC          ,c_preferred_cust_flag 
# MAGIC          ,c_birth_country
# MAGIC          ,c_login
# MAGIC          ,c_email_address
# MAGIC          ,d_year 
# MAGIC  union all
# MAGIC  select c_customer_id customer_id
# MAGIC        ,c_first_name customer_first_name
# MAGIC        ,c_last_name customer_last_name
# MAGIC        ,c_preferred_cust_flag customer_preferred_cust_flag
# MAGIC        ,c_birth_country customer_birth_country
# MAGIC        ,c_login customer_login
# MAGIC        ,c_email_address customer_email_address
# MAGIC        ,d_year dyear
# MAGIC        ,sum(ws_ext_list_price-ws_ext_discount_amt) year_total
# MAGIC        ,'w' sale_type
# MAGIC  from customer
# MAGIC      ,web_sales
# MAGIC      ,date_dim
# MAGIC  where c_customer_sk = ws_bill_customer_sk
# MAGIC    and ws_sold_date_sk = d_date_sk
# MAGIC  group by c_customer_id
# MAGIC          ,c_first_name
# MAGIC          ,c_last_name
# MAGIC          ,c_preferred_cust_flag 
# MAGIC          ,c_birth_country
# MAGIC          ,c_login
# MAGIC          ,c_email_address
# MAGIC          ,d_year
# MAGIC          )
# MAGIC   select  
# MAGIC                   t_s_secyear.customer_id
# MAGIC                  ,t_s_secyear.customer_first_name
# MAGIC                  ,t_s_secyear.customer_last_name
# MAGIC                  ,t_s_secyear.customer_email_address
# MAGIC  from year_total t_s_firstyear
# MAGIC      ,year_total t_s_secyear
# MAGIC      ,year_total t_w_firstyear
# MAGIC      ,year_total t_w_secyear
# MAGIC  where t_s_secyear.customer_id = t_s_firstyear.customer_id
# MAGIC          and t_s_firstyear.customer_id = t_w_secyear.customer_id
# MAGIC          and t_s_firstyear.customer_id = t_w_firstyear.customer_id
# MAGIC          and t_s_firstyear.sale_type = 's'
# MAGIC          and t_w_firstyear.sale_type = 'w'
# MAGIC          and t_s_secyear.sale_type = 's'
# MAGIC          and t_w_secyear.sale_type = 'w'
# MAGIC          and t_s_firstyear.dyear = 2000
# MAGIC          and t_s_secyear.dyear = 2000+1
# MAGIC          and t_w_firstyear.dyear = 2000
# MAGIC          and t_w_secyear.dyear = 2000+1
# MAGIC          and t_s_firstyear.year_total > 0
# MAGIC          and t_w_firstyear.year_total > 0
# MAGIC          and case when t_w_firstyear.year_total > 0 then t_w_secyear.year_total / t_w_firstyear.year_total else 0.0 end
# MAGIC              > case when t_s_firstyear.year_total > 0 then t_s_secyear.year_total / t_s_firstyear.year_total else 0.0 end
# MAGIC  order by t_s_secyear.customer_id
# MAGIC          ,t_s_secyear.customer_first_name
# MAGIC          ,t_s_secyear.customer_last_name
# MAGIC          ,t_s_secyear.customer_email_address
# MAGIC limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q12.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  i_item_id
# MAGIC       ,i_item_desc 
# MAGIC       ,i_category 
# MAGIC       ,i_class 
# MAGIC       ,i_current_price
# MAGIC       ,sum(ws_ext_sales_price) as itemrevenue 
# MAGIC       ,sum(ws_ext_sales_price)*100/sum(sum(ws_ext_sales_price)) over
# MAGIC           (partition by i_class) as revenueratio
# MAGIC from	
# MAGIC 	web_sales
# MAGIC     	,item 
# MAGIC     	,date_dim
# MAGIC where 
# MAGIC 	ws_item_sk = i_item_sk 
# MAGIC   	and i_category in ('Men', 'Sports', 'Jewelry')
# MAGIC   	and ws_sold_date_sk = d_date_sk
# MAGIC 	and d_date between cast('2001-06-18' as date) 
# MAGIC 				and date_add(cast('2001-06-18' as date),30)
# MAGIC group by 
# MAGIC 	i_item_id
# MAGIC         ,i_item_desc 
# MAGIC         ,i_category
# MAGIC         ,i_class
# MAGIC         ,i_current_price
# MAGIC order by 
# MAGIC 	i_category
# MAGIC         ,i_class
# MAGIC         ,i_item_id
# MAGIC         ,i_item_desc
# MAGIC         ,revenueratio
# MAGIC limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q13.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select avg(ss_quantity)
# MAGIC        ,avg(ss_ext_sales_price)
# MAGIC        ,avg(ss_ext_wholesale_cost)
# MAGIC        ,sum(ss_ext_wholesale_cost)
# MAGIC  from store_sales
# MAGIC      ,store
# MAGIC      ,customer_demographics
# MAGIC      ,household_demographics
# MAGIC      ,customer_address
# MAGIC      ,date_dim
# MAGIC  where s_store_sk = ss_store_sk
# MAGIC  and  ss_sold_date_sk = d_date_sk and d_year = 2001
# MAGIC  and((ss_hdemo_sk=hd_demo_sk
# MAGIC   and cd_demo_sk = ss_cdemo_sk
# MAGIC   and cd_marital_status = 'M'
# MAGIC   and cd_education_status = '2 yr Degree'
# MAGIC   and ss_sales_price between 100.00 and 150.00
# MAGIC   and hd_dep_count = 3   
# MAGIC      )or
# MAGIC      (ss_hdemo_sk=hd_demo_sk
# MAGIC   and cd_demo_sk = ss_cdemo_sk
# MAGIC   and cd_marital_status = 'U'
# MAGIC   and cd_education_status = '4 yr Degree'
# MAGIC   and ss_sales_price between 50.00 and 100.00   
# MAGIC   and hd_dep_count = 1
# MAGIC      ) or 
# MAGIC      (ss_hdemo_sk=hd_demo_sk
# MAGIC   and cd_demo_sk = ss_cdemo_sk
# MAGIC   and cd_marital_status = 'S'
# MAGIC   and cd_education_status = 'Unknown'
# MAGIC   and ss_sales_price between 150.00 and 200.00 
# MAGIC   and hd_dep_count = 1  
# MAGIC      ))
# MAGIC  and((ss_addr_sk = ca_address_sk
# MAGIC   and ca_country = 'United States'
# MAGIC   and ca_state in ('TX', 'MN', 'MI')
# MAGIC   and ss_net_profit between 100 and 200  
# MAGIC      ) or
# MAGIC      (ss_addr_sk = ca_address_sk
# MAGIC   and ca_country = 'United States'
# MAGIC   and ca_state in ('GA', 'WA', 'AZ')
# MAGIC   and ss_net_profit between 150 and 300  
# MAGIC      ) or
# MAGIC      (ss_addr_sk = ca_address_sk
# MAGIC   and ca_country = 'United States'
# MAGIC   and ca_state in ('VA', 'NC', 'AK')
# MAGIC   and ss_net_profit between 50 and 250  
# MAGIC      ))
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q14a.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC with  cross_items as
# MAGIC  (select i_item_sk ss_item_sk
# MAGIC  from item,
# MAGIC  (select iss.i_brand_id brand_id
# MAGIC      ,iss.i_class_id class_id
# MAGIC      ,iss.i_category_id category_id
# MAGIC  from store_sales
# MAGIC      ,item iss
# MAGIC      ,date_dim d1
# MAGIC  where ss_item_sk = iss.i_item_sk
# MAGIC    and ss_sold_date_sk = d1.d_date_sk
# MAGIC    and d1.d_year between 1999 AND 1999 + 2
# MAGIC  intersect 
# MAGIC  select ics.i_brand_id
# MAGIC      ,ics.i_class_id
# MAGIC      ,ics.i_category_id
# MAGIC  from catalog_sales
# MAGIC      ,item ics
# MAGIC      ,date_dim d2
# MAGIC  where cs_item_sk = ics.i_item_sk
# MAGIC    and cs_sold_date_sk = d2.d_date_sk
# MAGIC    and d2.d_year between 1999 AND 1999 + 2
# MAGIC  intersect
# MAGIC  select iws.i_brand_id
# MAGIC      ,iws.i_class_id
# MAGIC      ,iws.i_category_id
# MAGIC  from web_sales
# MAGIC      ,item iws
# MAGIC      ,date_dim d3
# MAGIC  where ws_item_sk = iws.i_item_sk
# MAGIC    and ws_sold_date_sk = d3.d_date_sk
# MAGIC    and d3.d_year between 1999 AND 1999 + 2)
# MAGIC  where i_brand_id = brand_id
# MAGIC       and i_class_id = class_id
# MAGIC       and i_category_id = category_id
# MAGIC ),
# MAGIC  avg_sales as
# MAGIC  (select avg(quantity*list_price) average_sales
# MAGIC   from (select ss_quantity quantity
# MAGIC              ,ss_list_price list_price
# MAGIC        from store_sales
# MAGIC            ,date_dim
# MAGIC        where ss_sold_date_sk = d_date_sk
# MAGIC          and d_year between 1999 and 1999 + 2
# MAGIC        union all 
# MAGIC        select cs_quantity quantity 
# MAGIC              ,cs_list_price list_price
# MAGIC        from catalog_sales
# MAGIC            ,date_dim
# MAGIC        where cs_sold_date_sk = d_date_sk
# MAGIC          and d_year between 1999 and 1999 + 2 
# MAGIC        union all
# MAGIC        select ws_quantity quantity
# MAGIC              ,ws_list_price list_price
# MAGIC        from web_sales
# MAGIC            ,date_dim
# MAGIC        where ws_sold_date_sk = d_date_sk
# MAGIC          and d_year between 1999 and 1999 + 2) x)
# MAGIC   select  channel, i_brand_id,i_class_id,i_category_id,sum(sales), sum(number_sales)
# MAGIC  from(
# MAGIC        select 'store' channel, i_brand_id,i_class_id
# MAGIC              ,i_category_id,sum(ss_quantity*ss_list_price) sales
# MAGIC              , count(*) number_sales
# MAGIC        from store_sales
# MAGIC            ,item
# MAGIC            ,date_dim
# MAGIC        where ss_item_sk in (select ss_item_sk from cross_items)
# MAGIC          and ss_item_sk = i_item_sk
# MAGIC          and ss_sold_date_sk = d_date_sk
# MAGIC          and d_year = 1999+2 
# MAGIC          and d_moy = 11
# MAGIC        group by i_brand_id,i_class_id,i_category_id
# MAGIC        having sum(ss_quantity*ss_list_price) > (select average_sales from avg_sales)
# MAGIC        union all
# MAGIC        select 'catalog' channel, i_brand_id,i_class_id,i_category_id, sum(cs_quantity*cs_list_price) sales, count(*) number_sales
# MAGIC        from catalog_sales
# MAGIC            ,item
# MAGIC            ,date_dim
# MAGIC        where cs_item_sk in (select ss_item_sk from cross_items)
# MAGIC          and cs_item_sk = i_item_sk
# MAGIC          and cs_sold_date_sk = d_date_sk
# MAGIC          and d_year = 1999+2 
# MAGIC          and d_moy = 11
# MAGIC        group by i_brand_id,i_class_id,i_category_id
# MAGIC        having sum(cs_quantity*cs_list_price) > (select average_sales from avg_sales)
# MAGIC        union all
# MAGIC        select 'web' channel, i_brand_id,i_class_id,i_category_id, sum(ws_quantity*ws_list_price) sales , count(*) number_sales
# MAGIC        from web_sales
# MAGIC            ,item
# MAGIC            ,date_dim
# MAGIC        where ws_item_sk in (select ss_item_sk from cross_items)
# MAGIC          and ws_item_sk = i_item_sk
# MAGIC          and ws_sold_date_sk = d_date_sk
# MAGIC          and d_year = 1999+2
# MAGIC          and d_moy = 11
# MAGIC        group by i_brand_id,i_class_id,i_category_id
# MAGIC        having sum(ws_quantity*ws_list_price) > (select average_sales from avg_sales)
# MAGIC  ) y
# MAGIC  group by rollup (channel, i_brand_id,i_class_id,i_category_id)
# MAGIC  order by channel,i_brand_id,i_class_id,i_category_id
# MAGIC  limit 100
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q14b.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC with  cross_items as
# MAGIC  (select i_item_sk ss_item_sk
# MAGIC  from item,
# MAGIC  (select iss.i_brand_id brand_id
# MAGIC      ,iss.i_class_id class_id
# MAGIC      ,iss.i_category_id category_id
# MAGIC  from store_sales
# MAGIC      ,item iss
# MAGIC      ,date_dim d1
# MAGIC  where ss_item_sk = iss.i_item_sk
# MAGIC    and ss_sold_date_sk = d1.d_date_sk
# MAGIC    and d1.d_year between 1999 AND 1999 + 2
# MAGIC  intersect
# MAGIC  select ics.i_brand_id
# MAGIC      ,ics.i_class_id
# MAGIC      ,ics.i_category_id
# MAGIC  from catalog_sales
# MAGIC      ,item ics
# MAGIC      ,date_dim d2
# MAGIC  where cs_item_sk = ics.i_item_sk
# MAGIC    and cs_sold_date_sk = d2.d_date_sk
# MAGIC    and d2.d_year between 1999 AND 1999 + 2
# MAGIC  intersect
# MAGIC  select iws.i_brand_id
# MAGIC      ,iws.i_class_id
# MAGIC      ,iws.i_category_id
# MAGIC  from web_sales
# MAGIC      ,item iws
# MAGIC      ,date_dim d3
# MAGIC  where ws_item_sk = iws.i_item_sk
# MAGIC    and ws_sold_date_sk = d3.d_date_sk
# MAGIC    and d3.d_year between 1999 AND 1999 + 2) x
# MAGIC  where i_brand_id = brand_id
# MAGIC       and i_class_id = class_id
# MAGIC       and i_category_id = category_id
# MAGIC ),
# MAGIC  avg_sales as
# MAGIC (select avg(quantity*list_price) average_sales
# MAGIC   from (select ss_quantity quantity
# MAGIC              ,ss_list_price list_price
# MAGIC        from store_sales
# MAGIC            ,date_dim
# MAGIC        where ss_sold_date_sk = d_date_sk
# MAGIC          and d_year between 1999 and 1999 + 2
# MAGIC        union all
# MAGIC        select cs_quantity quantity
# MAGIC              ,cs_list_price list_price
# MAGIC        from catalog_sales
# MAGIC            ,date_dim
# MAGIC        where cs_sold_date_sk = d_date_sk
# MAGIC          and d_year between 1999 and 1999 + 2
# MAGIC        union all
# MAGIC        select ws_quantity quantity
# MAGIC              ,ws_list_price list_price
# MAGIC        from web_sales
# MAGIC            ,date_dim
# MAGIC        where ws_sold_date_sk = d_date_sk
# MAGIC          and d_year between 1999 and 1999 + 2) x)
# MAGIC   select  this_year.channel ty_channel
# MAGIC                            ,this_year.i_brand_id ty_brand
# MAGIC                            ,this_year.i_class_id ty_class
# MAGIC                            ,this_year.i_category_id ty_category
# MAGIC                            ,this_year.sales ty_sales
# MAGIC                            ,this_year.number_sales ty_number_sales
# MAGIC                            ,last_year.channel ly_channel
# MAGIC                            ,last_year.i_brand_id ly_brand
# MAGIC                            ,last_year.i_class_id ly_class
# MAGIC                            ,last_year.i_category_id ly_category
# MAGIC                            ,last_year.sales ly_sales
# MAGIC                            ,last_year.number_sales ly_number_sales 
# MAGIC  from
# MAGIC  (select 'store' channel, i_brand_id,i_class_id,i_category_id
# MAGIC         ,sum(ss_quantity*ss_list_price) sales, count(*) number_sales
# MAGIC  from store_sales 
# MAGIC      ,item
# MAGIC      ,date_dim
# MAGIC  where ss_item_sk in (select ss_item_sk from cross_items)
# MAGIC    and ss_item_sk = i_item_sk
# MAGIC    and ss_sold_date_sk = d_date_sk
# MAGIC    and d_week_seq = (select d_week_seq
# MAGIC                      from date_dim
# MAGIC                      where d_year = 1999 + 1
# MAGIC                        and d_moy = 12
# MAGIC                        and d_dom = 19)
# MAGIC  group by i_brand_id,i_class_id,i_category_id
# MAGIC  having sum(ss_quantity*ss_list_price) > (select average_sales from avg_sales)) this_year,
# MAGIC  (select 'store' channel, i_brand_id,i_class_id
# MAGIC         ,i_category_id, sum(ss_quantity*ss_list_price) sales, count(*) number_sales
# MAGIC  from store_sales
# MAGIC      ,item
# MAGIC      ,date_dim
# MAGIC  where ss_item_sk in (select ss_item_sk from cross_items)
# MAGIC    and ss_item_sk = i_item_sk
# MAGIC    and ss_sold_date_sk = d_date_sk
# MAGIC    and d_week_seq = (select d_week_seq
# MAGIC                      from date_dim
# MAGIC                      where d_year = 1999
# MAGIC                        and d_moy = 12
# MAGIC                        and d_dom = 19)
# MAGIC  group by i_brand_id,i_class_id,i_category_id
# MAGIC  having sum(ss_quantity*ss_list_price) > (select average_sales from avg_sales)) last_year
# MAGIC  where this_year.i_brand_id= last_year.i_brand_id
# MAGIC    and this_year.i_class_id = last_year.i_class_id
# MAGIC    and this_year.i_category_id = last_year.i_category_id
# MAGIC  order by this_year.channel, this_year.i_brand_id, this_year.i_class_id, this_year.i_category_id
# MAGIC  limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q15.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  ca_zip
# MAGIC        ,sum(cs_sales_price)
# MAGIC  from catalog_sales
# MAGIC      ,customer
# MAGIC      ,customer_address
# MAGIC      ,date_dim
# MAGIC  where cs_bill_customer_sk = c_customer_sk
# MAGIC  	and c_current_addr_sk = ca_address_sk 
# MAGIC  	and ( substr(ca_zip,1,5) in ('85669', '86197','88274','83405','86475',
# MAGIC                                    '85392', '85460', '80348', '81792')
# MAGIC  	      or ca_state in ('CA','WA','GA')
# MAGIC  	      or cs_sales_price > 500)
# MAGIC  	and cs_sold_date_sk = d_date_sk
# MAGIC  	and d_qoy = 1 and d_year = 1999
# MAGIC  group by ca_zip
# MAGIC  order by ca_zip
# MAGIC  limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q16.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  
# MAGIC    count(distinct cs_order_number) as `order count`
# MAGIC   ,sum(cs_ext_ship_cost) as `total shipping cost`
# MAGIC   ,sum(cs_net_profit) as `total net profit`
# MAGIC from
# MAGIC    catalog_sales cs1
# MAGIC   ,date_dim
# MAGIC   ,customer_address
# MAGIC   ,call_center
# MAGIC where
# MAGIC     d_date between '1999-4-01' and 
# MAGIC            date_add(cast('1999-4-01' as date),60)
# MAGIC and cs1.cs_ship_date_sk = d_date_sk
# MAGIC and cs1.cs_ship_addr_sk = ca_address_sk
# MAGIC and ca_state = 'WA'
# MAGIC and cs1.cs_call_center_sk = cc_call_center_sk
# MAGIC and cc_county in ('Fairfield County','Luce County','Dauphin County','Barrow County',
# MAGIC                   'Richland County'
# MAGIC )
# MAGIC and exists (select *
# MAGIC             from catalog_sales cs2
# MAGIC             where cs1.cs_order_number = cs2.cs_order_number
# MAGIC               and cs1.cs_warehouse_sk <> cs2.cs_warehouse_sk)
# MAGIC and not exists(select *
# MAGIC                from catalog_returns cr1
# MAGIC                where cs1.cs_order_number = cr1.cr_order_number)
# MAGIC order by count(distinct cs_order_number)
# MAGIC limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q17.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  i_item_id
# MAGIC        ,i_item_desc
# MAGIC        ,s_state
# MAGIC        ,count(ss_quantity) as store_sales_quantitycount
# MAGIC        ,avg(ss_quantity) as store_sales_quantityave
# MAGIC        ,stddev_samp(ss_quantity) as store_sales_quantitystdev
# MAGIC        ,stddev_samp(ss_quantity)/avg(ss_quantity) as store_sales_quantitycov
# MAGIC        ,count(sr_return_quantity) as store_returns_quantitycount
# MAGIC        ,avg(sr_return_quantity) as store_returns_quantityave
# MAGIC        ,stddev_samp(sr_return_quantity) as store_returns_quantitystdev
# MAGIC        ,stddev_samp(sr_return_quantity)/avg(sr_return_quantity) as store_returns_quantitycov
# MAGIC        ,count(cs_quantity) as catalog_sales_quantitycount ,avg(cs_quantity) as catalog_sales_quantityave
# MAGIC        ,stddev_samp(cs_quantity) as catalog_sales_quantitystdev
# MAGIC        ,stddev_samp(cs_quantity)/avg(cs_quantity) as catalog_sales_quantitycov
# MAGIC  from store_sales
# MAGIC      ,store_returns
# MAGIC      ,catalog_sales
# MAGIC      ,date_dim d1
# MAGIC      ,date_dim d2
# MAGIC      ,date_dim d3
# MAGIC      ,store
# MAGIC      ,item
# MAGIC  where d1.d_quarter_name = '2001Q1'
# MAGIC    and d1.d_date_sk = ss_sold_date_sk
# MAGIC    and i_item_sk = ss_item_sk
# MAGIC    and s_store_sk = ss_store_sk
# MAGIC    and ss_customer_sk = sr_customer_sk
# MAGIC    and ss_item_sk = sr_item_sk
# MAGIC    and ss_ticket_number = sr_ticket_number
# MAGIC    and sr_returned_date_sk = d2.d_date_sk
# MAGIC    and d2.d_quarter_name in ('2001Q1','2001Q2','2001Q3')
# MAGIC    and sr_customer_sk = cs_bill_customer_sk
# MAGIC    and sr_item_sk = cs_item_sk
# MAGIC    and cs_sold_date_sk = d3.d_date_sk
# MAGIC    and d3.d_quarter_name in ('2001Q1','2001Q2','2001Q3')
# MAGIC  group by i_item_id
# MAGIC          ,i_item_desc
# MAGIC          ,s_state
# MAGIC  order by i_item_id
# MAGIC          ,i_item_desc
# MAGIC          ,s_state
# MAGIC limit 100
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q18.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  i_item_id,
# MAGIC         ca_country,
# MAGIC         ca_state, 
# MAGIC         ca_county,
# MAGIC         avg( cast(cs_quantity as decimal(12,2))) agg1,
# MAGIC         avg( cast(cs_list_price as decimal(12,2))) agg2,
# MAGIC         avg( cast(cs_coupon_amt as decimal(12,2))) agg3,
# MAGIC         avg( cast(cs_sales_price as decimal(12,2))) agg4,
# MAGIC         avg( cast(cs_net_profit as decimal(12,2))) agg5,
# MAGIC         avg( cast(c_birth_year as decimal(12,2))) agg6,
# MAGIC         avg( cast(cd1.cd_dep_count as decimal(12,2))) agg7
# MAGIC  from catalog_sales, customer_demographics cd1, 
# MAGIC       customer_demographics cd2, customer, customer_address, date_dim, item
# MAGIC  where cs_sold_date_sk = d_date_sk and
# MAGIC        cs_item_sk = i_item_sk and
# MAGIC        cs_bill_cdemo_sk = cd1.cd_demo_sk and
# MAGIC        cs_bill_customer_sk = c_customer_sk and
# MAGIC        cd1.cd_gender = 'M' and 
# MAGIC        cd1.cd_education_status = 'Unknown' and
# MAGIC        c_current_cdemo_sk = cd2.cd_demo_sk and
# MAGIC        c_current_addr_sk = ca_address_sk and
# MAGIC        c_birth_month in (2,1,5,7,8,3) and
# MAGIC        d_year = 1998 and
# MAGIC        ca_state in ('IL','MT','WA'
# MAGIC                    ,'VT','IN','KS','SD')
# MAGIC  group by rollup (i_item_id, ca_country, ca_state, ca_county)
# MAGIC  order by ca_country,
# MAGIC         ca_state, 
# MAGIC         ca_county,
# MAGIC 	i_item_id
# MAGIC  limit 100
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q19.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  i_brand_id brand_id, i_brand brand, i_manufact_id, i_manufact,
# MAGIC  	sum(ss_ext_sales_price) ext_price
# MAGIC  from date_dim, store_sales, item,customer,customer_address,store
# MAGIC  where d_date_sk = ss_sold_date_sk
# MAGIC    and ss_item_sk = i_item_sk
# MAGIC    and i_manager_id=21
# MAGIC    and d_moy=11
# MAGIC    and d_year=1998
# MAGIC    and ss_customer_sk = c_customer_sk 
# MAGIC    and c_current_addr_sk = ca_address_sk
# MAGIC    and substr(ca_zip,1,5) <> substr(s_zip,1,5) 
# MAGIC    and ss_store_sk = s_store_sk 
# MAGIC  group by i_brand
# MAGIC       ,i_brand_id
# MAGIC       ,i_manufact_id
# MAGIC       ,i_manufact
# MAGIC  order by ext_price desc
# MAGIC          ,i_brand
# MAGIC          ,i_brand_id
# MAGIC          ,i_manufact_id
# MAGIC          ,i_manufact
# MAGIC limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q20.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  i_item_id
# MAGIC        ,i_item_desc 
# MAGIC        ,i_category 
# MAGIC        ,i_class 
# MAGIC        ,i_current_price
# MAGIC        ,sum(cs_ext_sales_price) as itemrevenue 
# MAGIC        ,sum(cs_ext_sales_price)*100/sum(sum(cs_ext_sales_price)) over
# MAGIC            (partition by i_class) as revenueratio
# MAGIC  from	catalog_sales
# MAGIC      ,item 
# MAGIC      ,date_dim
# MAGIC  where cs_item_sk = i_item_sk 
# MAGIC    and i_category in ('Men', 'Sports', 'Music')
# MAGIC    and cs_sold_date_sk = d_date_sk
# MAGIC  and d_date between cast('2002-03-25' as date) 
# MAGIC  				and date_add(cast('2002-03-25' as date),30)
# MAGIC  group by i_item_id
# MAGIC          ,i_item_desc 
# MAGIC          ,i_category
# MAGIC          ,i_class
# MAGIC          ,i_current_price
# MAGIC  order by i_category
# MAGIC          ,i_class
# MAGIC          ,i_item_id
# MAGIC          ,i_item_desc
# MAGIC          ,revenueratio
# MAGIC limit 100