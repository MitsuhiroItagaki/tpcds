# Databricks notebook source
# MAGIC %sql
# MAGIC use catalog tpcds;
# MAGIC use schema tpcds_sf1000_delta_lc;
# MAGIC set use_cached_result = false;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q1.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC with customer_total_return as (
# MAGIC   select
# MAGIC     sr_customer_sk as ctr_customer_sk,
# MAGIC     sr_store_sk as ctr_store_sk,
# MAGIC     sum(SR_RETURN_AMT) as ctr_total_return
# MAGIC   from
# MAGIC     store_returns,
# MAGIC     date_dim
# MAGIC   where
# MAGIC     sr_returned_date_sk = d_date_sk
# MAGIC     and d_year = 2002
# MAGIC   group by
# MAGIC     sr_customer_sk,
# MAGIC     sr_store_sk
# MAGIC )
# MAGIC select
# MAGIC   c_customer_id
# MAGIC from
# MAGIC   customer_total_return ctr1,
# MAGIC   store,
# MAGIC   customer
# MAGIC where
# MAGIC   ctr1.ctr_total_return > (
# MAGIC     select
# MAGIC       avg(ctr_total_return) * 1.2
# MAGIC     from
# MAGIC       customer_total_return ctr2
# MAGIC     where
# MAGIC       ctr1.ctr_store_sk = ctr2.ctr_store_sk
# MAGIC   )
# MAGIC   and s_store_sk = ctr1.ctr_store_sk
# MAGIC   and s_state = 'NM'
# MAGIC   and ctr1.ctr_customer_sk = c_customer_sk
# MAGIC order by
# MAGIC   c_customer_id
# MAGIC limit
# MAGIC   100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q2.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC with wscs as
# MAGIC  (select sold_date_sk
# MAGIC         ,sales_price
# MAGIC   from (select ws_sold_date_sk sold_date_sk
# MAGIC               ,ws_ext_sales_price sales_price
# MAGIC         from web_sales 
# MAGIC         union all
# MAGIC         select cs_sold_date_sk sold_date_sk
# MAGIC               ,cs_ext_sales_price sales_price
# MAGIC         from catalog_sales)),
# MAGIC  wswscs as 
# MAGIC  (select d_week_seq,
# MAGIC         sum(case when (d_day_name='Sunday') then sales_price else null end) sun_sales,
# MAGIC         sum(case when (d_day_name='Monday') then sales_price else null end) mon_sales,
# MAGIC         sum(case when (d_day_name='Tuesday') then sales_price else  null end) tue_sales,
# MAGIC         sum(case when (d_day_name='Wednesday') then sales_price else null end) wed_sales,
# MAGIC         sum(case when (d_day_name='Thursday') then sales_price else null end) thu_sales,
# MAGIC         sum(case when (d_day_name='Friday') then sales_price else null end) fri_sales,
# MAGIC         sum(case when (d_day_name='Saturday') then sales_price else null end) sat_sales
# MAGIC  from wscs
# MAGIC      ,date_dim
# MAGIC  where d_date_sk = sold_date_sk
# MAGIC  group by d_week_seq)
# MAGIC  select d_week_seq1
# MAGIC        ,round(sun_sales1/sun_sales2,2)
# MAGIC        ,round(mon_sales1/mon_sales2,2)
# MAGIC        ,round(tue_sales1/tue_sales2,2)
# MAGIC        ,round(wed_sales1/wed_sales2,2)
# MAGIC        ,round(thu_sales1/thu_sales2,2)
# MAGIC        ,round(fri_sales1/fri_sales2,2)
# MAGIC        ,round(sat_sales1/sat_sales2,2)
# MAGIC  from
# MAGIC  (select wswscs.d_week_seq d_week_seq1
# MAGIC         ,sun_sales sun_sales1
# MAGIC         ,mon_sales mon_sales1
# MAGIC         ,tue_sales tue_sales1
# MAGIC         ,wed_sales wed_sales1
# MAGIC         ,thu_sales thu_sales1
# MAGIC         ,fri_sales fri_sales1
# MAGIC         ,sat_sales sat_sales1
# MAGIC   from wswscs,date_dim 
# MAGIC   where date_dim.d_week_seq = wswscs.d_week_seq and
# MAGIC         d_year = 1999) y,
# MAGIC  (select wswscs.d_week_seq d_week_seq2
# MAGIC         ,sun_sales sun_sales2
# MAGIC         ,mon_sales mon_sales2
# MAGIC         ,tue_sales tue_sales2
# MAGIC         ,wed_sales wed_sales2
# MAGIC         ,thu_sales thu_sales2
# MAGIC         ,fri_sales fri_sales2
# MAGIC         ,sat_sales sat_sales2
# MAGIC   from wswscs
# MAGIC       ,date_dim 
# MAGIC   where date_dim.d_week_seq = wswscs.d_week_seq and
# MAGIC         d_year = 1999+1) z
# MAGIC  where d_week_seq1=d_week_seq2-53
# MAGIC  order by d_week_seq1

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q3.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select
# MAGIC   dt.d_year,
# MAGIC   item.i_brand_id brand_id,
# MAGIC   item.i_brand brand,
# MAGIC   sum(ss_ext_sales_price) sum_agg
# MAGIC from
# MAGIC   date_dim dt,
# MAGIC   store_sales,
# MAGIC   item
# MAGIC where
# MAGIC   dt.d_date_sk = store_sales.ss_sold_date_sk
# MAGIC   and store_sales.ss_item_sk = item.i_item_sk
# MAGIC   and item.i_manufact_id = 710
# MAGIC   and dt.d_moy = 12
# MAGIC group by
# MAGIC   dt.d_year,
# MAGIC   item.i_brand,
# MAGIC   item.i_brand_id
# MAGIC order by
# MAGIC   dt.d_year,
# MAGIC   sum_agg desc,
# MAGIC   brand_id
# MAGIC limit
# MAGIC   100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q4.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC with year_total as (
# MAGIC  select c_customer_id customer_id
# MAGIC        ,c_first_name customer_first_name
# MAGIC        ,c_last_name customer_last_name
# MAGIC        ,c_preferred_cust_flag customer_preferred_cust_flag
# MAGIC        ,c_birth_country customer_birth_country
# MAGIC        ,c_login customer_login
# MAGIC        ,c_email_address customer_email_address
# MAGIC        ,d_year dyear
# MAGIC        ,sum(((ss_ext_list_price-ss_ext_wholesale_cost-ss_ext_discount_amt)+ss_ext_sales_price)/2) year_total
# MAGIC        ,'s' sale_type
# MAGIC  from customer
# MAGIC      ,store_sales
# MAGIC      ,date_dim
# MAGIC  where c_customer_sk = ss_customer_sk
# MAGIC    and ss_sold_date_sk = d_date_sk
# MAGIC  group by c_customer_id
# MAGIC          ,c_first_name
# MAGIC          ,c_last_name
# MAGIC          ,c_preferred_cust_flag
# MAGIC          ,c_birth_country
# MAGIC          ,c_login
# MAGIC          ,c_email_address
# MAGIC          ,d_year
# MAGIC  union all
# MAGIC  select c_customer_id customer_id
# MAGIC        ,c_first_name customer_first_name
# MAGIC        ,c_last_name customer_last_name
# MAGIC        ,c_preferred_cust_flag customer_preferred_cust_flag
# MAGIC        ,c_birth_country customer_birth_country
# MAGIC        ,c_login customer_login
# MAGIC        ,c_email_address customer_email_address
# MAGIC        ,d_year dyear
# MAGIC        ,sum((((cs_ext_list_price-cs_ext_wholesale_cost-cs_ext_discount_amt)+cs_ext_sales_price)/2) ) year_total
# MAGIC        ,'c' sale_type
# MAGIC  from customer
# MAGIC      ,catalog_sales
# MAGIC      ,date_dim
# MAGIC  where c_customer_sk = cs_bill_customer_sk
# MAGIC    and cs_sold_date_sk = d_date_sk
# MAGIC  group by c_customer_id
# MAGIC          ,c_first_name
# MAGIC          ,c_last_name
# MAGIC          ,c_preferred_cust_flag
# MAGIC          ,c_birth_country
# MAGIC          ,c_login
# MAGIC          ,c_email_address
# MAGIC          ,d_year
# MAGIC union all
# MAGIC  select c_customer_id customer_id
# MAGIC        ,c_first_name customer_first_name
# MAGIC        ,c_last_name customer_last_name
# MAGIC        ,c_preferred_cust_flag customer_preferred_cust_flag
# MAGIC        ,c_birth_country customer_birth_country
# MAGIC        ,c_login customer_login
# MAGIC        ,c_email_address customer_email_address
# MAGIC        ,d_year dyear
# MAGIC        ,sum((((ws_ext_list_price-ws_ext_wholesale_cost-ws_ext_discount_amt)+ws_ext_sales_price)/2) ) year_total
# MAGIC        ,'w' sale_type
# MAGIC  from customer
# MAGIC      ,web_sales
# MAGIC      ,date_dim
# MAGIC  where c_customer_sk = ws_bill_customer_sk
# MAGIC    and ws_sold_date_sk = d_date_sk
# MAGIC  group by c_customer_id
# MAGIC          ,c_first_name
# MAGIC          ,c_last_name
# MAGIC          ,c_preferred_cust_flag
# MAGIC          ,c_birth_country
# MAGIC          ,c_login
# MAGIC          ,c_email_address
# MAGIC          ,d_year
# MAGIC          )
# MAGIC   select  
# MAGIC                   t_s_secyear.customer_id
# MAGIC                  ,t_s_secyear.customer_first_name
# MAGIC                  ,t_s_secyear.customer_last_name
# MAGIC                  ,t_s_secyear.customer_email_address
# MAGIC  from year_total t_s_firstyear
# MAGIC      ,year_total t_s_secyear
# MAGIC      ,year_total t_c_firstyear
# MAGIC      ,year_total t_c_secyear
# MAGIC      ,year_total t_w_firstyear
# MAGIC      ,year_total t_w_secyear
# MAGIC  where t_s_secyear.customer_id = t_s_firstyear.customer_id
# MAGIC    and t_s_firstyear.customer_id = t_c_secyear.customer_id
# MAGIC    and t_s_firstyear.customer_id = t_c_firstyear.customer_id
# MAGIC    and t_s_firstyear.customer_id = t_w_firstyear.customer_id
# MAGIC    and t_s_firstyear.customer_id = t_w_secyear.customer_id
# MAGIC    and t_s_firstyear.sale_type = 's'
# MAGIC    and t_c_firstyear.sale_type = 'c'
# MAGIC    and t_w_firstyear.sale_type = 'w'
# MAGIC    and t_s_secyear.sale_type = 's'
# MAGIC    and t_c_secyear.sale_type = 'c'
# MAGIC    and t_w_secyear.sale_type = 'w'
# MAGIC    and t_s_firstyear.dyear =  2001
# MAGIC    and t_s_secyear.dyear = 2001+1
# MAGIC    and t_c_firstyear.dyear =  2001
# MAGIC    and t_c_secyear.dyear =  2001+1
# MAGIC    and t_w_firstyear.dyear = 2001
# MAGIC    and t_w_secyear.dyear = 2001+1
# MAGIC    and t_s_firstyear.year_total > 0
# MAGIC    and t_c_firstyear.year_total > 0
# MAGIC    and t_w_firstyear.year_total > 0
# MAGIC    and case when t_c_firstyear.year_total > 0 then t_c_secyear.year_total / t_c_firstyear.year_total else null end
# MAGIC            > case when t_s_firstyear.year_total > 0 then t_s_secyear.year_total / t_s_firstyear.year_total else null end
# MAGIC    and case when t_c_firstyear.year_total > 0 then t_c_secyear.year_total / t_c_firstyear.year_total else null end
# MAGIC            > case when t_w_firstyear.year_total > 0 then t_w_secyear.year_total / t_w_firstyear.year_total else null end
# MAGIC  order by t_s_secyear.customer_id
# MAGIC          ,t_s_secyear.customer_first_name
# MAGIC          ,t_s_secyear.customer_last_name
# MAGIC          ,t_s_secyear.customer_email_address
# MAGIC limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q5.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC with ssr as
# MAGIC  (select s_store_id,
# MAGIC         sum(sales_price) as sales,
# MAGIC         sum(profit) as profit,
# MAGIC         sum(return_amt) as returns,
# MAGIC         sum(net_loss) as profit_loss
# MAGIC  from
# MAGIC   ( select  ss_store_sk as store_sk,
# MAGIC             ss_sold_date_sk  as date_sk,
# MAGIC             ss_ext_sales_price as sales_price,
# MAGIC             ss_net_profit as profit,
# MAGIC             cast(0 as decimal(7,2)) as return_amt,
# MAGIC             cast(0 as decimal(7,2)) as net_loss
# MAGIC     from store_sales
# MAGIC     union all
# MAGIC     select sr_store_sk as store_sk,
# MAGIC            sr_returned_date_sk as date_sk,
# MAGIC            cast(0 as decimal(7,2)) as sales_price,
# MAGIC            cast(0 as decimal(7,2)) as profit,
# MAGIC            sr_return_amt as return_amt,
# MAGIC            sr_net_loss as net_loss
# MAGIC     from store_returns
# MAGIC    ) salesreturns,
# MAGIC      date_dim,
# MAGIC      store
# MAGIC  where date_sk = d_date_sk
# MAGIC        and d_date between cast('2002-08-28' as date) 
# MAGIC                   and date_add(cast('2002-08-28' as date),14)
# MAGIC        and store_sk = s_store_sk
# MAGIC  group by s_store_id)
# MAGIC  ,
# MAGIC  csr as
# MAGIC  (select cp_catalog_page_id,
# MAGIC         sum(sales_price) as sales,
# MAGIC         sum(profit) as profit,
# MAGIC         sum(return_amt) as returns,
# MAGIC         sum(net_loss) as profit_loss
# MAGIC  from
# MAGIC   ( select  cs_catalog_page_sk as page_sk,
# MAGIC             cs_sold_date_sk  as date_sk,
# MAGIC             cs_ext_sales_price as sales_price,
# MAGIC             cs_net_profit as profit,
# MAGIC             cast(0 as decimal(7,2)) as return_amt,
# MAGIC             cast(0 as decimal(7,2)) as net_loss
# MAGIC     from catalog_sales
# MAGIC     union all
# MAGIC     select cr_catalog_page_sk as page_sk,
# MAGIC            cr_returned_date_sk as date_sk,
# MAGIC            cast(0 as decimal(7,2)) as sales_price,
# MAGIC            cast(0 as decimal(7,2)) as profit,
# MAGIC            cr_return_amount as return_amt,
# MAGIC            cr_net_loss as net_loss
# MAGIC     from catalog_returns
# MAGIC    ) salesreturns,
# MAGIC      date_dim,
# MAGIC      catalog_page
# MAGIC  where date_sk = d_date_sk
# MAGIC        and d_date between cast('2002-08-28' as date)
# MAGIC                   and date_add(cast('2002-08-28' as date),14)
# MAGIC        and page_sk = cp_catalog_page_sk
# MAGIC  group by cp_catalog_page_id)
# MAGIC  ,
# MAGIC  wsr as
# MAGIC  (select web_site_id,
# MAGIC         sum(sales_price) as sales,
# MAGIC         sum(profit) as profit,
# MAGIC         sum(return_amt) as returns,
# MAGIC         sum(net_loss) as profit_loss
# MAGIC  from
# MAGIC   ( select  ws_web_site_sk as wsr_web_site_sk,
# MAGIC             ws_sold_date_sk  as date_sk,
# MAGIC             ws_ext_sales_price as sales_price,
# MAGIC             ws_net_profit as profit,
# MAGIC             cast(0 as decimal(7,2)) as return_amt,
# MAGIC             cast(0 as decimal(7,2)) as net_loss
# MAGIC     from web_sales
# MAGIC     union all
# MAGIC     select ws_web_site_sk as wsr_web_site_sk,
# MAGIC            wr_returned_date_sk as date_sk,
# MAGIC            cast(0 as decimal(7,2)) as sales_price,
# MAGIC            cast(0 as decimal(7,2)) as profit,
# MAGIC            wr_return_amt as return_amt,
# MAGIC            wr_net_loss as net_loss
# MAGIC     from web_returns left outer join web_sales on
# MAGIC          ( wr_item_sk = ws_item_sk
# MAGIC            and wr_order_number = ws_order_number)
# MAGIC    ) salesreturns,
# MAGIC      date_dim,
# MAGIC      web_site
# MAGIC  where date_sk = d_date_sk
# MAGIC        and d_date between cast('2002-08-28' as date)
# MAGIC                   and date_add(cast('2002-08-28' as date),14)
# MAGIC        and wsr_web_site_sk = web_site_sk
# MAGIC  group by web_site_id)
# MAGIC   select  channel
# MAGIC         , id
# MAGIC         , sum(sales) as sales
# MAGIC         , sum(returns) as returns
# MAGIC         , sum(profit) as profit
# MAGIC  from 
# MAGIC  (select 'store channel' as channel
# MAGIC         , 'store' || s_store_id as id
# MAGIC         , sales
# MAGIC         , returns
# MAGIC         , (profit - profit_loss) as profit
# MAGIC  from   ssr
# MAGIC  union all
# MAGIC  select 'catalog channel' as channel
# MAGIC         , 'catalog_page' || cp_catalog_page_id as id
# MAGIC         , sales
# MAGIC         , returns
# MAGIC         , (profit - profit_loss) as profit
# MAGIC  from  csr
# MAGIC  union all
# MAGIC  select 'web channel' as channel
# MAGIC         , 'web_site' || web_site_id as id
# MAGIC         , sales
# MAGIC         , returns
# MAGIC         , (profit - profit_loss) as profit
# MAGIC  from   wsr
# MAGIC  ) x
# MAGIC  group by rollup (channel, id)
# MAGIC  order by channel
# MAGIC          ,id
# MAGIC  limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q6.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  a.ca_state state, count(*) cnt
# MAGIC  from customer_address a
# MAGIC      ,customer c
# MAGIC      ,store_sales s
# MAGIC      ,date_dim d
# MAGIC      ,item i
# MAGIC  where       a.ca_address_sk = c.c_current_addr_sk
# MAGIC  	and c.c_customer_sk = s.ss_customer_sk
# MAGIC  	and s.ss_sold_date_sk = d.d_date_sk
# MAGIC  	and s.ss_item_sk = i.i_item_sk
# MAGIC  	and d.d_month_seq = 
# MAGIC  	     (select distinct (d_month_seq)
# MAGIC  	      from date_dim
# MAGIC                where d_year = 2002
# MAGIC  	        and d_moy = 3 )
# MAGIC  	and i.i_current_price > 1.2 * 
# MAGIC              (select avg(j.i_current_price) 
# MAGIC  	     from item j 
# MAGIC  	     where j.i_category = i.i_category)
# MAGIC  group by a.ca_state
# MAGIC  having count(*) >= 10
# MAGIC  order by cnt, a.ca_state 
# MAGIC  limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q7.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  i_item_id, 
# MAGIC         avg(ss_quantity) agg1,
# MAGIC         avg(ss_list_price) agg2,
# MAGIC         avg(ss_coupon_amt) agg3,
# MAGIC         avg(ss_sales_price) agg4 
# MAGIC  from store_sales, customer_demographics, date_dim, item, promotion
# MAGIC  where ss_sold_date_sk = d_date_sk and
# MAGIC        ss_item_sk = i_item_sk and
# MAGIC        ss_cdemo_sk = cd_demo_sk and
# MAGIC        ss_promo_sk = p_promo_sk and
# MAGIC        cd_gender = 'F' and 
# MAGIC        cd_marital_status = 'S' and
# MAGIC        cd_education_status = 'College' and
# MAGIC        (p_channel_email = 'N' or p_channel_event = 'N') and
# MAGIC        d_year = 2002 
# MAGIC  group by i_item_id
# MAGIC  order by i_item_id
# MAGIC  limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q8.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  s_store_name
# MAGIC       ,sum(ss_net_profit)
# MAGIC  from store_sales
# MAGIC      ,date_dim
# MAGIC      ,store,
# MAGIC      (select ca_zip
# MAGIC      from (
# MAGIC       SELECT substr(ca_zip,1,5) ca_zip
# MAGIC       FROM customer_address
# MAGIC       WHERE substr(ca_zip,1,5) IN (
# MAGIC                           '19939','15415','99532','88109','38905','19375',
# MAGIC                           '56530','18362','35416','27628','20661',
# MAGIC                           '58398','88211','57824','75429','16379',
# MAGIC                           '68109','51982','66597','88140','14017',
# MAGIC                           '44159','60809','65904','73149','96224',
# MAGIC                           '92063','12567','78972','63040','68165',
# MAGIC                           '54050','11163','22929','73892','56920',
# MAGIC                           '52933','19156','71726','33409','65018',
# MAGIC                           '44771','36812','73971','61941','61299',
# MAGIC                           '49344','12756','21081','84478','87438',
# MAGIC                           '29983','67772','27451','39916','45766',
# MAGIC                           '35274','30734','54935','33483','53235',
# MAGIC                           '25329','16082','11293','35637','38153',
# MAGIC                           '37539','89687','53387','98013','57817',
# MAGIC                           '26971','18865','17944','52891','52856',
# MAGIC                           '45241','67343','60253','20965','41056',
# MAGIC                           '88979','53759','96810','53439','14575',
# MAGIC                           '70802','61481','19025','72666','40770',
# MAGIC                           '76110','16417','34436','59210','52858',
# MAGIC                           '72918','87387','73453','29496','43314',
# MAGIC                           '39448','19263','13178','34900','39401',
# MAGIC                           '21274','52207','20946','79761','19120',
# MAGIC                           '74955','13144','43265','64156','29767',
# MAGIC                           '84885','38686','68517','10798','45293',
# MAGIC                           '95575','13753','71966','45132','33216',
# MAGIC                           '52462','82154','74882','22943','37620',
# MAGIC                           '82326','10508','29439','19689','57959',
# MAGIC                           '31232','62344','55851','22384','58946',
# MAGIC                           '36144','12988','24773','87033','10175',
# MAGIC                           '64061','96507','30874','48827','72137',
# MAGIC                           '23783','93874','95190','58465','53478',
# MAGIC                           '30252','40177','68295','23826','48490',
# MAGIC                           '52295','18696','54503','47586','65441',
# MAGIC                           '41599','67646','12498','15048','50271',
# MAGIC                           '76221','68359','61907','45680','44941',
# MAGIC                           '46094','49039','11893','28124','34648',
# MAGIC                           '96966','20444','19766','34211','83840',
# MAGIC                           '10321','59206','45418','55810','43185',
# MAGIC                           '40974','40174','90586','58461','32033',
# MAGIC                           '88417','22559','61475','37287','32411',
# MAGIC                           '19344','31100','14371','47157','70357',
# MAGIC                           '81715','42708','28845','96699','29479',
# MAGIC                           '78676','50907','26621','65545','64296',
# MAGIC                           '36498','11386','41035','37947','78291',
# MAGIC                           '82294','59198','25007','18680','23836',
# MAGIC                           '52776','98361','62030','26548','66096',
# MAGIC                           '15140','31380','49667','39914','99907',
# MAGIC                           '16857','62044','28777','93103','22948',
# MAGIC                           '40161','71942','10310','98447','88078',
# MAGIC                           '44055','95729','36187','68260','74272',
# MAGIC                           '90765','15915','25236','58291','61415',
# MAGIC                           '30779','44758','97585','53982','75935',
# MAGIC                           '57017','22885','42172','62490','40490',
# MAGIC                           '92295','63916','42694','17390','64268',
# MAGIC                           '28981','27902','21847','56904','49052',
# MAGIC                           '17126','56821','94231','49070','32440',
# MAGIC                           '57887','11181','93658','12680','19027',
# MAGIC                           '85456','11766','41052','89239','85444',
# MAGIC                           '89958','29684','96147','36784','20763',
# MAGIC                           '36075','55806','11311','34643','99846',
# MAGIC                           '77309','57759','43925','29842','45898',
# MAGIC                           '92435','24590','47594','66679','37547',
# MAGIC                           '27104','22383','46707','15873','35468',
# MAGIC                           '84671','79278','11415','44776','35562',
# MAGIC                           '22428','32065','42884','76029','29889',
# MAGIC                           '85500','84166','70983','92239','94371',
# MAGIC                           '83364','97939','45304','13680','14815',
# MAGIC                           '87181','69068','76527','63391','14503',
# MAGIC                           '57782','48931','65516','56554','85580',
# MAGIC                           '90893','60804','73481','99879','68889',
# MAGIC                           '91973','20870','28187','38899','67801',
# MAGIC                           '33154','97449','30611','35311','23817',
# MAGIC                           '25504','49676','26416','93102','32039',
# MAGIC                           '88476','30700','96307','49298','16571',
# MAGIC                           '71649','99513','14618','15923','33480',
# MAGIC                           '16134','13077','11702','17549','44911',
# MAGIC                           '14615','20814','56957','58210','32581',
# MAGIC                           '11811','61363','57280','29426','72062',
# MAGIC                           '16363','25526','27317','70631','83257',
# MAGIC                           '78846','84367','38731','94258')
# MAGIC      intersect
# MAGIC       select ca_zip
# MAGIC       from (SELECT substr(ca_zip,1,5) ca_zip,count(*) cnt
# MAGIC             FROM customer_address, customer
# MAGIC             WHERE ca_address_sk = c_current_addr_sk and
# MAGIC                   c_preferred_cust_flag='Y'
# MAGIC             group by ca_zip
# MAGIC             having count(*) > 10)A1)A2) V1
# MAGIC  where ss_store_sk = s_store_sk
# MAGIC   and ss_sold_date_sk = d_date_sk
# MAGIC   and d_qoy = 1 and d_year = 2001
# MAGIC   and (substr(s_zip,1,2) = substr(V1.ca_zip,1,2))
# MAGIC  group by s_store_name
# MAGIC  order by s_store_name
# MAGIC  limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q9.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select case when (select count(*) 
# MAGIC                   from store_sales 
# MAGIC                   where ss_quantity between 1 and 20) > 653676775
# MAGIC             then (select avg(ss_ext_tax) 
# MAGIC                   from store_sales 
# MAGIC                   where ss_quantity between 1 and 20) 
# MAGIC             else (select avg(ss_net_paid_inc_tax)
# MAGIC                   from store_sales
# MAGIC                   where ss_quantity between 1 and 20) end bucket1 ,
# MAGIC        case when (select count(*)
# MAGIC                   from store_sales
# MAGIC                   where ss_quantity between 21 and 40) > 730830854
# MAGIC             then (select avg(ss_ext_tax)
# MAGIC                   from store_sales
# MAGIC                   where ss_quantity between 21 and 40) 
# MAGIC             else (select avg(ss_net_paid_inc_tax)
# MAGIC                   from store_sales
# MAGIC                   where ss_quantity between 21 and 40) end bucket2,
# MAGIC        case when (select count(*)
# MAGIC                   from store_sales
# MAGIC                   where ss_quantity between 41 and 60) > 451895667
# MAGIC             then (select avg(ss_ext_tax)
# MAGIC                   from store_sales
# MAGIC                   where ss_quantity between 41 and 60)
# MAGIC             else (select avg(ss_net_paid_inc_tax)
# MAGIC                   from store_sales
# MAGIC                   where ss_quantity between 41 and 60) end bucket3,
# MAGIC        case when (select count(*)
# MAGIC                   from store_sales
# MAGIC                   where ss_quantity between 61 and 80) > 367088927
# MAGIC             then (select avg(ss_ext_tax)
# MAGIC                   from store_sales
# MAGIC                   where ss_quantity between 61 and 80)
# MAGIC             else (select avg(ss_net_paid_inc_tax)
# MAGIC                   from store_sales
# MAGIC                   where ss_quantity between 61 and 80) end bucket4,
# MAGIC        case when (select count(*)
# MAGIC                   from store_sales
# MAGIC                   where ss_quantity between 81 and 100) > 1354293848
# MAGIC             then (select avg(ss_ext_tax)
# MAGIC                   from store_sales
# MAGIC                   where ss_quantity between 81 and 100)
# MAGIC             else (select avg(ss_net_paid_inc_tax)
# MAGIC                   from store_sales
# MAGIC                   where ss_quantity between 81 and 100) end bucket5
# MAGIC from reason
# MAGIC where r_reason_sk = 1
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q10.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  
# MAGIC   cd_gender,
# MAGIC   cd_marital_status,
# MAGIC   cd_education_status,
# MAGIC   count(*) cnt1,
# MAGIC   cd_purchase_estimate,
# MAGIC   count(*) cnt2,
# MAGIC   cd_credit_rating,
# MAGIC   count(*) cnt3,
# MAGIC   cd_dep_count,
# MAGIC   count(*) cnt4,
# MAGIC   cd_dep_employed_count,
# MAGIC   count(*) cnt5,
# MAGIC   cd_dep_college_count,
# MAGIC   count(*) cnt6
# MAGIC  from
# MAGIC   customer c,customer_address ca,customer_demographics
# MAGIC  where
# MAGIC   c.c_current_addr_sk = ca.ca_address_sk and
# MAGIC   ca_county in ('Conway County','Deer Lodge County','Valencia County','Portsmouth city','Daviess County') and
# MAGIC   cd_demo_sk = c.c_current_cdemo_sk and 
# MAGIC   exists (select *
# MAGIC           from store_sales,date_dim
# MAGIC           where c.c_customer_sk = ss_customer_sk and
# MAGIC                 ss_sold_date_sk = d_date_sk and
# MAGIC                 d_year = 2001 and
# MAGIC                 d_moy between 2 and 2+3) and
# MAGIC    (exists (select *
# MAGIC             from web_sales,date_dim
# MAGIC             where c.c_customer_sk = ws_bill_customer_sk and
# MAGIC                   ws_sold_date_sk = d_date_sk and
# MAGIC                   d_year = 2001 and
# MAGIC                   d_moy between 2 ANd 2+3) or 
# MAGIC     exists (select * 
# MAGIC             from catalog_sales,date_dim
# MAGIC             where c.c_customer_sk = cs_ship_customer_sk and
# MAGIC                   cs_sold_date_sk = d_date_sk and
# MAGIC                   d_year = 2001 and
# MAGIC                   d_moy between 2 and 2+3))
# MAGIC  group by cd_gender,
# MAGIC           cd_marital_status,
# MAGIC           cd_education_status,
# MAGIC           cd_purchase_estimate,
# MAGIC           cd_credit_rating,
# MAGIC           cd_dep_count,
# MAGIC           cd_dep_employed_count,
# MAGIC           cd_dep_college_count
# MAGIC  order by cd_gender,
# MAGIC           cd_marital_status,
# MAGIC           cd_education_status,
# MAGIC           cd_purchase_estimate,
# MAGIC           cd_credit_rating,
# MAGIC           cd_dep_count,
# MAGIC           cd_dep_employed_count,
# MAGIC           cd_dep_college_count
# MAGIC limit 100