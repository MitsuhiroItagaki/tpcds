# Databricks notebook source
# MAGIC %sql
# MAGIC use catalog tpcds;
# MAGIC use schema tpcds_sf1000_delta_lc;
# MAGIC set use_cached_result = false;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q71.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select i_brand_id brand_id, i_brand brand,t_hour,t_minute,
# MAGIC  	sum(ext_price) ext_price
# MAGIC  from item, (select ws_ext_sales_price as ext_price, 
# MAGIC                         ws_sold_date_sk as sold_date_sk,
# MAGIC                         ws_item_sk as sold_item_sk,
# MAGIC                         ws_sold_time_sk as time_sk  
# MAGIC                  from web_sales,date_dim
# MAGIC                  where d_date_sk = ws_sold_date_sk
# MAGIC                    and d_moy=11
# MAGIC                    and d_year=2002
# MAGIC                  union all
# MAGIC                  select cs_ext_sales_price as ext_price,
# MAGIC                         cs_sold_date_sk as sold_date_sk,
# MAGIC                         cs_item_sk as sold_item_sk,
# MAGIC                         cs_sold_time_sk as time_sk
# MAGIC                  from catalog_sales,date_dim
# MAGIC                  where d_date_sk = cs_sold_date_sk
# MAGIC                    and d_moy=11
# MAGIC                    and d_year=2002
# MAGIC                  union all
# MAGIC                  select ss_ext_sales_price as ext_price,
# MAGIC                         ss_sold_date_sk as sold_date_sk,
# MAGIC                         ss_item_sk as sold_item_sk,
# MAGIC                         ss_sold_time_sk as time_sk
# MAGIC                  from store_sales,date_dim
# MAGIC                  where d_date_sk = ss_sold_date_sk
# MAGIC                    and d_moy=11
# MAGIC                    and d_year=2002
# MAGIC                  ) tmp,time_dim
# MAGIC  where
# MAGIC    sold_item_sk = i_item_sk
# MAGIC    and i_manager_id=1
# MAGIC    and time_sk = t_time_sk
# MAGIC    and (t_meal_time = 'breakfast' or t_meal_time = 'dinner')
# MAGIC  group by i_brand, i_brand_id,t_hour,t_minute
# MAGIC  order by ext_price desc, i_brand_id

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q72.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  i_item_desc
# MAGIC       ,w_warehouse_name
# MAGIC       ,d1.d_week_seq
# MAGIC       ,sum(case when p_promo_sk is null then 1 else 0 end) no_promo
# MAGIC       ,sum(case when p_promo_sk is not null then 1 else 0 end) promo
# MAGIC       ,count(*) total_cnt
# MAGIC from catalog_sales
# MAGIC join inventory on (cs_item_sk = inv_item_sk)
# MAGIC join warehouse on (w_warehouse_sk=inv_warehouse_sk)
# MAGIC join item on (i_item_sk = cs_item_sk)
# MAGIC join customer_demographics on (cs_bill_cdemo_sk = cd_demo_sk)
# MAGIC join household_demographics on (cs_bill_hdemo_sk = hd_demo_sk)
# MAGIC join date_dim d1 on (cs_sold_date_sk = d1.d_date_sk)
# MAGIC join date_dim d2 on (inv_date_sk = d2.d_date_sk)
# MAGIC join date_dim d3 on (cs_ship_date_sk = d3.d_date_sk)
# MAGIC left outer join promotion on (cs_promo_sk=p_promo_sk)
# MAGIC left outer join catalog_returns on (cr_item_sk = cs_item_sk and cr_order_number = cs_order_number)
# MAGIC where d1.d_week_seq = d2.d_week_seq
# MAGIC   and inv_quantity_on_hand < cs_quantity 
# MAGIC   and d3.d_date > date_add(d1.d_date,5)
# MAGIC   and hd_buy_potential = '1001-5000'
# MAGIC   and d1.d_year = 2001
# MAGIC   and cd_marital_status = 'U'
# MAGIC group by i_item_desc,w_warehouse_name,d1.d_week_seq
# MAGIC order by total_cnt desc, i_item_desc, w_warehouse_name, d_week_seq
# MAGIC limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q73.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select c_last_name
# MAGIC        ,c_first_name
# MAGIC        ,c_salutation
# MAGIC        ,c_preferred_cust_flag 
# MAGIC        ,ss_ticket_number
# MAGIC        ,cnt from
# MAGIC    (select ss_ticket_number
# MAGIC           ,ss_customer_sk
# MAGIC           ,count(*) cnt
# MAGIC     from store_sales,date_dim,store,household_demographics
# MAGIC     where store_sales.ss_sold_date_sk = date_dim.d_date_sk
# MAGIC     and store_sales.ss_store_sk = store.s_store_sk  
# MAGIC     and store_sales.ss_hdemo_sk = household_demographics.hd_demo_sk
# MAGIC     and date_dim.d_dom between 1 and 2 
# MAGIC     and (household_demographics.hd_buy_potential = '501-1000' or
# MAGIC          household_demographics.hd_buy_potential = '5001-10000')
# MAGIC     and household_demographics.hd_vehicle_count > 0
# MAGIC     and case when household_demographics.hd_vehicle_count > 0 then 
# MAGIC              household_demographics.hd_dep_count/ household_demographics.hd_vehicle_count else null end > 1
# MAGIC     and date_dim.d_year in (1999,1999+1,1999+2)
# MAGIC     and store.s_county in ('Tompkins County','Richland County','Huron County','Kittitas County')
# MAGIC     group by ss_ticket_number,ss_customer_sk) dj,customer
# MAGIC     where ss_customer_sk = c_customer_sk
# MAGIC       and cnt between 1 and 5
# MAGIC     order by cnt desc, c_last_name asc

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q74.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC with year_total as (
# MAGIC  select c_customer_id customer_id
# MAGIC        ,c_first_name customer_first_name
# MAGIC        ,c_last_name customer_last_name
# MAGIC        ,d_year as year
# MAGIC        ,min(ss_net_paid) year_total
# MAGIC        ,'s' sale_type
# MAGIC  from customer
# MAGIC      ,store_sales
# MAGIC      ,date_dim
# MAGIC  where c_customer_sk = ss_customer_sk
# MAGIC    and ss_sold_date_sk = d_date_sk
# MAGIC    and d_year in (2001,2001+1)
# MAGIC  group by c_customer_id
# MAGIC          ,c_first_name
# MAGIC          ,c_last_name
# MAGIC          ,d_year
# MAGIC  union all
# MAGIC  select c_customer_id customer_id
# MAGIC        ,c_first_name customer_first_name
# MAGIC        ,c_last_name customer_last_name
# MAGIC        ,d_year as year
# MAGIC        ,min(ws_net_paid) year_total
# MAGIC        ,'w' sale_type
# MAGIC  from customer
# MAGIC      ,web_sales
# MAGIC      ,date_dim
# MAGIC  where c_customer_sk = ws_bill_customer_sk
# MAGIC    and ws_sold_date_sk = d_date_sk
# MAGIC    and d_year in (2001,2001+1)
# MAGIC  group by c_customer_id
# MAGIC          ,c_first_name
# MAGIC          ,c_last_name
# MAGIC          ,d_year
# MAGIC          )
# MAGIC   select 
# MAGIC         t_s_secyear.customer_id, t_s_secyear.customer_first_name, t_s_secyear.customer_last_name
# MAGIC  from year_total t_s_firstyear
# MAGIC      ,year_total t_s_secyear
# MAGIC      ,year_total t_w_firstyear
# MAGIC      ,year_total t_w_secyear
# MAGIC  where t_s_secyear.customer_id = t_s_firstyear.customer_id
# MAGIC          and t_s_firstyear.customer_id = t_w_secyear.customer_id
# MAGIC          and t_s_firstyear.customer_id = t_w_firstyear.customer_id
# MAGIC          and t_s_firstyear.sale_type = 's'
# MAGIC          and t_w_firstyear.sale_type = 'w'
# MAGIC          and t_s_secyear.sale_type = 's'
# MAGIC          and t_w_secyear.sale_type = 'w'
# MAGIC          and t_s_firstyear.year = 2001
# MAGIC          and t_s_secyear.year = 2001+1
# MAGIC          and t_w_firstyear.year = 2001
# MAGIC          and t_w_secyear.year = 2001+1
# MAGIC          and t_s_firstyear.year_total > 0
# MAGIC          and t_w_firstyear.year_total > 0
# MAGIC          and case when t_w_firstyear.year_total > 0 then t_w_secyear.year_total / t_w_firstyear.year_total else null end
# MAGIC            > case when t_s_firstyear.year_total > 0 then t_s_secyear.year_total / t_s_firstyear.year_total else null end
# MAGIC  order by 2,3,1
# MAGIC limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q75.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC WITH all_sales AS (
# MAGIC  SELECT d_year
# MAGIC        ,i_brand_id
# MAGIC        ,i_class_id
# MAGIC        ,i_category_id
# MAGIC        ,i_manufact_id
# MAGIC        ,SUM(sales_cnt) AS sales_cnt
# MAGIC        ,SUM(sales_amt) AS sales_amt
# MAGIC  FROM (SELECT d_year
# MAGIC              ,i_brand_id
# MAGIC              ,i_class_id
# MAGIC              ,i_category_id
# MAGIC              ,i_manufact_id
# MAGIC              ,cs_quantity - COALESCE(cr_return_quantity,0) AS sales_cnt
# MAGIC              ,cs_ext_sales_price - COALESCE(cr_return_amount,0.0) AS sales_amt
# MAGIC        FROM catalog_sales JOIN item ON i_item_sk=cs_item_sk
# MAGIC                           JOIN date_dim ON d_date_sk=cs_sold_date_sk
# MAGIC                           LEFT JOIN catalog_returns ON (cs_order_number=cr_order_number 
# MAGIC                                                     AND cs_item_sk=cr_item_sk)
# MAGIC        WHERE i_category='Women'
# MAGIC        UNION
# MAGIC        SELECT d_year
# MAGIC              ,i_brand_id
# MAGIC              ,i_class_id
# MAGIC              ,i_category_id
# MAGIC              ,i_manufact_id
# MAGIC              ,ss_quantity - COALESCE(sr_return_quantity,0) AS sales_cnt
# MAGIC              ,ss_ext_sales_price - COALESCE(sr_return_amt,0.0) AS sales_amt
# MAGIC        FROM store_sales JOIN item ON i_item_sk=ss_item_sk
# MAGIC                         JOIN date_dim ON d_date_sk=ss_sold_date_sk
# MAGIC                         LEFT JOIN store_returns ON (ss_ticket_number=sr_ticket_number 
# MAGIC                                                 AND ss_item_sk=sr_item_sk)
# MAGIC        WHERE i_category='Women'
# MAGIC        UNION
# MAGIC        SELECT d_year
# MAGIC              ,i_brand_id
# MAGIC              ,i_class_id
# MAGIC              ,i_category_id
# MAGIC              ,i_manufact_id
# MAGIC              ,ws_quantity - COALESCE(wr_return_quantity,0) AS sales_cnt
# MAGIC              ,ws_ext_sales_price - COALESCE(wr_return_amt,0.0) AS sales_amt
# MAGIC        FROM web_sales JOIN item ON i_item_sk=ws_item_sk
# MAGIC                       JOIN date_dim ON d_date_sk=ws_sold_date_sk
# MAGIC                       LEFT JOIN web_returns ON (ws_order_number=wr_order_number 
# MAGIC                                             AND ws_item_sk=wr_item_sk)
# MAGIC        WHERE i_category='Women') sales_detail
# MAGIC  GROUP BY d_year, i_brand_id, i_class_id, i_category_id, i_manufact_id)
# MAGIC  SELECT  prev_yr.d_year AS prev_year
# MAGIC                           ,curr_yr.d_year AS year
# MAGIC                           ,curr_yr.i_brand_id
# MAGIC                           ,curr_yr.i_class_id
# MAGIC                           ,curr_yr.i_category_id
# MAGIC                           ,curr_yr.i_manufact_id
# MAGIC                           ,prev_yr.sales_cnt AS prev_yr_cnt
# MAGIC                           ,curr_yr.sales_cnt AS curr_yr_cnt
# MAGIC                           ,curr_yr.sales_cnt-prev_yr.sales_cnt AS sales_cnt_diff
# MAGIC                           ,curr_yr.sales_amt-prev_yr.sales_amt AS sales_amt_diff
# MAGIC  FROM all_sales curr_yr, all_sales prev_yr
# MAGIC  WHERE curr_yr.i_brand_id=prev_yr.i_brand_id
# MAGIC    AND curr_yr.i_class_id=prev_yr.i_class_id
# MAGIC    AND curr_yr.i_category_id=prev_yr.i_category_id
# MAGIC    AND curr_yr.i_manufact_id=prev_yr.i_manufact_id
# MAGIC    AND curr_yr.d_year=1999
# MAGIC    AND prev_yr.d_year=1999-1
# MAGIC    AND CAST(curr_yr.sales_cnt AS DECIMAL(17,2))/CAST(prev_yr.sales_cnt AS DECIMAL(17,2))<0.9
# MAGIC  ORDER BY sales_cnt_diff,sales_amt_diff
# MAGIC  limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q76.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  channel, col_name, d_year, d_qoy, i_category, COUNT(*) sales_cnt, SUM(ext_sales_price) sales_amt FROM (
# MAGIC         SELECT 'store' as channel, 'ss_cdemo_sk' col_name, d_year, d_qoy, i_category, ss_ext_sales_price ext_sales_price
# MAGIC          FROM store_sales, item, date_dim
# MAGIC          WHERE ss_cdemo_sk IS NULL
# MAGIC            AND ss_sold_date_sk=d_date_sk
# MAGIC            AND ss_item_sk=i_item_sk
# MAGIC         UNION ALL
# MAGIC         SELECT 'web' as channel, 'ws_ship_hdemo_sk' col_name, d_year, d_qoy, i_category, ws_ext_sales_price ext_sales_price
# MAGIC          FROM web_sales, item, date_dim
# MAGIC          WHERE ws_ship_hdemo_sk IS NULL
# MAGIC            AND ws_sold_date_sk=d_date_sk
# MAGIC            AND ws_item_sk=i_item_sk
# MAGIC         UNION ALL
# MAGIC         SELECT 'catalog' as channel, 'cs_ship_mode_sk' col_name, d_year, d_qoy, i_category, cs_ext_sales_price ext_sales_price
# MAGIC          FROM catalog_sales, item, date_dim
# MAGIC          WHERE cs_ship_mode_sk IS NULL
# MAGIC            AND cs_sold_date_sk=d_date_sk
# MAGIC            AND cs_item_sk=i_item_sk) foo
# MAGIC GROUP BY channel, col_name, d_year, d_qoy, i_category
# MAGIC ORDER BY channel, col_name, d_year, d_qoy, i_category
# MAGIC limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q77.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC with ss as
# MAGIC  (select s_store_sk,
# MAGIC          sum(ss_ext_sales_price) as sales,
# MAGIC          sum(ss_net_profit) as profit
# MAGIC  from store_sales,
# MAGIC       date_dim,
# MAGIC       store
# MAGIC  where ss_sold_date_sk = d_date_sk
# MAGIC        and d_date between cast('2001-08-11' as date) 
# MAGIC                   and date_add(cast('2001-08-11' as date),30) 
# MAGIC        and ss_store_sk = s_store_sk
# MAGIC  group by s_store_sk)
# MAGIC  ,
# MAGIC  sr as
# MAGIC  (select s_store_sk,
# MAGIC          sum(sr_return_amt) as returns,
# MAGIC          sum(sr_net_loss) as profit_loss
# MAGIC  from store_returns,
# MAGIC       date_dim,
# MAGIC       store
# MAGIC  where sr_returned_date_sk = d_date_sk
# MAGIC        and d_date between cast('2001-08-11' as date)
# MAGIC                   and date_add(cast('2001-08-11' as date),30)
# MAGIC        and sr_store_sk = s_store_sk
# MAGIC  group by s_store_sk), 
# MAGIC  cs as
# MAGIC  (select cs_call_center_sk,
# MAGIC         sum(cs_ext_sales_price) as sales,
# MAGIC         sum(cs_net_profit) as profit
# MAGIC  from catalog_sales,
# MAGIC       date_dim
# MAGIC  where cs_sold_date_sk = d_date_sk
# MAGIC        and d_date between cast('2001-08-11' as date)
# MAGIC                   and date_add(cast('2001-08-11' as date),30)
# MAGIC  group by cs_call_center_sk 
# MAGIC  ), 
# MAGIC  cr as
# MAGIC  (select cr_call_center_sk,
# MAGIC          sum(cr_return_amount) as returns,
# MAGIC          sum(cr_net_loss) as profit_loss
# MAGIC  from catalog_returns,
# MAGIC       date_dim
# MAGIC  where cr_returned_date_sk = d_date_sk
# MAGIC        and d_date between cast('2001-08-11' as date)
# MAGIC                   and date_add(cast('2001-08-11' as date),30)
# MAGIC  group by cr_call_center_sk
# MAGIC  ), 
# MAGIC  ws as
# MAGIC  ( select wp_web_page_sk,
# MAGIC         sum(ws_ext_sales_price) as sales,
# MAGIC         sum(ws_net_profit) as profit
# MAGIC  from web_sales,
# MAGIC       date_dim,
# MAGIC       web_page
# MAGIC  where ws_sold_date_sk = d_date_sk
# MAGIC        and d_date between cast('2001-08-11' as date)
# MAGIC                   and date_add(cast('2001-08-11' as date),30)
# MAGIC        and ws_web_page_sk = wp_web_page_sk
# MAGIC  group by wp_web_page_sk), 
# MAGIC  wr as
# MAGIC  (select wp_web_page_sk,
# MAGIC         sum(wr_return_amt) as returns,
# MAGIC         sum(wr_net_loss) as profit_loss
# MAGIC  from web_returns,
# MAGIC       date_dim,
# MAGIC       web_page
# MAGIC  where wr_returned_date_sk = d_date_sk
# MAGIC        and d_date between cast('2001-08-11' as date)
# MAGIC                   and date_add(cast('2001-08-11' as date),30)
# MAGIC        and wr_web_page_sk = wp_web_page_sk
# MAGIC  group by wp_web_page_sk)
# MAGIC   select  channel
# MAGIC         , id
# MAGIC         , sum(sales) as sales
# MAGIC         , sum(returns) as returns
# MAGIC         , sum(profit) as profit
# MAGIC  from 
# MAGIC  (select 'store channel' as channel
# MAGIC         , ss.s_store_sk as id
# MAGIC         , sales
# MAGIC         , coalesce(returns, 0) as returns
# MAGIC         , (profit - coalesce(profit_loss,0)) as profit
# MAGIC  from   ss left join sr
# MAGIC         on  ss.s_store_sk = sr.s_store_sk
# MAGIC  union all
# MAGIC  select 'catalog channel' as channel
# MAGIC         , cs_call_center_sk as id
# MAGIC         , sales
# MAGIC         , returns
# MAGIC         , (profit - profit_loss) as profit
# MAGIC  from  cs
# MAGIC        , cr
# MAGIC  union all
# MAGIC  select 'web channel' as channel
# MAGIC         , ws.wp_web_page_sk as id
# MAGIC         , sales
# MAGIC         , coalesce(returns, 0) returns
# MAGIC         , (profit - coalesce(profit_loss,0)) as profit
# MAGIC  from   ws left join wr
# MAGIC         on  ws.wp_web_page_sk = wr.wp_web_page_sk
# MAGIC  ) x
# MAGIC  group by rollup (channel, id)
# MAGIC  order by channel
# MAGIC          ,id
# MAGIC  limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q78.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC with ws as
# MAGIC   (select d_year AS ws_sold_year, ws_item_sk,
# MAGIC     ws_bill_customer_sk ws_customer_sk,
# MAGIC     sum(ws_quantity) ws_qty,
# MAGIC     sum(ws_wholesale_cost) ws_wc,
# MAGIC     sum(ws_sales_price) ws_sp
# MAGIC    from web_sales
# MAGIC    left join web_returns on wr_order_number=ws_order_number and ws_item_sk=wr_item_sk
# MAGIC    join date_dim on ws_sold_date_sk = d_date_sk
# MAGIC    where wr_order_number is null
# MAGIC    group by d_year, ws_item_sk, ws_bill_customer_sk
# MAGIC    ),
# MAGIC cs as
# MAGIC   (select d_year AS cs_sold_year, cs_item_sk,
# MAGIC     cs_bill_customer_sk cs_customer_sk,
# MAGIC     sum(cs_quantity) cs_qty,
# MAGIC     sum(cs_wholesale_cost) cs_wc,
# MAGIC     sum(cs_sales_price) cs_sp
# MAGIC    from catalog_sales
# MAGIC    left join catalog_returns on cr_order_number=cs_order_number and cs_item_sk=cr_item_sk
# MAGIC    join date_dim on cs_sold_date_sk = d_date_sk
# MAGIC    where cr_order_number is null
# MAGIC    group by d_year, cs_item_sk, cs_bill_customer_sk
# MAGIC    ),
# MAGIC ss as
# MAGIC   (select d_year AS ss_sold_year, ss_item_sk,
# MAGIC     ss_customer_sk,
# MAGIC     sum(ss_quantity) ss_qty,
# MAGIC     sum(ss_wholesale_cost) ss_wc,
# MAGIC     sum(ss_sales_price) ss_sp
# MAGIC    from store_sales
# MAGIC    left join store_returns on sr_ticket_number=ss_ticket_number and ss_item_sk=sr_item_sk
# MAGIC    join date_dim on ss_sold_date_sk = d_date_sk
# MAGIC    where sr_ticket_number is null
# MAGIC    group by d_year, ss_item_sk, ss_customer_sk
# MAGIC    )
# MAGIC  select 
# MAGIC ss_sold_year, ss_item_sk, ss_customer_sk,
# MAGIC round(ss_qty/(coalesce(ws_qty,0)+coalesce(cs_qty,0)),2) ratio,
# MAGIC ss_qty store_qty, ss_wc store_wholesale_cost, ss_sp store_sales_price,
# MAGIC coalesce(ws_qty,0)+coalesce(cs_qty,0) other_chan_qty,
# MAGIC coalesce(ws_wc,0)+coalesce(cs_wc,0) other_chan_wholesale_cost,
# MAGIC coalesce(ws_sp,0)+coalesce(cs_sp,0) other_chan_sales_price
# MAGIC from ss
# MAGIC left join ws on (ws_sold_year=ss_sold_year and ws_item_sk=ss_item_sk and ws_customer_sk=ss_customer_sk)
# MAGIC left join cs on (cs_sold_year=ss_sold_year and cs_item_sk=ss_item_sk and cs_customer_sk=ss_customer_sk)
# MAGIC where (coalesce(ws_qty,0)>0 or coalesce(cs_qty, 0)>0) and ss_sold_year=1999
# MAGIC order by 
# MAGIC   ss_sold_year, ss_item_sk, ss_customer_sk,
# MAGIC   ss_qty desc, ss_wc desc, ss_sp desc,
# MAGIC   other_chan_qty,
# MAGIC   other_chan_wholesale_cost,
# MAGIC   other_chan_sales_price,
# MAGIC   ratio
# MAGIC limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q79.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select 
# MAGIC   c_last_name,c_first_name,substr(s_city,1,30),ss_ticket_number,amt,profit
# MAGIC   from
# MAGIC    (select ss_ticket_number
# MAGIC           ,ss_customer_sk
# MAGIC           ,store.s_city
# MAGIC           ,sum(ss_coupon_amt) amt
# MAGIC           ,sum(ss_net_profit) profit
# MAGIC     from store_sales,date_dim,store,household_demographics
# MAGIC     where store_sales.ss_sold_date_sk = date_dim.d_date_sk
# MAGIC     and store_sales.ss_store_sk = store.s_store_sk  
# MAGIC     and store_sales.ss_hdemo_sk = household_demographics.hd_demo_sk
# MAGIC     and (household_demographics.hd_dep_count = 9 or household_demographics.hd_vehicle_count > -1)
# MAGIC     and date_dim.d_dow = 1
# MAGIC     and date_dim.d_year in (1999,1999+1,1999+2) 
# MAGIC     and store.s_number_employees between 200 and 295
# MAGIC     group by ss_ticket_number,ss_customer_sk,ss_addr_sk,store.s_city) ms,customer
# MAGIC     where ss_customer_sk = c_customer_sk
# MAGIC  order by c_last_name,c_first_name,substr(s_city,1,30), profit
# MAGIC limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q80.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC with ssr as
# MAGIC  (select  s_store_id as store_id,
# MAGIC           sum(ss_ext_sales_price) as sales,
# MAGIC           sum(coalesce(sr_return_amt, 0)) as returns,
# MAGIC           sum(ss_net_profit - coalesce(sr_net_loss, 0)) as profit
# MAGIC   from store_sales left outer join store_returns on
# MAGIC          (ss_item_sk = sr_item_sk and ss_ticket_number = sr_ticket_number),
# MAGIC      date_dim,
# MAGIC      store,
# MAGIC      item,
# MAGIC      promotion
# MAGIC  where ss_sold_date_sk = d_date_sk
# MAGIC        and d_date between cast('2001-08-20' as date) 
# MAGIC                   and date_add(cast('2001-08-20' as date),30)
# MAGIC        and ss_store_sk = s_store_sk
# MAGIC        and ss_item_sk = i_item_sk
# MAGIC        and i_current_price > 50
# MAGIC        and ss_promo_sk = p_promo_sk
# MAGIC        and p_channel_tv = 'N'
# MAGIC  group by s_store_id)
# MAGIC  ,
# MAGIC  csr as
# MAGIC  (select  cp_catalog_page_id as catalog_page_id,
# MAGIC           sum(cs_ext_sales_price) as sales,
# MAGIC           sum(coalesce(cr_return_amount, 0)) as returns,
# MAGIC           sum(cs_net_profit - coalesce(cr_net_loss, 0)) as profit
# MAGIC   from catalog_sales left outer join catalog_returns on
# MAGIC          (cs_item_sk = cr_item_sk and cs_order_number = cr_order_number),
# MAGIC      date_dim,
# MAGIC      catalog_page,
# MAGIC      item,
# MAGIC      promotion
# MAGIC  where cs_sold_date_sk = d_date_sk
# MAGIC        and d_date between cast('2001-08-20' as date)
# MAGIC                   and date_add(cast('2001-08-20' as date),30)
# MAGIC         and cs_catalog_page_sk = cp_catalog_page_sk
# MAGIC        and cs_item_sk = i_item_sk
# MAGIC        and i_current_price > 50
# MAGIC        and cs_promo_sk = p_promo_sk
# MAGIC        and p_channel_tv = 'N'
# MAGIC group by cp_catalog_page_id)
# MAGIC  ,
# MAGIC  wsr as
# MAGIC  (select  web_site_id,
# MAGIC           sum(ws_ext_sales_price) as sales,
# MAGIC           sum(coalesce(wr_return_amt, 0)) as returns,
# MAGIC           sum(ws_net_profit - coalesce(wr_net_loss, 0)) as profit
# MAGIC   from web_sales left outer join web_returns on
# MAGIC          (ws_item_sk = wr_item_sk and ws_order_number = wr_order_number),
# MAGIC      date_dim,
# MAGIC      web_site,
# MAGIC      item,
# MAGIC      promotion
# MAGIC  where ws_sold_date_sk = d_date_sk
# MAGIC        and d_date between cast('2001-08-20' as date)
# MAGIC                   and date_add(cast('2001-08-20' as date),30)
# MAGIC         and ws_web_site_sk = web_site_sk
# MAGIC        and ws_item_sk = i_item_sk
# MAGIC        and i_current_price > 50
# MAGIC        and ws_promo_sk = p_promo_sk
# MAGIC        and p_channel_tv = 'N'
# MAGIC group by web_site_id)
# MAGIC   select  channel
# MAGIC         , id
# MAGIC         , sum(sales) as sales
# MAGIC         , sum(returns) as returns
# MAGIC         , sum(profit) as profit
# MAGIC  from 
# MAGIC  (select 'store channel' as channel
# MAGIC         , 'store' || store_id as id
# MAGIC         , sales
# MAGIC         , returns
# MAGIC         , profit
# MAGIC  from   ssr
# MAGIC  union all
# MAGIC  select 'catalog channel' as channel
# MAGIC         , 'catalog_page' || catalog_page_id as id
# MAGIC         , sales
# MAGIC         , returns
# MAGIC         , profit
# MAGIC  from  csr
# MAGIC  union all
# MAGIC  select 'web channel' as channel
# MAGIC         , 'web_site' || web_site_id as id
# MAGIC         , sales
# MAGIC         , returns
# MAGIC         , profit
# MAGIC  from   wsr
# MAGIC  ) x
# MAGIC  group by rollup (channel, id)
# MAGIC  order by channel
# MAGIC          ,id
# MAGIC  limit 100