# Databricks notebook source
# MAGIC %sql
# MAGIC use catalog tpcds;
# MAGIC use schema tpcds_sf1000_delta_lc;
# MAGIC set use_cached_result = false;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q41.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  distinct(i_product_name)
# MAGIC  from item i1
# MAGIC  where i_manufact_id between 857 and 857+40 
# MAGIC    and (select count(*) as item_cnt
# MAGIC         from item
# MAGIC         where (i_manufact = i1.i_manufact and
# MAGIC         ((i_category = 'Women' and 
# MAGIC         (i_color = 'pink' or i_color = 'goldenrod') and 
# MAGIC         (i_units = 'Box' or i_units = 'Dram') and
# MAGIC         (i_size = 'N/A' or i_size = 'medium')
# MAGIC         ) or
# MAGIC         (i_category = 'Women' and
# MAGIC         (i_color = 'violet' or i_color = 'spring') and
# MAGIC         (i_units = 'Each' or i_units = 'Gross') and
# MAGIC         (i_size = 'petite' or i_size = 'economy')
# MAGIC         ) or
# MAGIC         (i_category = 'Men' and
# MAGIC         (i_color = 'smoke' or i_color = 'plum') and
# MAGIC         (i_units = 'Lb' or i_units = 'Tsp') and
# MAGIC         (i_size = 'extra large' or i_size = 'small')
# MAGIC         ) or
# MAGIC         (i_category = 'Men' and
# MAGIC         (i_color = 'tomato' or i_color = 'misty') and
# MAGIC         (i_units = 'Tbl' or i_units = 'Bundle') and
# MAGIC         (i_size = 'N/A' or i_size = 'medium')
# MAGIC         ))) or
# MAGIC        (i_manufact = i1.i_manufact and
# MAGIC         ((i_category = 'Women' and 
# MAGIC         (i_color = 'blanched' or i_color = 'royal') and 
# MAGIC         (i_units = 'Pallet' or i_units = 'Case') and
# MAGIC         (i_size = 'N/A' or i_size = 'medium')
# MAGIC         ) or
# MAGIC         (i_category = 'Women' and
# MAGIC         (i_color = 'orange' or i_color = 'black') and
# MAGIC         (i_units = 'Unknown' or i_units = 'N/A') and
# MAGIC         (i_size = 'petite' or i_size = 'economy')
# MAGIC         ) or
# MAGIC         (i_category = 'Men' and
# MAGIC         (i_color = 'green' or i_color = 'dodger') and
# MAGIC         (i_units = 'Pound' or i_units = 'Ton') and
# MAGIC         (i_size = 'extra large' or i_size = 'small')
# MAGIC         ) or
# MAGIC         (i_category = 'Men' and
# MAGIC         (i_color = 'frosted' or i_color = 'gainsboro') and
# MAGIC         (i_units = 'Cup' or i_units = 'Dozen') and
# MAGIC         (i_size = 'N/A' or i_size = 'medium')
# MAGIC         )))) > 0
# MAGIC  order by i_product_name
# MAGIC  limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q42.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  dt.d_year
# MAGIC  	,item.i_category_id
# MAGIC  	,item.i_category
# MAGIC  	,sum(ss_ext_sales_price)
# MAGIC  from 	date_dim dt
# MAGIC  	,store_sales
# MAGIC  	,item
# MAGIC  where dt.d_date_sk = store_sales.ss_sold_date_sk
# MAGIC  	and store_sales.ss_item_sk = item.i_item_sk
# MAGIC  	and item.i_manager_id = 1  	
# MAGIC  	and dt.d_moy=12
# MAGIC  	and dt.d_year=2002
# MAGIC  group by 	dt.d_year
# MAGIC  		,item.i_category_id
# MAGIC  		,item.i_category
# MAGIC  order by       sum(ss_ext_sales_price) desc,dt.d_year
# MAGIC  		,item.i_category_id
# MAGIC  		,item.i_category
# MAGIC limit 100
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q43.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  s_store_name, s_store_id,
# MAGIC         sum(case when (d_day_name='Sunday') then ss_sales_price else null end) sun_sales,
# MAGIC         sum(case when (d_day_name='Monday') then ss_sales_price else null end) mon_sales,
# MAGIC         sum(case when (d_day_name='Tuesday') then ss_sales_price else  null end) tue_sales,
# MAGIC         sum(case when (d_day_name='Wednesday') then ss_sales_price else null end) wed_sales,
# MAGIC         sum(case when (d_day_name='Thursday') then ss_sales_price else null end) thu_sales,
# MAGIC         sum(case when (d_day_name='Friday') then ss_sales_price else null end) fri_sales,
# MAGIC         sum(case when (d_day_name='Saturday') then ss_sales_price else null end) sat_sales
# MAGIC  from date_dim, store_sales, store
# MAGIC  where d_date_sk = ss_sold_date_sk and
# MAGIC        s_store_sk = ss_store_sk and
# MAGIC        s_gmt_offset = -5 and
# MAGIC        d_year = 1998 
# MAGIC  group by s_store_name, s_store_id
# MAGIC  order by s_store_name, s_store_id,sun_sales,mon_sales,tue_sales,wed_sales,thu_sales,fri_sales,sat_sales
# MAGIC  limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q44.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  asceding.rnk, i1.i_product_name best_performing, i2.i_product_name worst_performing
# MAGIC from(select *
# MAGIC      from (select item_sk,rank() over (order by rank_col asc) rnk
# MAGIC            from (select ss_item_sk item_sk,avg(ss_net_profit) rank_col 
# MAGIC                  from store_sales ss1
# MAGIC                  where ss_store_sk = 447
# MAGIC                  group by ss_item_sk
# MAGIC                  having avg(ss_net_profit) > 0.9*(select avg(ss_net_profit) rank_col
# MAGIC                                                   from store_sales
# MAGIC                                                   where ss_store_sk = 447
# MAGIC                                                     and ss_addr_sk is null
# MAGIC                                                   group by ss_store_sk))V1)V11
# MAGIC      where rnk  < 11) asceding,
# MAGIC     (select *
# MAGIC      from (select item_sk,rank() over (order by rank_col desc) rnk
# MAGIC            from (select ss_item_sk item_sk,avg(ss_net_profit) rank_col
# MAGIC                  from store_sales ss1
# MAGIC                  where ss_store_sk = 447
# MAGIC                  group by ss_item_sk
# MAGIC                  having avg(ss_net_profit) > 0.9*(select avg(ss_net_profit) rank_col
# MAGIC                                                   from store_sales
# MAGIC                                                   where ss_store_sk = 447
# MAGIC                                                     and ss_addr_sk is null
# MAGIC                                                   group by ss_store_sk))V2)V21
# MAGIC      where rnk  < 11) descending,
# MAGIC item i1,
# MAGIC item i2
# MAGIC where asceding.rnk = descending.rnk 
# MAGIC   and i1.i_item_sk=asceding.item_sk
# MAGIC   and i2.i_item_sk=descending.item_sk
# MAGIC order by asceding.rnk
# MAGIC limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q45.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  ca_zip, ca_state, sum(ws_sales_price)
# MAGIC  from web_sales, customer, customer_address, date_dim, item
# MAGIC  where ws_bill_customer_sk = c_customer_sk
# MAGIC  	and c_current_addr_sk = ca_address_sk 
# MAGIC  	and ws_item_sk = i_item_sk 
# MAGIC  	and ( substr(ca_zip,1,5) in ('85669', '86197','88274','83405','86475', '85392', '85460', '80348', '81792')
# MAGIC  	      or 
# MAGIC  	      i_item_id in (select i_item_id
# MAGIC                              from item
# MAGIC                              where i_item_sk in (2, 3, 5, 7, 11, 13, 17, 19, 23, 29)
# MAGIC                              )
# MAGIC  	    )
# MAGIC  	and ws_sold_date_sk = d_date_sk
# MAGIC  	and d_qoy = 1 and d_year = 2000
# MAGIC  group by ca_zip, ca_state
# MAGIC  order by ca_zip, ca_state
# MAGIC  limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q46.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  c_last_name
# MAGIC        ,c_first_name
# MAGIC        ,ca_city
# MAGIC        ,bought_city
# MAGIC        ,ss_ticket_number
# MAGIC        ,amt,profit 
# MAGIC  from
# MAGIC    (select ss_ticket_number
# MAGIC           ,ss_customer_sk
# MAGIC           ,ca_city bought_city
# MAGIC           ,sum(ss_coupon_amt) amt
# MAGIC           ,sum(ss_net_profit) profit
# MAGIC     from store_sales,date_dim,store,household_demographics,customer_address 
# MAGIC     where store_sales.ss_sold_date_sk = date_dim.d_date_sk
# MAGIC     and store_sales.ss_store_sk = store.s_store_sk  
# MAGIC     and store_sales.ss_hdemo_sk = household_demographics.hd_demo_sk
# MAGIC     and store_sales.ss_addr_sk = customer_address.ca_address_sk
# MAGIC     and (household_demographics.hd_dep_count = 7 or
# MAGIC          household_demographics.hd_vehicle_count= 4)
# MAGIC     and date_dim.d_dow in (6,0)
# MAGIC     and date_dim.d_year in (2000,2000+1,2000+2) 
# MAGIC     and store.s_city in ('Manchester','Watson','Marion','Oxford','Bellevue') 
# MAGIC     group by ss_ticket_number,ss_customer_sk,ss_addr_sk,ca_city) dn,customer,customer_address current_addr
# MAGIC     where ss_customer_sk = c_customer_sk
# MAGIC       and customer.c_current_addr_sk = current_addr.ca_address_sk
# MAGIC       and current_addr.ca_city <> bought_city
# MAGIC   order by c_last_name
# MAGIC           ,c_first_name
# MAGIC           ,ca_city
# MAGIC           ,bought_city
# MAGIC           ,ss_ticket_number
# MAGIC   limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q47.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC with v1 as(
# MAGIC  select i_category, i_brand,
# MAGIC         s_store_name, s_company_name,
# MAGIC         d_year, d_moy,
# MAGIC         sum(ss_sales_price) sum_sales,
# MAGIC         avg(sum(ss_sales_price)) over
# MAGIC           (partition by i_category, i_brand,
# MAGIC                      s_store_name, s_company_name, d_year)
# MAGIC           avg_monthly_sales,
# MAGIC         rank() over
# MAGIC           (partition by i_category, i_brand,
# MAGIC                      s_store_name, s_company_name
# MAGIC            order by d_year, d_moy) rn
# MAGIC  from item, store_sales, date_dim, store
# MAGIC  where ss_item_sk = i_item_sk and
# MAGIC        ss_sold_date_sk = d_date_sk and
# MAGIC        ss_store_sk = s_store_sk and
# MAGIC        (
# MAGIC          d_year = 1999 or
# MAGIC          ( d_year = 1999-1 and d_moy =12) or
# MAGIC          ( d_year = 1999+1 and d_moy =1)
# MAGIC        )
# MAGIC  group by i_category, i_brand,
# MAGIC           s_store_name, s_company_name,
# MAGIC           d_year, d_moy),
# MAGIC  v2 as(
# MAGIC  select v1.i_brand
# MAGIC         ,v1.d_year, v1.d_moy
# MAGIC         ,v1.avg_monthly_sales
# MAGIC         ,v1.sum_sales, v1_lag.sum_sales psum, v1_lead.sum_sales nsum
# MAGIC  from v1, v1 v1_lag, v1 v1_lead
# MAGIC  where v1.i_category = v1_lag.i_category and
# MAGIC        v1.i_category = v1_lead.i_category and
# MAGIC        v1.i_brand = v1_lag.i_brand and
# MAGIC        v1.i_brand = v1_lead.i_brand and
# MAGIC        v1.s_store_name = v1_lag.s_store_name and
# MAGIC        v1.s_store_name = v1_lead.s_store_name and
# MAGIC        v1.s_company_name = v1_lag.s_company_name and
# MAGIC        v1.s_company_name = v1_lead.s_company_name and
# MAGIC        v1.rn = v1_lag.rn + 1 and
# MAGIC        v1.rn = v1_lead.rn - 1)
# MAGIC   select  *
# MAGIC  from v2
# MAGIC  where  d_year = 1999 and    
# MAGIC         avg_monthly_sales > 0 and
# MAGIC         case when avg_monthly_sales > 0 then abs(sum_sales - avg_monthly_sales) / avg_monthly_sales else null end > 0.1
# MAGIC  order by sum_sales - avg_monthly_sales, nsum
# MAGIC  limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q48.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select sum (ss_quantity)
# MAGIC  from store_sales, store, customer_demographics, customer_address, date_dim
# MAGIC  where s_store_sk = ss_store_sk
# MAGIC  and  ss_sold_date_sk = d_date_sk and d_year = 1999
# MAGIC  and  
# MAGIC  (
# MAGIC   (
# MAGIC    cd_demo_sk = ss_cdemo_sk
# MAGIC    and 
# MAGIC    cd_marital_status = 'D'
# MAGIC    and 
# MAGIC    cd_education_status = 'Unknown'
# MAGIC    and 
# MAGIC    ss_sales_price between 100.00 and 150.00  
# MAGIC    )
# MAGIC  or
# MAGIC   (
# MAGIC   cd_demo_sk = ss_cdemo_sk
# MAGIC    and 
# MAGIC    cd_marital_status = 'M'
# MAGIC    and 
# MAGIC    cd_education_status = 'Secondary'
# MAGIC    and 
# MAGIC    ss_sales_price between 50.00 and 100.00   
# MAGIC   )
# MAGIC  or 
# MAGIC  (
# MAGIC   cd_demo_sk = ss_cdemo_sk
# MAGIC   and 
# MAGIC    cd_marital_status = 'W'
# MAGIC    and 
# MAGIC    cd_education_status = '4 yr Degree'
# MAGIC    and 
# MAGIC    ss_sales_price between 150.00 and 200.00  
# MAGIC  )
# MAGIC  )
# MAGIC  and
# MAGIC  (
# MAGIC   (
# MAGIC   ss_addr_sk = ca_address_sk
# MAGIC   and
# MAGIC   ca_country = 'United States'
# MAGIC   and
# MAGIC   ca_state in ('KY', 'AL', 'AK')
# MAGIC   and ss_net_profit between 0 and 2000  
# MAGIC   )
# MAGIC  or
# MAGIC   (ss_addr_sk = ca_address_sk
# MAGIC   and
# MAGIC   ca_country = 'United States'
# MAGIC   and
# MAGIC   ca_state in ('KS', 'MN', 'NC')
# MAGIC   and ss_net_profit between 150 and 3000 
# MAGIC   )
# MAGIC  or
# MAGIC   (ss_addr_sk = ca_address_sk
# MAGIC   and
# MAGIC   ca_country = 'United States'
# MAGIC   and
# MAGIC   ca_state in ('NE', 'CA', 'TX')
# MAGIC   and ss_net_profit between 50 and 25000 
# MAGIC   )
# MAGIC  )
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q49.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  channel, item, return_ratio, return_rank, currency_rank from
# MAGIC  (select
# MAGIC  'web' as channel
# MAGIC  ,web.item
# MAGIC  ,web.return_ratio
# MAGIC  ,web.return_rank
# MAGIC  ,web.currency_rank
# MAGIC  from (
# MAGIC  	select 
# MAGIC  	 item
# MAGIC  	,return_ratio
# MAGIC  	,currency_ratio
# MAGIC  	,rank() over (order by return_ratio) as return_rank
# MAGIC  	,rank() over (order by currency_ratio) as currency_rank
# MAGIC  	from
# MAGIC  	(	select ws.ws_item_sk as item
# MAGIC  		,(cast(sum(coalesce(wr.wr_return_quantity,0)) as decimal(15,4))/
# MAGIC  		cast(sum(coalesce(ws.ws_quantity,0)) as decimal(15,4) )) as return_ratio
# MAGIC  		,(cast(sum(coalesce(wr.wr_return_amt,0)) as decimal(15,4))/
# MAGIC  		cast(sum(coalesce(ws.ws_net_paid,0)) as decimal(15,4) )) as currency_ratio
# MAGIC  		from 
# MAGIC  		 web_sales ws left outer join web_returns wr 
# MAGIC  			on (ws.ws_order_number = wr.wr_order_number and 
# MAGIC  			ws.ws_item_sk = wr.wr_item_sk)
# MAGIC                  ,date_dim
# MAGIC  		where 
# MAGIC  			wr.wr_return_amt > 10000 
# MAGIC  			and ws.ws_net_profit > 1
# MAGIC                          and ws.ws_net_paid > 0
# MAGIC                          and ws.ws_quantity > 0
# MAGIC                          and ws_sold_date_sk = d_date_sk
# MAGIC                          and d_year = 2000
# MAGIC                          and d_moy = 12
# MAGIC  		group by ws.ws_item_sk
# MAGIC  	) in_web
# MAGIC  ) web
# MAGIC  where 
# MAGIC  (
# MAGIC  web.return_rank <= 10
# MAGIC  or
# MAGIC  web.currency_rank <= 10
# MAGIC  )
# MAGIC  union
# MAGIC  select 
# MAGIC  'catalog' as channel
# MAGIC  ,catalog.item
# MAGIC  ,catalog.return_ratio
# MAGIC  ,catalog.return_rank
# MAGIC  ,catalog.currency_rank
# MAGIC  from (
# MAGIC  	select 
# MAGIC  	 item
# MAGIC  	,return_ratio
# MAGIC  	,currency_ratio
# MAGIC  	,rank() over (order by return_ratio) as return_rank
# MAGIC  	,rank() over (order by currency_ratio) as currency_rank
# MAGIC  	from
# MAGIC  	(	select 
# MAGIC  		cs.cs_item_sk as item
# MAGIC  		,(cast(sum(coalesce(cr.cr_return_quantity,0)) as decimal(15,4))/
# MAGIC  		cast(sum(coalesce(cs.cs_quantity,0)) as decimal(15,4) )) as return_ratio
# MAGIC  		,(cast(sum(coalesce(cr.cr_return_amount,0)) as decimal(15,4))/
# MAGIC  		cast(sum(coalesce(cs.cs_net_paid,0)) as decimal(15,4) )) as currency_ratio
# MAGIC  		from 
# MAGIC  		catalog_sales cs left outer join catalog_returns cr
# MAGIC  			on (cs.cs_order_number = cr.cr_order_number and 
# MAGIC  			cs.cs_item_sk = cr.cr_item_sk)
# MAGIC                 ,date_dim
# MAGIC  		where 
# MAGIC  			cr.cr_return_amount > 10000 
# MAGIC  			and cs.cs_net_profit > 1
# MAGIC                          and cs.cs_net_paid > 0
# MAGIC                          and cs.cs_quantity > 0
# MAGIC                          and cs_sold_date_sk = d_date_sk
# MAGIC                          and d_year = 2000
# MAGIC                          and d_moy = 12
# MAGIC                  group by cs.cs_item_sk
# MAGIC  	) in_cat
# MAGIC  ) catalog
# MAGIC  where 
# MAGIC  (
# MAGIC  catalog.return_rank <= 10
# MAGIC  or
# MAGIC  catalog.currency_rank <=10
# MAGIC  )
# MAGIC  union
# MAGIC  select 
# MAGIC  'store' as channel
# MAGIC  ,store.item
# MAGIC  ,store.return_ratio
# MAGIC  ,store.return_rank
# MAGIC  ,store.currency_rank
# MAGIC  from (
# MAGIC  	select 
# MAGIC  	 item
# MAGIC  	,return_ratio
# MAGIC  	,currency_ratio
# MAGIC  	,rank() over (order by return_ratio) as return_rank
# MAGIC  	,rank() over (order by currency_ratio) as currency_rank
# MAGIC  	from
# MAGIC  	(	select sts.ss_item_sk as item
# MAGIC  		,(cast(sum(coalesce(sr.sr_return_quantity,0)) as decimal(15,4))/cast(sum(coalesce(sts.ss_quantity,0)) as decimal(15,4) )) as return_ratio
# MAGIC  		,(cast(sum(coalesce(sr.sr_return_amt,0)) as decimal(15,4))/cast(sum(coalesce(sts.ss_net_paid,0)) as decimal(15,4) )) as currency_ratio
# MAGIC  		from 
# MAGIC  		store_sales sts left outer join store_returns sr
# MAGIC  			on (sts.ss_ticket_number = sr.sr_ticket_number and sts.ss_item_sk = sr.sr_item_sk)
# MAGIC                 ,date_dim
# MAGIC  		where 
# MAGIC  			sr.sr_return_amt > 10000 
# MAGIC  			and sts.ss_net_profit > 1
# MAGIC                          and sts.ss_net_paid > 0 
# MAGIC                          and sts.ss_quantity > 0
# MAGIC                          and ss_sold_date_sk = d_date_sk
# MAGIC                          and d_year = 2000
# MAGIC                          and d_moy = 12
# MAGIC  		group by sts.ss_item_sk
# MAGIC  	) in_store
# MAGIC  ) store
# MAGIC  where  (
# MAGIC  store.return_rank <= 10
# MAGIC  or 
# MAGIC  store.currency_rank <= 10
# MAGIC  )
# MAGIC  )
# MAGIC  order by 1,4,5,2
# MAGIC  limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q50.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select  
# MAGIC    s_store_name
# MAGIC   ,s_company_id
# MAGIC   ,s_street_number
# MAGIC   ,s_street_name
# MAGIC   ,s_street_type
# MAGIC   ,s_suite_number
# MAGIC   ,s_city
# MAGIC   ,s_county
# MAGIC   ,s_state
# MAGIC   ,s_zip
# MAGIC   ,sum(case when (sr_returned_date_sk - ss_sold_date_sk <= 30 ) then 1 else 0 end)  as `30 days` 
# MAGIC   ,sum(case when (sr_returned_date_sk - ss_sold_date_sk > 30) and 
# MAGIC                  (sr_returned_date_sk - ss_sold_date_sk <= 60) then 1 else 0 end )  as `31-60 days` 
# MAGIC   ,sum(case when (sr_returned_date_sk - ss_sold_date_sk > 60) and 
# MAGIC                  (sr_returned_date_sk - ss_sold_date_sk <= 90) then 1 else 0 end)  as `61-90 days` 
# MAGIC   ,sum(case when (sr_returned_date_sk - ss_sold_date_sk > 90) and
# MAGIC                  (sr_returned_date_sk - ss_sold_date_sk <= 120) then 1 else 0 end)  as `91-120 days` 
# MAGIC   ,sum(case when (sr_returned_date_sk - ss_sold_date_sk  > 120) then 1 else 0 end)  as `>120 days` 
# MAGIC from
# MAGIC    store_sales
# MAGIC   ,store_returns
# MAGIC   ,store
# MAGIC   ,date_dim d1
# MAGIC   ,date_dim d2
# MAGIC where
# MAGIC     d2.d_year = 2000
# MAGIC and d2.d_moy  = 8
# MAGIC and ss_ticket_number = sr_ticket_number
# MAGIC and ss_item_sk = sr_item_sk
# MAGIC and ss_sold_date_sk   = d1.d_date_sk
# MAGIC and sr_returned_date_sk   = d2.d_date_sk
# MAGIC and ss_customer_sk = sr_customer_sk
# MAGIC and ss_store_sk = s_store_sk
# MAGIC group by
# MAGIC    s_store_name
# MAGIC   ,s_company_id
# MAGIC   ,s_street_number
# MAGIC   ,s_street_name
# MAGIC   ,s_street_type
# MAGIC   ,s_suite_number
# MAGIC   ,s_city
# MAGIC   ,s_county
# MAGIC   ,s_state
# MAGIC   ,s_zip
# MAGIC order by s_store_name
# MAGIC         ,s_company_id
# MAGIC         ,s_street_number
# MAGIC         ,s_street_name
# MAGIC         ,s_street_type
# MAGIC         ,s_suite_number
# MAGIC         ,s_city
# MAGIC         ,s_county
# MAGIC         ,s_state
# MAGIC         ,s_zip
# MAGIC limit 100
# MAGIC