# Databricks notebook source
# MAGIC %sql
# MAGIC use catalog tpcds;
# MAGIC use schema tpcds_sf1000_delta_lc;
# MAGIC set use_cached_result = false;

# COMMAND ----------

# MAGIC %md ## クエリ-1

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q14a.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC with cross_items as (
# MAGIC   select
# MAGIC     i_item_sk ss_item_sk
# MAGIC   from
# MAGIC     item,
# MAGIC     (
# MAGIC       select
# MAGIC         iss.i_brand_id brand_id,
# MAGIC         iss.i_class_id class_id,
# MAGIC         iss.i_category_id category_id
# MAGIC       from
# MAGIC         store_sales,
# MAGIC         item iss,
# MAGIC         date_dim d1
# MAGIC       where
# MAGIC         ss_item_sk = iss.i_item_sk
# MAGIC         and ss_sold_date_sk = d1.d_date_sk
# MAGIC         and d1.d_year between 1998
# MAGIC         AND 1998 + 4
# MAGIC       intersect
# MAGIC       select
# MAGIC         ics.i_brand_id,
# MAGIC         ics.i_class_id,
# MAGIC         ics.i_category_id
# MAGIC       from
# MAGIC         catalog_sales,
# MAGIC         item ics,
# MAGIC         date_dim d2
# MAGIC       where
# MAGIC         cs_item_sk = ics.i_item_sk
# MAGIC         and cs_sold_date_sk = d2.d_date_sk
# MAGIC         and d2.d_year between 1998
# MAGIC         AND 1998 + 4
# MAGIC       intersect
# MAGIC       select
# MAGIC         iws.i_brand_id,
# MAGIC         iws.i_class_id,
# MAGIC         iws.i_category_id
# MAGIC       from
# MAGIC         web_sales,
# MAGIC         item iws,
# MAGIC         date_dim d3
# MAGIC       where
# MAGIC         ws_item_sk = iws.i_item_sk
# MAGIC         and ws_sold_date_sk = d3.d_date_sk
# MAGIC         and d3.d_year between 1998
# MAGIC         AND 1998 + 4
# MAGIC     )
# MAGIC   where
# MAGIC     i_brand_id = brand_id
# MAGIC     and i_class_id = class_id
# MAGIC     and i_category_id = category_id
# MAGIC ),
# MAGIC avg_sales as (
# MAGIC   select
# MAGIC     avg(quantity * list_price) average_sales
# MAGIC   from
# MAGIC     (
# MAGIC       select
# MAGIC         ss_quantity quantity,
# MAGIC         ss_list_price list_price
# MAGIC       from
# MAGIC         store_sales,
# MAGIC         date_dim
# MAGIC       where
# MAGIC         ss_sold_date_sk = d_date_sk
# MAGIC         and d_year between 1998
# MAGIC         and 1998 + 4
# MAGIC       union all
# MAGIC       select
# MAGIC         cs_quantity quantity,
# MAGIC         cs_list_price list_price
# MAGIC       from
# MAGIC         catalog_sales,
# MAGIC         date_dim
# MAGIC       where
# MAGIC         cs_sold_date_sk = d_date_sk
# MAGIC         and d_year between 1998
# MAGIC         and 1998 + 4
# MAGIC       union all
# MAGIC       select
# MAGIC         ws_quantity quantity,
# MAGIC         ws_list_price list_price
# MAGIC       from
# MAGIC         web_sales,
# MAGIC         date_dim
# MAGIC       where
# MAGIC         ws_sold_date_sk = d_date_sk
# MAGIC         and d_year between 1998
# MAGIC         and 1998 + 4
# MAGIC     ) x
# MAGIC )
# MAGIC select
# MAGIC   channel,
# MAGIC   i_brand_id,
# MAGIC   i_class_id,
# MAGIC   i_category_id,
# MAGIC   sum(sales),
# MAGIC   sum(number_sales)
# MAGIC from(
# MAGIC     select
# MAGIC       'store' channel,
# MAGIC       i_brand_id,
# MAGIC       i_class_id,
# MAGIC       i_category_id,
# MAGIC       sum(ss_quantity * ss_list_price) sales,
# MAGIC       count(*) number_sales
# MAGIC     from
# MAGIC       store_sales,
# MAGIC       item,
# MAGIC       date_dim
# MAGIC     where
# MAGIC       ss_item_sk in (
# MAGIC         select
# MAGIC           ss_item_sk
# MAGIC         from
# MAGIC           cross_items
# MAGIC       )
# MAGIC       and ss_item_sk = i_item_sk
# MAGIC       and ss_sold_date_sk = d_date_sk
# MAGIC       and d_year = 1998 + 4
# MAGIC       and d_moy = 11
# MAGIC     group by
# MAGIC       i_brand_id,
# MAGIC       i_class_id,
# MAGIC       i_category_id
# MAGIC     having
# MAGIC       sum(ss_quantity * ss_list_price) > (
# MAGIC         select
# MAGIC           average_sales
# MAGIC         from
# MAGIC           avg_sales
# MAGIC       )
# MAGIC     union all
# MAGIC     select
# MAGIC       'catalog' channel,
# MAGIC       i_brand_id,
# MAGIC       i_class_id,
# MAGIC       i_category_id,
# MAGIC       sum(cs_quantity * cs_list_price) sales,
# MAGIC       count(*) number_sales
# MAGIC     from
# MAGIC       catalog_sales,
# MAGIC       item,
# MAGIC       date_dim
# MAGIC     where
# MAGIC       cs_item_sk in (
# MAGIC         select
# MAGIC           ss_item_sk
# MAGIC         from
# MAGIC           cross_items
# MAGIC       )
# MAGIC       and cs_item_sk = i_item_sk
# MAGIC       and cs_sold_date_sk = d_date_sk
# MAGIC       and d_year = 1998 + 4
# MAGIC       and d_moy = 11
# MAGIC     group by
# MAGIC       i_brand_id,
# MAGIC       i_class_id,
# MAGIC       i_category_id
# MAGIC     having
# MAGIC       sum(cs_quantity * cs_list_price) > (
# MAGIC         select
# MAGIC           average_sales
# MAGIC         from
# MAGIC           avg_sales
# MAGIC       )
# MAGIC     union all
# MAGIC     select
# MAGIC       'web' channel,
# MAGIC       i_brand_id,
# MAGIC       i_class_id,
# MAGIC       i_category_id,
# MAGIC       sum(ws_quantity * ws_list_price) sales,
# MAGIC       count(*) number_sales
# MAGIC     from
# MAGIC       web_sales,
# MAGIC       item,
# MAGIC       date_dim
# MAGIC     where
# MAGIC       ws_item_sk in (
# MAGIC         select
# MAGIC           ss_item_sk
# MAGIC         from
# MAGIC           cross_items
# MAGIC       )
# MAGIC       and ws_item_sk = i_item_sk
# MAGIC       and ws_sold_date_sk = d_date_sk
# MAGIC       and d_year = 1998 + 4
# MAGIC       and d_moy = 11
# MAGIC     group by
# MAGIC       i_brand_id,
# MAGIC       i_class_id,
# MAGIC       i_category_id
# MAGIC     having
# MAGIC       sum(ws_quantity * ws_list_price) > (
# MAGIC         select
# MAGIC           average_sales
# MAGIC         from
# MAGIC           avg_sales
# MAGIC       )
# MAGIC   ) y
# MAGIC group by
# MAGIC   rollup (channel, i_brand_id, i_class_id, i_category_id)
# MAGIC order by
# MAGIC   channel,
# MAGIC   i_brand_id,
# MAGIC   i_class_id,
# MAGIC   i_category_id
# MAGIC limit
# MAGIC   100

# COMMAND ----------

# MAGIC %md ## クエリ-2

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q14b.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC with cross_items as (
# MAGIC   select
# MAGIC     i_item_sk ss_item_sk
# MAGIC   from
# MAGIC     item,
# MAGIC     (
# MAGIC       select
# MAGIC         iss.i_brand_id brand_id,
# MAGIC         iss.i_class_id class_id,
# MAGIC         iss.i_category_id category_id
# MAGIC       from
# MAGIC         store_sales,
# MAGIC         item iss,
# MAGIC         date_dim d1
# MAGIC       where
# MAGIC         ss_item_sk = iss.i_item_sk
# MAGIC         and ss_sold_date_sk = d1.d_date_sk
# MAGIC         and d1.d_year between 1998
# MAGIC         AND 1998 + 4
# MAGIC       intersect
# MAGIC       select
# MAGIC         ics.i_brand_id,
# MAGIC         ics.i_class_id,
# MAGIC         ics.i_category_id
# MAGIC       from
# MAGIC         catalog_sales,
# MAGIC         item ics,
# MAGIC         date_dim d2
# MAGIC       where
# MAGIC         cs_item_sk = ics.i_item_sk
# MAGIC         and cs_sold_date_sk = d2.d_date_sk
# MAGIC         and d2.d_year between 1998
# MAGIC         AND 1998 + 4
# MAGIC       intersect
# MAGIC       select
# MAGIC         iws.i_brand_id,
# MAGIC         iws.i_class_id,
# MAGIC         iws.i_category_id
# MAGIC       from
# MAGIC         web_sales,
# MAGIC         item iws,
# MAGIC         date_dim d3
# MAGIC       where
# MAGIC         ws_item_sk = iws.i_item_sk
# MAGIC         and ws_sold_date_sk = d3.d_date_sk
# MAGIC         and d3.d_year between 1998
# MAGIC         AND 1998 + 4
# MAGIC     ) x
# MAGIC   where
# MAGIC     i_brand_id = brand_id
# MAGIC     and i_class_id = class_id
# MAGIC     and i_category_id = category_id
# MAGIC ),
# MAGIC avg_sales as (
# MAGIC   select
# MAGIC     avg(quantity * list_price) average_sales
# MAGIC   from
# MAGIC     (
# MAGIC       select
# MAGIC         ss_quantity quantity,
# MAGIC         ss_list_price list_price
# MAGIC       from
# MAGIC         store_sales,
# MAGIC         date_dim
# MAGIC       where
# MAGIC         ss_sold_date_sk = d_date_sk
# MAGIC         and d_year between 1998
# MAGIC         and 1998 + 4
# MAGIC       union all
# MAGIC       select
# MAGIC         cs_quantity quantity,
# MAGIC         cs_list_price list_price
# MAGIC       from
# MAGIC         catalog_sales,
# MAGIC         date_dim
# MAGIC       where
# MAGIC         cs_sold_date_sk = d_date_sk
# MAGIC         and d_year between 1998
# MAGIC         and 1998 + 4
# MAGIC       union all
# MAGIC       select
# MAGIC         ws_quantity quantity,
# MAGIC         ws_list_price list_price
# MAGIC       from
# MAGIC         web_sales,
# MAGIC         date_dim
# MAGIC       where
# MAGIC         ws_sold_date_sk = d_date_sk
# MAGIC         and d_year between 1998
# MAGIC         and 1998 + 4
# MAGIC     ) x
# MAGIC )
# MAGIC select
# MAGIC   this_year.channel ty_channel,
# MAGIC   this_year.i_brand_id ty_brand,
# MAGIC   this_year.i_class_id ty_class,
# MAGIC   this_year.i_category_id ty_category,
# MAGIC   this_year.sales ty_sales,
# MAGIC   this_year.number_sales ty_number_sales,
# MAGIC   last_year.channel ly_channel,
# MAGIC   last_year.i_brand_id ly_brand,
# MAGIC   last_year.i_class_id ly_class,
# MAGIC   last_year.i_category_id ly_category,
# MAGIC   last_year.sales ly_sales,
# MAGIC   last_year.number_sales ly_number_sales
# MAGIC from
# MAGIC   (
# MAGIC     select
# MAGIC       'store' channel,
# MAGIC       i_brand_id,
# MAGIC       i_class_id,
# MAGIC       i_category_id,
# MAGIC       sum(ss_quantity * ss_list_price) sales,
# MAGIC       count(*) number_sales
# MAGIC     from
# MAGIC       store_sales,
# MAGIC       item,
# MAGIC       date_dim
# MAGIC     where
# MAGIC       ss_item_sk in (
# MAGIC         select
# MAGIC           ss_item_sk
# MAGIC         from
# MAGIC           cross_items
# MAGIC       )
# MAGIC       and ss_item_sk = i_item_sk
# MAGIC       and ss_sold_date_sk = d_date_sk
# MAGIC       and d_week_seq = (
# MAGIC         select
# MAGIC           d_week_seq
# MAGIC         from
# MAGIC           date_dim
# MAGIC         where
# MAGIC           d_year = 1998 + 1
# MAGIC           and d_moy = 12
# MAGIC           and d_dom = 19
# MAGIC       )
# MAGIC     group by
# MAGIC       i_brand_id,
# MAGIC       i_class_id,
# MAGIC       i_category_id
# MAGIC     having
# MAGIC       sum(ss_quantity * ss_list_price) > (
# MAGIC         select
# MAGIC           average_sales
# MAGIC         from
# MAGIC           avg_sales
# MAGIC       )
# MAGIC   ) this_year,
# MAGIC   (
# MAGIC     select
# MAGIC       'store' channel,
# MAGIC       i_brand_id,
# MAGIC       i_class_id,
# MAGIC       i_category_id,
# MAGIC       sum(ss_quantity * ss_list_price) sales,
# MAGIC       count(*) number_sales
# MAGIC     from
# MAGIC       store_sales,
# MAGIC       item,
# MAGIC       date_dim
# MAGIC     where
# MAGIC       ss_item_sk in (
# MAGIC         select
# MAGIC           ss_item_sk
# MAGIC         from
# MAGIC           cross_items
# MAGIC       )
# MAGIC       and ss_item_sk = i_item_sk
# MAGIC       and ss_sold_date_sk = d_date_sk
# MAGIC       and d_week_seq = (
# MAGIC         select
# MAGIC           d_week_seq
# MAGIC         from
# MAGIC           date_dim
# MAGIC         where
# MAGIC           d_year = 1998
# MAGIC           and d_moy = 12
# MAGIC           and d_dom = 19
# MAGIC       )
# MAGIC     group by
# MAGIC       i_brand_id,
# MAGIC       i_class_id,
# MAGIC       i_category_id
# MAGIC     having
# MAGIC       sum(ss_quantity * ss_list_price) > (
# MAGIC         select
# MAGIC           average_sales
# MAGIC         from
# MAGIC           avg_sales
# MAGIC       )
# MAGIC   ) last_year
# MAGIC where
# MAGIC   this_year.i_brand_id = last_year.i_brand_id
# MAGIC   and this_year.i_class_id = last_year.i_class_id
# MAGIC   and this_year.i_category_id = last_year.i_category_id
# MAGIC order by
# MAGIC   this_year.channel,
# MAGIC   this_year.i_brand_id,
# MAGIC   this_year.i_class_id,
# MAGIC   this_year.i_category_id
# MAGIC limit
# MAGIC   100

# COMMAND ----------

# MAGIC %md ## クエリ-3

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q22.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select
# MAGIC   i_product_name,
# MAGIC   i_brand,
# MAGIC   i_class,
# MAGIC   i_category,
# MAGIC   avg(inv_quantity_on_hand) qoh
# MAGIC from
# MAGIC   inventory,
# MAGIC   date_dim,
# MAGIC   item
# MAGIC where
# MAGIC   inv_date_sk = d_date_sk
# MAGIC   and inv_item_sk = i_item_sk
# MAGIC   and d_month_seq between 1183
# MAGIC   and 1183 + 110
# MAGIC group by
# MAGIC   rollup(
# MAGIC     i_product_name,
# MAGIC     i_brand,
# MAGIC     i_class,
# MAGIC     i_category
# MAGIC   )
# MAGIC order by
# MAGIC   qoh,
# MAGIC   i_product_name,
# MAGIC   i_brand,
# MAGIC   i_class,
# MAGIC   i_category
# MAGIC limit
# MAGIC   100

# COMMAND ----------

# MAGIC %md ## クエリ-4

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q23a.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC with frequent_ss_items as (
# MAGIC   select
# MAGIC     substr(i_item_desc, 1, 30) itemdesc,
# MAGIC     i_item_sk item_sk,
# MAGIC     d_date solddate,
# MAGIC     count(*) cnt
# MAGIC   from
# MAGIC     store_sales,
# MAGIC     date_dim,
# MAGIC     item
# MAGIC   where
# MAGIC     ss_sold_date_sk = d_date_sk
# MAGIC     and ss_item_sk = i_item_sk
# MAGIC     and d_year in (1997, 1998, 1998 + 1, 1998 + 2, 1998 + 3)
# MAGIC   group by
# MAGIC     substr(i_item_desc, 1, 30),
# MAGIC     i_item_sk,
# MAGIC     d_date
# MAGIC   having
# MAGIC     count(*) > 4
# MAGIC ),
# MAGIC max_store_sales as (
# MAGIC   select
# MAGIC     max(csales) tpcds_cmax
# MAGIC   from
# MAGIC     (
# MAGIC       select
# MAGIC         c_customer_sk,
# MAGIC         sum(ss_quantity * ss_sales_price) csales
# MAGIC       from
# MAGIC         store_sales,
# MAGIC         customer,
# MAGIC         date_dim
# MAGIC       where
# MAGIC         ss_customer_sk = c_customer_sk
# MAGIC         and ss_sold_date_sk = d_date_sk
# MAGIC         and d_year in (1997, 1998, 1998 + 1, 1998 + 2, 1998 + 3)
# MAGIC       group by
# MAGIC         c_customer_sk
# MAGIC     )
# MAGIC ),
# MAGIC best_ss_customer as (
# MAGIC   select
# MAGIC     c_customer_sk,
# MAGIC     sum(ss_quantity * ss_sales_price) ssales
# MAGIC   from
# MAGIC     store_sales,
# MAGIC     customer
# MAGIC   where
# MAGIC     ss_customer_sk = c_customer_sk
# MAGIC   group by
# MAGIC     c_customer_sk
# MAGIC   having
# MAGIC     sum(ss_quantity * ss_sales_price) > (95 / 100.0) * (
# MAGIC       select
# MAGIC         *
# MAGIC       from
# MAGIC         max_store_sales
# MAGIC     )
# MAGIC )
# MAGIC select
# MAGIC   sum(sales)
# MAGIC from
# MAGIC   (
# MAGIC     select
# MAGIC       cs_quantity * cs_list_price sales
# MAGIC     from
# MAGIC       catalog_sales,
# MAGIC       date_dim
# MAGIC     where
# MAGIC       d_year in (1997, 1998, 1999 )
# MAGIC       and d_moy = 4
# MAGIC       and cs_sold_date_sk = d_date_sk
# MAGIC       and cs_item_sk in (
# MAGIC         select
# MAGIC           item_sk
# MAGIC         from
# MAGIC           frequent_ss_items
# MAGIC       )
# MAGIC       and cs_bill_customer_sk in (
# MAGIC         select
# MAGIC           c_customer_sk
# MAGIC         from
# MAGIC           best_ss_customer
# MAGIC       )
# MAGIC     union all
# MAGIC     select
# MAGIC       ws_quantity * ws_list_price sales
# MAGIC     from
# MAGIC       web_sales,
# MAGIC       date_dim
# MAGIC     where
# MAGIC       d_year  in (1997, 1998, 1999 )
# MAGIC       and d_moy = 4
# MAGIC       and ws_sold_date_sk = d_date_sk
# MAGIC       and ws_item_sk in (
# MAGIC         select
# MAGIC           item_sk
# MAGIC         from
# MAGIC           frequent_ss_items
# MAGIC       )
# MAGIC       and ws_bill_customer_sk in (
# MAGIC         select
# MAGIC           c_customer_sk
# MAGIC         from
# MAGIC           best_ss_customer
# MAGIC       )
# MAGIC   )
# MAGIC limit
# MAGIC   100

# COMMAND ----------

# MAGIC %md ## クエリ-5

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q23b.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC with frequent_ss_items as (
# MAGIC   select
# MAGIC     substr(i_item_desc, 1, 30) itemdesc,
# MAGIC     i_item_sk item_sk,
# MAGIC     d_date solddate,
# MAGIC     count(*) cnt
# MAGIC   from
# MAGIC     store_sales,
# MAGIC     date_dim,
# MAGIC     item
# MAGIC   where
# MAGIC     ss_sold_date_sk = d_date_sk
# MAGIC     and ss_item_sk = i_item_sk
# MAGIC     --and d_year in (1998, 1998 + 1, 1998 + 2, 1998 + 3)
# MAGIC   group by
# MAGIC     substr(i_item_desc, 1, 30),
# MAGIC     i_item_sk,
# MAGIC     d_date
# MAGIC   having
# MAGIC     count(*) > 4
# MAGIC ),
# MAGIC max_store_sales as (
# MAGIC   select
# MAGIC     max(csales) tpcds_cmax
# MAGIC   from
# MAGIC     (
# MAGIC       select
# MAGIC         c_customer_sk,
# MAGIC         sum(ss_quantity * ss_sales_price) csales
# MAGIC       from
# MAGIC         store_sales,
# MAGIC         customer,
# MAGIC         date_dim
# MAGIC       where
# MAGIC         ss_customer_sk = c_customer_sk
# MAGIC         and ss_sold_date_sk = d_date_sk
# MAGIC         --and d_year in (1998, 1998 + 1, 1998 + 2, 1998 + 3)
# MAGIC       group by
# MAGIC         c_customer_sk
# MAGIC     )
# MAGIC ),
# MAGIC best_ss_customer as (
# MAGIC   select
# MAGIC     c_customer_sk,
# MAGIC     sum(ss_quantity * ss_sales_price) ssales
# MAGIC   from
# MAGIC     store_sales,
# MAGIC     customer
# MAGIC   where
# MAGIC     ss_customer_sk = c_customer_sk
# MAGIC   group by
# MAGIC     c_customer_sk
# MAGIC   having
# MAGIC     sum(ss_quantity * ss_sales_price) > (95 / 100.0) * (
# MAGIC       select
# MAGIC         *
# MAGIC       from
# MAGIC         max_store_sales
# MAGIC     )
# MAGIC )
# MAGIC select
# MAGIC   c_last_name,
# MAGIC   c_first_name,
# MAGIC   sales
# MAGIC from
# MAGIC   (
# MAGIC     select
# MAGIC       c_last_name,
# MAGIC       c_first_name,
# MAGIC       sum(cs_quantity * cs_list_price) sales
# MAGIC     from
# MAGIC       catalog_sales,
# MAGIC       customer,
# MAGIC       date_dim
# MAGIC     where
# MAGIC       d_year = 1998
# MAGIC       --and d_moy = 4
# MAGIC       and cs_sold_date_sk = d_date_sk
# MAGIC       and cs_item_sk in (
# MAGIC         select
# MAGIC           item_sk
# MAGIC         from
# MAGIC           frequent_ss_items
# MAGIC       )
# MAGIC       and cs_bill_customer_sk in (
# MAGIC         select
# MAGIC           c_customer_sk
# MAGIC         from
# MAGIC           best_ss_customer
# MAGIC       )
# MAGIC       and cs_bill_customer_sk = c_customer_sk
# MAGIC     group by
# MAGIC       c_last_name,
# MAGIC       c_first_name
# MAGIC     union all
# MAGIC     select
# MAGIC       c_last_name,
# MAGIC       c_first_name,
# MAGIC       sum(ws_quantity * ws_list_price) sales
# MAGIC     from
# MAGIC       web_sales,
# MAGIC       customer,
# MAGIC       date_dim
# MAGIC     where
# MAGIC       d_year = 1998
# MAGIC       --and d_moy = 4
# MAGIC       and ws_sold_date_sk = d_date_sk
# MAGIC       and ws_item_sk in (
# MAGIC         select
# MAGIC           item_sk
# MAGIC         from
# MAGIC           frequent_ss_items
# MAGIC       )
# MAGIC       and ws_bill_customer_sk in (
# MAGIC         select
# MAGIC           c_customer_sk
# MAGIC         from
# MAGIC           best_ss_customer
# MAGIC       )
# MAGIC       and ws_bill_customer_sk = c_customer_sk
# MAGIC     group by
# MAGIC       c_last_name,
# MAGIC       c_first_name
# MAGIC   )
# MAGIC order by
# MAGIC   c_last_name,
# MAGIC   c_first_name,
# MAGIC   sales
# MAGIC limit
# MAGIC   100

# COMMAND ----------

# MAGIC %md ## クエリ-6

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q24a.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC with ssales as (
# MAGIC   select
# MAGIC     c_last_name,
# MAGIC     c_first_name,
# MAGIC     s_store_name,
# MAGIC     ca_state,
# MAGIC     s_state,
# MAGIC     i_color,
# MAGIC     i_current_price,
# MAGIC     i_manager_id,
# MAGIC     i_units,
# MAGIC     i_size,
# MAGIC     sum(ss_net_paid_inc_tax) netpaid
# MAGIC   from
# MAGIC     store_sales,
# MAGIC     store_returns,
# MAGIC     store,
# MAGIC     item,
# MAGIC     customer,
# MAGIC     customer_address
# MAGIC   where
# MAGIC     ss_ticket_number = sr_ticket_number
# MAGIC     and ss_item_sk = sr_item_sk
# MAGIC     and ss_customer_sk = c_customer_sk
# MAGIC     and ss_item_sk = i_item_sk
# MAGIC     and ss_store_sk = s_store_sk
# MAGIC     and c_current_addr_sk = ca_address_sk
# MAGIC     and c_birth_country <> upper(ca_country)
# MAGIC     and s_zip = ca_zip
# MAGIC     -- and s_market_id = 5
# MAGIC   group by
# MAGIC     c_last_name,
# MAGIC     c_first_name,
# MAGIC     s_store_name,
# MAGIC     ca_state,
# MAGIC     s_state,
# MAGIC     i_color,
# MAGIC     i_current_price,
# MAGIC     i_manager_id,
# MAGIC     i_units,
# MAGIC     i_size
# MAGIC )
# MAGIC select
# MAGIC   c_last_name,
# MAGIC   c_first_name,
# MAGIC   s_store_name,
# MAGIC   sum(netpaid) paid
# MAGIC from
# MAGIC   ssales
# MAGIC where i_color = 'tomato'
# MAGIC group by
# MAGIC   c_last_name,
# MAGIC   c_first_name,
# MAGIC   s_store_name
# MAGIC having
# MAGIC   sum(netpaid) > (
# MAGIC     select
# MAGIC       0.05 * avg(netpaid)
# MAGIC     from
# MAGIC       ssales
# MAGIC   )
# MAGIC order by
# MAGIC   c_last_name,
# MAGIC   c_first_name,
# MAGIC   s_store_name

# COMMAND ----------

# MAGIC %md ## クエリ-7

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q64.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC with cs_ui as (
# MAGIC   select
# MAGIC     cs_item_sk,
# MAGIC     sum(cs_ext_list_price) as sale,
# MAGIC     sum(
# MAGIC       cr_refunded_cash + cr_reversed_charge + cr_store_credit
# MAGIC     ) as refund
# MAGIC   from
# MAGIC     catalog_sales,
# MAGIC     catalog_returns
# MAGIC   where
# MAGIC     cs_item_sk = cr_item_sk
# MAGIC     and cs_order_number = cr_order_number
# MAGIC   group by
# MAGIC     cs_item_sk
# MAGIC   having
# MAGIC     sum(cs_ext_list_price) > 2 * sum(
# MAGIC       cr_refunded_cash + cr_reversed_charge + cr_store_credit
# MAGIC     )
# MAGIC ),
# MAGIC cross_sales as (
# MAGIC   select
# MAGIC     i_product_name product_name,
# MAGIC     i_item_sk item_sk,
# MAGIC     s_store_name store_name,
# MAGIC     s_zip store_zip,
# MAGIC     ad1.ca_street_number b_street_number,
# MAGIC     ad1.ca_street_name b_street_name,
# MAGIC     ad1.ca_city b_city,
# MAGIC     ad1.ca_zip b_zip,
# MAGIC     ad2.ca_street_number c_street_number,
# MAGIC     ad2.ca_street_name c_street_name,
# MAGIC     ad2.ca_city c_city,
# MAGIC     ad2.ca_zip c_zip,
# MAGIC     d1.d_year as syear,
# MAGIC     d2.d_year as fsyear,
# MAGIC     d3.d_year s2year,
# MAGIC     count(*) cnt,
# MAGIC     sum(ss_wholesale_cost) s1,
# MAGIC     sum(ss_list_price) s2,
# MAGIC     sum(ss_coupon_amt) s3
# MAGIC   FROM
# MAGIC     store_sales,
# MAGIC     store_returns,
# MAGIC     cs_ui,
# MAGIC     date_dim d1,
# MAGIC     date_dim d2,
# MAGIC     date_dim d3,
# MAGIC     store,
# MAGIC     customer,
# MAGIC     customer_demographics cd1,
# MAGIC     customer_demographics cd2,
# MAGIC     promotion,
# MAGIC     household_demographics hd1,
# MAGIC     household_demographics hd2,
# MAGIC     customer_address ad1,
# MAGIC     customer_address ad2,
# MAGIC     income_band ib1,
# MAGIC     income_band ib2,
# MAGIC     item
# MAGIC   WHERE
# MAGIC     ss_store_sk = s_store_sk
# MAGIC     AND ss_sold_date_sk = d1.d_date_sk
# MAGIC     AND ss_customer_sk = c_customer_sk
# MAGIC     AND ss_cdemo_sk = cd1.cd_demo_sk
# MAGIC     AND ss_hdemo_sk = hd1.hd_demo_sk
# MAGIC     AND ss_addr_sk = ad1.ca_address_sk
# MAGIC     and ss_item_sk = i_item_sk
# MAGIC     and ss_item_sk = sr_item_sk
# MAGIC     and ss_ticket_number = sr_ticket_number
# MAGIC     and ss_item_sk = cs_ui.cs_item_sk
# MAGIC     and c_current_cdemo_sk = cd2.cd_demo_sk
# MAGIC     AND c_current_hdemo_sk = hd2.hd_demo_sk
# MAGIC     AND c_current_addr_sk = ad2.ca_address_sk
# MAGIC     and c_first_sales_date_sk = d2.d_date_sk
# MAGIC     and c_first_shipto_date_sk = d3.d_date_sk
# MAGIC     and ss_promo_sk = p_promo_sk
# MAGIC     and hd1.hd_income_band_sk = ib1.ib_income_band_sk
# MAGIC     and hd2.hd_income_band_sk = ib2.ib_income_band_sk
# MAGIC     and cd1.cd_marital_status <> cd2.cd_marital_status
# MAGIC     and i_color in (
# MAGIC       'sky',
# MAGIC       'burlywood',
# MAGIC       'lavender',
# MAGIC       'khaki',
# MAGIC       'seashell',
# MAGIC       'puff'
# MAGIC     )
# MAGIC     -- and i_current_price between 61 and 61 + 10
# MAGIC     -- and i_current_price between 61 + 1 and 61 + 15
# MAGIC   group by
# MAGIC     i_product_name,
# MAGIC     i_item_sk,
# MAGIC     s_store_name,
# MAGIC     s_zip,
# MAGIC     ad1.ca_street_number,
# MAGIC     ad1.ca_street_name,
# MAGIC     ad1.ca_city,
# MAGIC     ad1.ca_zip,
# MAGIC     ad2.ca_street_number,
# MAGIC     ad2.ca_street_name,
# MAGIC     ad2.ca_city,
# MAGIC     ad2.ca_zip,
# MAGIC     d1.d_year,
# MAGIC     d2.d_year,
# MAGIC     d3.d_year
# MAGIC )
# MAGIC select
# MAGIC   cs1.product_name,
# MAGIC   cs1.store_name,
# MAGIC   cs1.store_zip,
# MAGIC   cs1.b_street_number,
# MAGIC   cs1.b_street_name,
# MAGIC   cs1.b_city,
# MAGIC   cs1.b_zip,
# MAGIC   cs1.c_street_number,
# MAGIC   cs1.c_street_name,
# MAGIC   cs1.c_city,
# MAGIC   cs1.c_zip,
# MAGIC   cs1.syear as syear1,
# MAGIC   cs1.cnt as cnt1,
# MAGIC   cs1.s1 as s11,
# MAGIC   cs1.s2 as s21,
# MAGIC   cs1.s3 as s31,
# MAGIC   cs2.s1 as s12,
# MAGIC   cs2.s2 as s22,
# MAGIC   cs2.s3 as s32,
# MAGIC   cs2.syear as syear2,
# MAGIC   cs2.cnt as cnt2
# MAGIC from
# MAGIC   cross_sales cs1,
# MAGIC   cross_sales cs2
# MAGIC where
# MAGIC   cs1.item_sk = cs2.item_sk
# MAGIC   and cs1.syear = 2000
# MAGIC   and cs2.syear = 2000 + 1
# MAGIC   and cs2.cnt <= cs1.cnt
# MAGIC   and cs1.store_name = cs2.store_name
# MAGIC   and cs1.store_zip = cs2.store_zip
# MAGIC order by
# MAGIC   cs1.product_name,
# MAGIC   cs1.store_name,
# MAGIC   cs2.cnt,
# MAGIC   cs1.s1,
# MAGIC   cs2.s1
# MAGIC   limit
# MAGIC   100

# COMMAND ----------

# MAGIC %md ## クエリ-8

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q67.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select
# MAGIC   *
# MAGIC from
# MAGIC   (
# MAGIC     select
# MAGIC       i_category,
# MAGIC       i_class,
# MAGIC       i_brand,
# MAGIC       i_product_name,
# MAGIC       d_year,
# MAGIC       d_qoy,
# MAGIC       d_moy,
# MAGIC       s_store_id,
# MAGIC       sumsales,
# MAGIC       rank() over (
# MAGIC         partition by i_category
# MAGIC         order by
# MAGIC           sumsales desc
# MAGIC       ) rk
# MAGIC     from
# MAGIC       (
# MAGIC         select
# MAGIC           i_category,
# MAGIC           i_class,
# MAGIC           i_brand,
# MAGIC           i_product_name,
# MAGIC           d_year,
# MAGIC           d_qoy,
# MAGIC           d_moy,
# MAGIC           s_store_id,
# MAGIC           sum(coalesce(ss_sales_price * ss_quantity, 0)) sumsales
# MAGIC         from
# MAGIC           store_sales,
# MAGIC           date_dim,
# MAGIC           store,
# MAGIC           item
# MAGIC         where
# MAGIC           ss_sold_date_sk = d_date_sk
# MAGIC           and ss_item_sk = i_item_sk
# MAGIC           and ss_store_sk = s_store_sk
# MAGIC           and d_month_seq between 1189 and 1189 + 110
# MAGIC         group by
# MAGIC           rollup(
# MAGIC             i_category,
# MAGIC             i_class,
# MAGIC             i_brand,
# MAGIC             i_product_name,
# MAGIC             d_year,
# MAGIC             d_qoy,
# MAGIC             d_moy,
# MAGIC             s_store_id
# MAGIC           )
# MAGIC       ) dw1
# MAGIC   ) dw2
# MAGIC where
# MAGIC   rk <= 100
# MAGIC order by
# MAGIC   i_category,
# MAGIC   i_class,
# MAGIC   i_brand,
# MAGIC   i_product_name,
# MAGIC   d_year,
# MAGIC   d_qoy,
# MAGIC   d_moy,
# MAGIC   s_store_id,
# MAGIC   sumsales,
# MAGIC   rk
# MAGIC limit
# MAGIC   100

# COMMAND ----------

# MAGIC %md ## クエリ-9

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q78.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC with ws as (
# MAGIC   select
# MAGIC     d_year AS ws_sold_year,
# MAGIC     ws_item_sk,
# MAGIC     ws_bill_customer_sk ws_customer_sk,
# MAGIC     sum(ws_quantity) ws_qty,
# MAGIC     sum(ws_wholesale_cost) ws_wc,
# MAGIC     sum(ws_sales_price) ws_sp
# MAGIC   from
# MAGIC     web_sales
# MAGIC     left join web_returns on wr_order_number = ws_order_number
# MAGIC     and ws_item_sk = wr_item_sk
# MAGIC     join date_dim on ws_sold_date_sk = d_date_sk
# MAGIC   where
# MAGIC     wr_order_number is null
# MAGIC   group by
# MAGIC     d_year,
# MAGIC     ws_item_sk,
# MAGIC     ws_bill_customer_sk
# MAGIC ),
# MAGIC cs as (
# MAGIC   select
# MAGIC     d_year AS cs_sold_year,
# MAGIC     cs_item_sk,
# MAGIC     cs_bill_customer_sk cs_customer_sk,
# MAGIC     sum(cs_quantity) cs_qty,
# MAGIC     sum(cs_wholesale_cost) cs_wc,
# MAGIC     sum(cs_sales_price) cs_sp
# MAGIC   from
# MAGIC     catalog_sales
# MAGIC     left join catalog_returns on cr_order_number = cs_order_number
# MAGIC     and cs_item_sk = cr_item_sk
# MAGIC     join date_dim on cs_sold_date_sk = d_date_sk
# MAGIC   where
# MAGIC     cr_order_number is null
# MAGIC   group by
# MAGIC     d_year,
# MAGIC     cs_item_sk,
# MAGIC     cs_bill_customer_sk
# MAGIC ),
# MAGIC ss as (
# MAGIC   select
# MAGIC     d_year AS ss_sold_year,
# MAGIC     ss_item_sk,
# MAGIC     ss_customer_sk,
# MAGIC     sum(ss_quantity) ss_qty,
# MAGIC     sum(ss_wholesale_cost) ss_wc,
# MAGIC     sum(ss_sales_price) ss_sp
# MAGIC   from
# MAGIC     store_sales
# MAGIC     left join store_returns on sr_ticket_number = ss_ticket_number
# MAGIC     and ss_item_sk = sr_item_sk
# MAGIC     join date_dim on ss_sold_date_sk = d_date_sk
# MAGIC   where
# MAGIC     sr_ticket_number is null
# MAGIC   group by
# MAGIC     d_year,
# MAGIC     ss_item_sk,
# MAGIC     ss_customer_sk
# MAGIC )
# MAGIC select
# MAGIC   ss_sold_year,
# MAGIC   ss_item_sk,
# MAGIC   ss_customer_sk,
# MAGIC   round(ss_qty /(coalesce(ws_qty, 0) + coalesce(cs_qty, 0)), 2) ratio,
# MAGIC   ss_qty store_qty,
# MAGIC   ss_wc store_wholesale_cost,
# MAGIC   ss_sp store_sales_price,
# MAGIC   coalesce(ws_qty, 0) + coalesce(cs_qty, 0) other_chan_qty,
# MAGIC   coalesce(ws_wc, 0) + coalesce(cs_wc, 0) other_chan_wholesale_cost,
# MAGIC   coalesce(ws_sp, 0) + coalesce(cs_sp, 0) other_chan_sales_price
# MAGIC from
# MAGIC   ss
# MAGIC   left join ws on (
# MAGIC     ws_sold_year = ss_sold_year
# MAGIC     and ws_item_sk = ss_item_sk
# MAGIC     and ws_customer_sk = ss_customer_sk
# MAGIC   )
# MAGIC   left join cs on (
# MAGIC     cs_sold_year = ss_sold_year
# MAGIC     and cs_item_sk = ss_item_sk
# MAGIC     and cs_customer_sk = ss_customer_sk
# MAGIC   )
# MAGIC where
# MAGIC   (
# MAGIC     coalesce(ws_qty, 0) > 0
# MAGIC     or coalesce(cs_qty, 0) > 0
# MAGIC   )
# MAGIC   and ss_sold_year in (1997, 1998, 1999,2000)
# MAGIC order by
# MAGIC   ss_sold_year,
# MAGIC   ss_item_sk,
# MAGIC   ss_customer_sk,
# MAGIC   ss_qty desc,
# MAGIC   ss_wc desc,
# MAGIC   ss_sp desc,
# MAGIC   other_chan_qty,
# MAGIC   other_chan_wholesale_cost,
# MAGIC   other_chan_sales_price,
# MAGIC   ratio
# MAGIC limit
# MAGIC   100

# COMMAND ----------

# MAGIC %md ## クエリ-10

# COMMAND ----------

# MAGIC %sql
# MAGIC -- q88.sql
# MAGIC -- scale 30000, stream 0, seed 100
# MAGIC select
# MAGIC   *
# MAGIC from
# MAGIC   (
# MAGIC     select
# MAGIC       count(*) h8_30_to_9
# MAGIC     from
# MAGIC       store_sales,
# MAGIC       household_demographics,
# MAGIC       time_dim,
# MAGIC       store
# MAGIC     where
# MAGIC       ss_sold_time_sk = time_dim.t_time_sk
# MAGIC       and ss_hdemo_sk = household_demographics.hd_demo_sk
# MAGIC       and ss_store_sk = s_store_sk
# MAGIC       and time_dim.t_hour in (7, 8)
# MAGIC       -- and time_dim.t_minute >= 30
# MAGIC       -- and (
# MAGIC       --   (
# MAGIC       --     household_demographics.hd_dep_count = 1
# MAGIC       --     and household_demographics.hd_vehicle_count <= 1 + 2
# MAGIC       --   )
# MAGIC       --   or (
# MAGIC       --     household_demographics.hd_dep_count = 0
# MAGIC       --     and household_demographics.hd_vehicle_count <= 0 + 2
# MAGIC       --   )
# MAGIC       --   or (
# MAGIC       --     household_demographics.hd_dep_count = 2
# MAGIC       --     and household_demographics.hd_vehicle_count <= 2 + 2
# MAGIC       --   )
# MAGIC       -- )
# MAGIC       -- and store.s_store_name = 'ese'
# MAGIC   ) s1,
# MAGIC   (
# MAGIC     select
# MAGIC       count(*) h9_to_9_30
# MAGIC     from
# MAGIC       store_sales,
# MAGIC       household_demographics,
# MAGIC       time_dim,
# MAGIC       store
# MAGIC     where
# MAGIC       ss_sold_time_sk = time_dim.t_time_sk
# MAGIC       and ss_hdemo_sk = household_demographics.hd_demo_sk
# MAGIC       and ss_store_sk = s_store_sk
# MAGIC       and time_dim.t_hour in (9,10)
# MAGIC       -- and time_dim.t_minute < 30
# MAGIC       -- and (
# MAGIC       --   (
# MAGIC       --     household_demographics.hd_dep_count = 1
# MAGIC       --     and household_demographics.hd_vehicle_count <= 1 + 2
# MAGIC       --   )
# MAGIC       --   or (
# MAGIC       --     household_demographics.hd_dep_count = 0
# MAGIC       --     and household_demographics.hd_vehicle_count <= 0 + 2
# MAGIC       --   )
# MAGIC       --   or (
# MAGIC       --     household_demographics.hd_dep_count = 2
# MAGIC       --     and household_demographics.hd_vehicle_count <= 2 + 2
# MAGIC       --   )
# MAGIC       -- )
# MAGIC       -- and store.s_store_name = 'ese'
# MAGIC   ) s2,
# MAGIC   (
# MAGIC     select
# MAGIC       count(*) h9_30_to_10
# MAGIC     from
# MAGIC       store_sales,
# MAGIC       household_demographics,
# MAGIC       time_dim,
# MAGIC       store
# MAGIC     where
# MAGIC       ss_sold_time_sk = time_dim.t_time_sk
# MAGIC       and ss_hdemo_sk = household_demographics.hd_demo_sk
# MAGIC       and ss_store_sk = s_store_sk
# MAGIC       and time_dim.t_hour in (11,12)
# MAGIC       -- and time_dim.t_minute >= 30
# MAGIC       -- and (
# MAGIC       --   (
# MAGIC       --     household_demographics.hd_dep_count = 1
# MAGIC       --     and household_demographics.hd_vehicle_count <= 1 + 2
# MAGIC       --   )
# MAGIC       --   or (
# MAGIC       --     household_demographics.hd_dep_count = 0
# MAGIC       --     and household_demographics.hd_vehicle_count <= 0 + 2
# MAGIC       --   )
# MAGIC       --   or (
# MAGIC       --     household_demographics.hd_dep_count = 2
# MAGIC       --     and household_demographics.hd_vehicle_count <= 2 + 2
# MAGIC       --   )
# MAGIC       -- )
# MAGIC       -- and store.s_store_name = 'ese'
# MAGIC   ) s3,
# MAGIC   (
# MAGIC     select
# MAGIC       count(*) h10_to_10_30
# MAGIC     from
# MAGIC       store_sales,
# MAGIC       household_demographics,
# MAGIC       time_dim,
# MAGIC       store
# MAGIC     where
# MAGIC       ss_sold_time_sk = time_dim.t_time_sk
# MAGIC       and ss_hdemo_sk = household_demographics.hd_demo_sk
# MAGIC       and ss_store_sk = s_store_sk
# MAGIC       and time_dim.t_hour in (13,14) 
# MAGIC       -- and time_dim.t_minute < 30
# MAGIC       -- and (
# MAGIC       --   (
# MAGIC       --     household_demographics.hd_dep_count = 1
# MAGIC       --     --and household_demographics.hd_vehicle_count <= 1 + 2
# MAGIC       --   )
# MAGIC       --   or (
# MAGIC       --     household_demographics.hd_dep_count = 0
# MAGIC       --     --and household_demographics.hd_vehicle_count <= 0 + 2
# MAGIC       --   )
# MAGIC       --   or (
# MAGIC       --     household_demographics.hd_dep_count = 2
# MAGIC       --     --and household_demographics.hd_vehicle_count <= 2 + 2
# MAGIC       --   )
# MAGIC       -- )
# MAGIC       -- and store.s_store_name = 'ese'
# MAGIC   ) s4,
# MAGIC   (
# MAGIC     select
# MAGIC       count(*) h10_30_to_11
# MAGIC     from
# MAGIC       store_sales,
# MAGIC       household_demographics,
# MAGIC       time_dim,
# MAGIC       store
# MAGIC     where
# MAGIC       ss_sold_time_sk = time_dim.t_time_sk
# MAGIC       and ss_hdemo_sk = household_demographics.hd_demo_sk
# MAGIC       and ss_store_sk = s_store_sk
# MAGIC       and time_dim.t_hour in (15,16)
# MAGIC       -- and time_dim.t_minute >= 30
# MAGIC       -- and (
# MAGIC       --   (
# MAGIC       --     household_demographics.hd_dep_count = 1
# MAGIC       --     --and household_demographics.hd_vehicle_count <= 1 + 2
# MAGIC       --   )
# MAGIC       --   or (
# MAGIC       --     household_demographics.hd_dep_count = 0
# MAGIC       --     --and household_demographics.hd_vehicle_count <= 0 + 2
# MAGIC       --   )
# MAGIC       --   or (
# MAGIC       --     household_demographics.hd_dep_count = 2
# MAGIC       --     --and household_demographics.hd_vehicle_count <= 2 + 2
# MAGIC       --   )
# MAGIC       -- )
# MAGIC       -- and store.s_store_name = 'ese'
# MAGIC   ) s5,
# MAGIC   (
# MAGIC     select
# MAGIC       count(*) h11_to_11_30
# MAGIC     from
# MAGIC       store_sales,
# MAGIC       household_demographics,
# MAGIC       time_dim,
# MAGIC       store
# MAGIC     where
# MAGIC       ss_sold_time_sk = time_dim.t_time_sk
# MAGIC       and ss_hdemo_sk = household_demographics.hd_demo_sk
# MAGIC       and ss_store_sk = s_store_sk
# MAGIC       and time_dim.t_hour in (17,18)
# MAGIC       -- and time_dim.t_minute < 30
# MAGIC       -- and (
# MAGIC       --   (
# MAGIC       --     household_demographics.hd_dep_count = 1
# MAGIC       --     --and household_demographics.hd_vehicle_count <= 1 + 2
# MAGIC       --   )
# MAGIC       --   or (
# MAGIC       --     household_demographics.hd_dep_count = 0
# MAGIC       --     --and household_demographics.hd_vehicle_count <= 0 + 2
# MAGIC       --   )
# MAGIC       --   or (
# MAGIC       --     household_demographics.hd_dep_count = 2
# MAGIC       --     ---and household_demographics.hd_vehicle_count <= 2 + 2
# MAGIC       --   )
# MAGIC       -- )
# MAGIC       -- and store.s_store_name = 'ese'
# MAGIC   ) s6,
# MAGIC   (
# MAGIC     select
# MAGIC       count(*) h11_30_to_12
# MAGIC     from
# MAGIC       store_sales,
# MAGIC       household_demographics,
# MAGIC       time_dim,
# MAGIC       store
# MAGIC     where
# MAGIC       ss_sold_time_sk = time_dim.t_time_sk
# MAGIC       and ss_hdemo_sk = household_demographics.hd_demo_sk
# MAGIC       and ss_store_sk = s_store_sk
# MAGIC       and time_dim.t_hour in (19,20 )
# MAGIC       -- and time_dim.t_minute >= 30
# MAGIC       -- and (
# MAGIC       --   (
# MAGIC       --     household_demographics.hd_dep_count = 1
# MAGIC       --     --and household_demographics.hd_vehicle_count <= 1 + 2
# MAGIC       --   )
# MAGIC       --   or (
# MAGIC       --     household_demographics.hd_dep_count = 0
# MAGIC       --     --and household_demographics.hd_vehicle_count <= 0 + 2
# MAGIC       --   )
# MAGIC       --   or (
# MAGIC       --     household_demographics.hd_dep_count = 2
# MAGIC       --     --and household_demographics.hd_vehicle_count <= 2 + 2
# MAGIC       --   )
# MAGIC       -- )
# MAGIC       -- and store.s_store_name = 'ese'
# MAGIC   ) s7,
# MAGIC   (
# MAGIC     select
# MAGIC       count(*) h12_to_12_30
# MAGIC     from
# MAGIC       store_sales,
# MAGIC       household_demographics,
# MAGIC       time_dim,
# MAGIC       store
# MAGIC     where
# MAGIC       ss_sold_time_sk = time_dim.t_time_sk
# MAGIC       and ss_hdemo_sk = household_demographics.hd_demo_sk
# MAGIC       and ss_store_sk = s_store_sk
# MAGIC       and time_dim.t_hour in (21,22) 
# MAGIC       -- and time_dim.t_minute < 30
# MAGIC       -- and (
# MAGIC       --   (
# MAGIC       --     household_demographics.hd_dep_count = 1
# MAGIC       --     --and household_demographics.hd_vehicle_count <= 1 + 2
# MAGIC       --   )
# MAGIC       --   or (
# MAGIC       --     household_demographics.hd_dep_count = 0
# MAGIC       --     --and household_demographics.hd_vehicle_count <= 0 + 2
# MAGIC       --   )
# MAGIC       --   or (
# MAGIC       --     household_demographics.hd_dep_count = 2
# MAGIC       --     --and household_demographics.hd_vehicle_count <= 2 + 2
# MAGIC       --   )
# MAGIC       --)
# MAGIC       -- and store.s_store_name = 'ese'
# MAGIC   ) s8
# MAGIC   limit
# MAGIC   100